package com.ssafy.productmgr;

import java.util.Arrays;

import com.ssafy.product.Product;
import com.ssafy.refrigerator.Refrigerator;
import com.ssafy.tv.Tv;

public class productMgr {
	private static productMgr mgr;
	private Product[] list = new Product[10];
	private int listIndex;

	private productMgr() {}

	public static productMgr getInstance() {
		if(mgr == null)
			mgr =  new productMgr();
		return mgr;
	}

	@Override
	public String toString() {
		return Arrays.toString(list);
	}

	public void addProduct(Product p) {
		list[listIndex++] = p;
	}

	public Product[] getProducts() {
		Product[] temp;
		int counter = 0;
		
		for (int i = 0; i < listIndex; i++) {
			if(list[i] != null)
				 counter++;
		}
			
		
		temp = new Product[counter];
		for (int i = 0; i < listIndex; i++) {
			if(list[i] != null)
				 temp[--counter] = list[i];
		}
		
		return temp;
	}

	public Product findBySerialNumber(String serialNumber) {
		for (int i = 0; i < listIndex; i++) {
			if(list[i].getSerialNumber().equals(serialNumber))
				return list[i];
		}

		return null;
	}

	public Product[] findByName(String name) {
		Product[] temp;
		int counter = 0;
		for (int i = 0; i < listIndex; i++) {
			if(list[i].getProductName().contains(name))
				counter++;
		}

		temp = new Product[counter];

		for (int i = 0; i < listIndex; i++) {
			if(list[i].getProductName().contains(name))
				temp[--counter] = list[i]; 
		}

		return temp;
	}

	public Tv[] findOnlyTv() {
		Tv[] temp;
		int counter = 0;

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Tv)
				counter++; 
		}

		temp = new Tv[counter];

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Tv)
				temp[--counter] = (Tv)list[i]; 
		}

		return temp;
	}

	public Refrigerator[] findOnlyRefrigerator() {
		Refrigerator[] temp = new Refrigerator[listIndex];
		int counter = 0;

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Refrigerator)
				counter++; 
		}

		temp = new Refrigerator[counter];

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Refrigerator)
				temp[--counter] = (Refrigerator)list[i]; 
		}

		return temp;
	}

	public Refrigerator[] findRefrigeratorByliters() {
		Refrigerator[] temp;
		int counter = 0;

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Refrigerator && ((Refrigerator)list[i]).getLiters() >= 400)
				counter++; 
		}

		temp = new Refrigerator[counter];

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Refrigerator && ((Refrigerator)list[i]).getLiters() >= 400)
				temp[--counter] = (Refrigerator)list[i]; 
		}
		return temp;
	}

	public Tv[] findTvByinches() {
		Tv[] temp;
		int counter = 0;

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Tv && ((Tv)list[i]).getInches() >= 50)
				counter++; 
		}

		temp = new Tv[counter];

		for (int i = 0; i < listIndex; i++) {
			if(list[i] instanceof Tv && ((Tv)list[i]).getInches() >= 50)
				temp[--counter] = (Tv)list[i]; 
		}

		return temp;
	}

	public void changePrice(String serialNumber, int price) {
		for (int i = 0; i < listIndex; i++) {
			if(list[i].getSerialNumber().equals(serialNumber)) {
				list[i].setPrice(price);
				return;
			}
		}
	}

	public void deleteProduct(String serialNumber) {
		for (int i = 0; i < listIndex; i++) {
			if(list[i].getSerialNumber().equals(serialNumber)) {
				for (int j = i; j < list.length-1; j++) {
					if( list[i+1] == null)
						return;
					list[i] = list[i+1];
				}
				list[9] = null;
				return;
			}
		}
	}

	public int getSumOfProducts() {
		int sum = 0;

		for (int i = 0; i < listIndex; i++)
			sum += list[i].getPrice() * list[i].getQuantity();

		return sum;
	}

}
