package test.com.ssafy.product;

public class FileAlreadyReadException extends Exception {
	public FileAlreadyReadException(String m) {
		super(m);
	}
}
