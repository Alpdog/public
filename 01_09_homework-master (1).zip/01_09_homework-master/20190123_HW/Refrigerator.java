package com.ssafy.refrigerator;

import com.ssafy.product.Product;

public class Refrigerator extends Product{
	private int liters;
	
	public Refrigerator(String serialNumber, String productName, int price, int quantity, int liters) {
		super(serialNumber, productName, price, quantity);
		setLiters(liters);
	}

	public int getLiters() {
		return liters;
	}

	public void setLiters(int liters) {
		this.liters = liters;
	}

	@Override
	public String toString() {
		return super.toString() + ", liters = " + liters;
	}
	
	
}
