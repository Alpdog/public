package test.com.ssafy.product;

public class ProductNotFoundException extends Exception {
	public ProductNotFoundException(String m) {
		super(m);
	}
}
