package com.ssafy.product;

import java.io.Serializable;

public class Product implements Serializable{
	private String serialNumber;
	private String productName;
	private int price;
	private int quantity;
	
	
	public Product(String serialNumber, String productName, int price, int quantity) {
		setSerialNumber(serialNumber);
		setProductName(productName);
		setPrice(price);
		setQuantity(quantity);
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "serialNumber = " + serialNumber + ", productName = " + productName + ", price = " + price
				+ ", quantity = " + quantity;
	}
	
	
	
	
}
