package test.com.ssafy.product;
import java.util.Collection;

import com.ssafy.product.Product;
import com.ssafy.refrigerator.Refrigerator;
import com.ssafy.tv.Tv;

public interface MgrInterface {

	boolean addProduct(Product p) throws DuplicateException;
	
	Collection<Product> getProducts();
	
	Product findBySerialNumber(String serialNumber) throws CodeNotFoundException;

	Collection<Product> findByName(String name);

	Collection<Tv> findOnlyTv();

	Collection<Refrigerator> findOnlyRefrigerator();

	Collection<Refrigerator> findRefrigeratorByliters() throws ProductNotFoundException;

	Collection<Tv> findTvByinches() throws ProductNotFoundException;

	boolean changePrice(String serialNumber, int price);

	boolean deleteProduct(String serialNumber);

	int getSumOfProducts();

}
