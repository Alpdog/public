package com.ssafy.tv;

import com.ssafy.product.Product;

public class Tv extends Product{
	private int inches;

	public Tv(String serialNumber, String productName, int price, int quantity, int inches) {
		super(serialNumber, productName, price, quantity);
		setInches(inches);
	}

	public int getInches() {
		return inches;
	}

	public void setInches(int inches) {
		this.inches = inches;
	}

	@Override
	public String toString() {
		return super.toString() + ", inches=" + inches;
	}
	
	

}
