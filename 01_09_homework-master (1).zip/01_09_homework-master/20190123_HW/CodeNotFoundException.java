package test.com.ssafy.product;

public class CodeNotFoundException extends Exception {
	public CodeNotFoundException(String m) {
		super(m);
	}
}
