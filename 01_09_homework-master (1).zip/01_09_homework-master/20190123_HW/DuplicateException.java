package test.com.ssafy.product;

public class DuplicateException extends Exception {
	public DuplicateException(String m) {
		super(m);
	}
}
