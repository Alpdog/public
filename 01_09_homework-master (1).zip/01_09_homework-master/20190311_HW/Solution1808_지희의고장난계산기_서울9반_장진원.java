import java.awt.List;
import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1808_지희의고장난계산기_서울9반_장진원 {
	static int[] available;
	static int[] dp;
	
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1808.txt"));
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int testCase = 1; testCase <= T; testCase++) {
			available = new int[10];
			
			for (int i = 0; i < available.length; i++)
				available[i] = sc.nextInt();

			int N  =sc.nextInt();
			
			if(N < 10) {
				if(available[N] == 1) {
					System.out.println("#" + testCase + " 2");
					continue;
				}
			}
			
			dp = new int[N+10];
			
			for (int i = 0; i < 10; i++) {
				if(available[i] == 1) {
					dp[i] = 1;
				}
			}
			
			solve(N);
			
			if(dp[N] == -1)
				System.out.println("#" + testCase + " -1");
			else
				System.out.println("#" + testCase + " " + dp[N]);
		}
	}
	

	private static int solve(int n) {
		if(dp[n] != 0)
			return dp[n];
		
		dp[n] = count(n);
		
		for (int i = 1; i <= (int)Math.sqrt(n); i++) {
			if(n%i == 0) {
				int num1 = solve(i);
				int num2 = solve(n/i);
				
				dp[n] = Math.min(dp[n], num1 == -1 || num2 == -1 ? -1 : num1+num2+1);
			}
		}
		
		return dp[n];
	}


	private static int count(int n) {
		int cnt = 0;
		
		while(n > 0) {
			int temp = n % 10;
			if(available[temp] == 0)
				return -1;
			n /= 10;
			cnt++;
		}
		
		return cnt;
	}

}
