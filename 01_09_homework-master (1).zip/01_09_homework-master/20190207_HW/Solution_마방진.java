package com.ssafy.ct;

import java.util.Scanner;

public class Solution_마방진 {
	static int N;
	static String[] codes = {"1001011001101001",
			"10010110011010010110100110010110",
			"1001011001101001",
			"10010110011010010110100110010110011010011001011010010110011010010110100110010110100101100110100110010110011010010110100110010110"};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		N = sc.nextInt();
		int[][] map = new int[N][N];
		int sx = N/2;
		int sy = 0;
		
		switch (N) {
		case 4:
			make4x(map, 1);
			break;
		case 8:
			make4x(map, 2);
			break;
		case 12:
			make12x(map, 3);
			break;
		case 16:
			make4x(map, 4);
			break;
		default:
			make(map, 0, 0, sx, sy, N, 1);
			break;
		}
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				System.out.printf("%5d",map[i][j]);
			}
			System.out.println();
		}
		
		System.out.println("마방진 체크 : " + check(map));
	}

	private static void make12x(int[][] map, int type) {
		int counter = 0;
		int numCounter =1;
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 4; j++) {
				if(codes[type-1].toCharArray()[counter] == '1') {
					numCounter = make(map, 3*j, 3*i, 3*j+1, 3*i,3,counter*9+1)-1;
				}
				else if(codes[type-1].toCharArray()[counter] == '0') {
					numCounter = make(map,3*j,3*i, 3*j+1, 3*i,3,N*N-counter*9-9+1);
				}
				counter++;
			}
		}
		
		for (int i = 2; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if(codes[type-1].toCharArray()[16-counter-1] == '1') {
					numCounter = make(map, 3*j, 3*i, 3*j+1, 3*i,3,counter*9+1)-1;
				}
				else if(codes[type-1].toCharArray()[16-counter-1] == '0') {
					numCounter = make(map, 3*j, 3*i, 3*j+1, 3*i,3,N*N-counter*9-9+1);
				}
				counter++;
			}
		}
	}

	private static void make4x(int[][] map, int type) {
		int counter = 0;
		for (int i = 0; i < map.length/2; i++) {
			for (int j = 0; j < map.length; j++) {
				if(codes[type-1].toCharArray()[counter] == '1') {
					map[i][j] = counter+1;
				}
				else if(codes[type-1].toCharArray()[counter] == '0') {
					map[i][j] = N*N-counter;
				}
				counter++;
			}
		}
		for (int i = map.length/2; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				if(codes[type-1].toCharArray()[N*N-counter-1] == '1') {
					map[i][j] = counter+1;
				}
				else if(codes[type-1].toCharArray()[N*N-counter-1] == '0') {
					map[i][j] = N*N-counter;
				}
				counter++;
			}
		}
	}

	private static int make(int[][] map, int rx, int cy, int sx, int sy, int size, int start) {
		int counter = start;
		map[sy][sx] = counter++;
		int nx, ny;
		int flag = 1;
		while(flag < size*size) {
			nx = sx +1;
			ny = sy -1;
			
			if(nx > rx + size-1)
				nx = rx;
			if(ny < cy)
				ny = cy + size-1;
			
			if(map[ny][nx] != 0) {
				nx = sx;
				ny = sy+1;
				map[ny][nx] = counter++;
			}else {
				map[ny][nx] = counter++;
			}
			
			sx=nx;
			sy=ny;
			flag++;
		}
		return counter;
	}

	private static boolean check(int[][] map) {
		int sum = 0;
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				sum += map[i][j]; 
			}
		}
		
		sum /= map.length;
		System.out.println("한 줄의 합 : " + sum);
		
		for (int i = 0; i < map.length; i++) {
			int temp = 0;
			for (int j = 0; j < map.length; j++)
				temp += map[i][j]; 
			if(temp != sum)
				return false;
			temp = 0;
		}
		
		for (int i = 0; i < map.length; i++) {
			int temp = 0;
			for (int j = 0; j < map.length; j++)
				temp += map[j][i]; 
			if(temp != sum)
				return false;
			temp = 0;
		}
		
		int temp = 0;
		for (int i = 0; i < map.length; i++)
				temp += map[i][i]; 
		if(temp != sum)
			return false;
		
		temp = 0;
		for (int i = 0; i < map.length; i++)
				temp += map[map.length-1-i][i]; 
		if(temp != sum)
			return false;
		
		return true;
	}
}
