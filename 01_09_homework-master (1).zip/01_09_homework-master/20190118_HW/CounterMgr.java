package com.ssafy.test;

import java.util.Scanner;

import com.ssafy.person.Person;
import com.ssafy.person.PersonMgr;
import com.ssafy.product.Product;
import com.ssafy.product.ProductMgr;

public class CounterMgr {

	private Scanner sc;
	ProductMgr product = ProductMgr.getInstance();
	PersonMgr person = PersonMgr.getInstance();
	
	private CounterMgr() {
		sc = new Scanner(System.in);
		StartUI();
	}


	private void StartUI() {
		while(true) {
			String menuFlag = getInputData("메뉴 입력 : 1. 상품/고객 정보 입력, 2. 상품/고객 정보 수정\n"
					+ " 3. 모든 상품/고객 보기, 4. 상품/고객 삭제\n"
					+ " 5. 선택 가격 미만의 상품 검색, 6. 이름으로 상품 검색\n"
					+ " 7. 전화번호로 고객 찾기, 8. 이름으로 고객 찾기\n"
					+ " 0. 종료");
			switch(menuFlag) {
			case "1" :
				add();
				break;
			case "2" :
				change();
				break;
			case "3" :
				getAll();
				break;
			case "4" :
				delete();
				break;
			case "5" :
				searchProductByName();
				break;
			case "6" :
				searchProductByPrice();
				break;
			case "7" :
				searchPersonByPhoneNumber();
				break;
			case "8" :
				searchPersonByName();
				break;
			case "0" :
				exitUI();
				break;
			default:
				System.out.println("잘못된 메뉴");
			}
		}
		
	}

	private void searchProductByName() {
		product.getProductsByName(getInputData("제품 이름을 입력하세요"));
	}

	private void searchProductByPrice() {
		product.getProductsByPrice(Integer.parseInt(getInputData("가격을 입력하세요")));
	}

	private void searchPersonByPhoneNumber() {
		person.getPeopleByPhoneNumber(getInputData("고객 전화번호를 입력하세요"));	
	}

	private void searchPersonByName() {
			person.getPeopleByName(getInputData("고객 성명을 입력하세요"));		
	}


	private void delete() {
		int input = Integer.parseInt(getInputData("삭제하고자 하는 카테고리를 선택하세요. (1) 상품, (2) 고객"));
		
		if(input == 1)
			product.deleteProduct(new Product(getInputData("삭제하고자 하는 제품 번호를 입력하세요"), "", 0, 0));
		if(input == 2)
			person.deletePerson(new Person(getInputData("삭제하고자 하는 고객 성명을 입력하세요"), 0, ""));		
	}

	private void getAll() {
		int input = Integer.parseInt(getInputData("보고자 하는 카테고리를 선택하세요. (1) 상품, (2) 고객"));
		
		if(input == 1)
			System.out.println(product.getAllProducts());
		if(input == 2)
			System.out.println(person.getAllPeople());		
	}


	private void change() {
		
		int input = Integer.parseInt(getInputData("수정하고자 하는 카테고리를 선택하세요. (1) 상품, (2) 고객"));
		
		if(input == 1)
			product.setProduct(new Product(getInputData("바꾸고자 하는 상품번호 입력"), getInputData("상품명 입력"),
					Integer.parseInt(getInputData("상품 가격 입력")), Integer.parseInt(getInputData("상품 수량 입력"))));
		if(input == 2)
			person.setPerson(new Person(getInputData("바꾸고자 하는 고객 성명 입력"),Integer.parseInt(getInputData("고객 나이 입력")), getInputData("고객 전화번호 입력")));
	}

	private void add() {
		int input = Integer.parseInt(getInputData("입력하고자 하는 카테고리를 선택하세요. (1) 상품, (2) 고객"));
		
		if(input == 1)
			product.addProduct(new Product(getInputData("상품번호 입력"), getInputData("상품명 입력"),
					Integer.parseInt(getInputData("상품 가격 입력")), Integer.parseInt(getInputData("상품 수량 입력"))));
		if(input == 2)
			person.addPerson(new Person(getInputData("고객 성명 입력"),Integer.parseInt(getInputData("고객 나이 입력")), getInputData("고객 전화번호 입력")));
	}


	private String getInputData(String string) {
		System.out.println(string);
		return sc.next();
	}
	
	private void exitUI() {
		System.out.println("프로그램 종료 메뉴 실행");
		System.exit(0);	
	}

	public static void main(String[] args) {
		new CounterMgr();
		System.out.println("정상종료");
	}

	

}
