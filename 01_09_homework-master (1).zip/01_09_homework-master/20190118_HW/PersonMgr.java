package com.ssafy.person;

import java.util.ArrayList;
import java.util.Collection;

import com.ssafy.product.Product;

public class PersonMgr implements IPersonMgr{
	private Collection<Person> people = new ArrayList<Person>();
	private static PersonMgr p;
	
	public PersonMgr() {}
	
	public static PersonMgr getInstance() {
		if(p == null)
			p = new PersonMgr();
		
		return p;
	}
	@Override
	public boolean addPerson(Person p) {
		if(p != null) {
			people.add(p);
			return true;
		}
		return false;
	}

	@Override
	public boolean setPerson(Person p) {
		for (Person person : people) {
			if(person.getName().equals(p.getName())) {
				person = p;
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deletePerson(Person p) {
		for (Person person : people) {
			if(person.getName().equals(p.getName())) {
				people.remove(person);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deletePerson(String name) {
		for (Person person : people) {
			if(person.getName().equals(name)) {
				people.remove(person);
				return true;
			}
		}
		return false;
	}

	@Override
	public Collection<Person> getAllPeople() {
		Collection<Person> temp = new ArrayList<Person>();
		for (Person person : people)
			temp.add(person);
		return temp;
	}

	@Override
	public Collection<Person> getPeopleByName(String name) {
		Collection<Person> temp = new ArrayList<Person>();
		for (Person person : people) {
			if(person.getName().equals(name))
				temp.add(person);
		}
		return temp;
	}

	@Override
	public Collection<Person> getPeopleByPhoneNumber(String phoneNumber) {
		Collection<Person> temp = new ArrayList<Person>();
		for (Person person : people) {
			if(person.getPhoneNumber().equals(phoneNumber))
				temp.add(person);
		}
		return temp;
	}

}
