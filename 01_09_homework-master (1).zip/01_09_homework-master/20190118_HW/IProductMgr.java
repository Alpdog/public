package com.ssafy.product;
import java.util.Collection;

import com.ssafy.product.Product;

public interface IProductMgr {

	boolean addProduct(Product p);
	boolean setProduct(Product p);
	boolean deleteProduct(Product p);
	boolean deleteProduct(String serialNumber);
	Collection<Product> getAllProducts();
	Collection<Product> getProductsByName(String name);
	Collection<Product> getProductsByPrice(int price);
}
