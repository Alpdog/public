package com.ssafy.person;
import java.util.Collection;

import com.ssafy.person.Person;
import com.ssafy.product.Product;

public interface IPersonMgr {

	boolean addPerson(Person p);
	boolean setPerson(Person p);
	boolean deletePerson(Person p);
	boolean deletePerson(String name);
	Collection<Person> getAllPeople();
	Collection<Person> getPeopleByName(String name);
	Collection<Person> getPeopleByPhoneNumber(String phoneNumber);
	
}
