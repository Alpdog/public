package com.ssafy.product;

public class Product {
	private String serialNumber;
	private String name;
	private int price;
	private int quantity;
	
	public Product(String serialNumber, String name, int price, int quantity) {
		setSerialNumber(serialNumber);
		setName(name);
		setPrice(price);
		setQuantity(quantity);
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "serialNumber=" + serialNumber + ", name=" + name + ", price=" + price + ", quantity="
				+ quantity;
	}
	
	
	
}
