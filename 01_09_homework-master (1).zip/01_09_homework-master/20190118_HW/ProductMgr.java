package com.ssafy.product;

import java.util.ArrayList;
import java.util.Collection;

public class ProductMgr implements IProductMgr {

	private static ProductMgr p;
	private Collection<Product> products = new ArrayList<Product>();
	
	public ProductMgr() {}
	
	public static ProductMgr getInstance() {
		if(p == null)
			p = new ProductMgr();
		
		return p;
	}

	@Override
	public boolean addProduct(Product p) {
		if(p != null) {
			products.add(p);
			return true;
		}
		return false;
	}

	@Override
	public boolean setProduct(Product p) {
		for (Product product : products) {
			if(product.getSerialNumber().equals(p.getSerialNumber())) {
				product = p;
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteProduct(Product p) {
		return deleteProduct(p.getSerialNumber());
	}
	
	@Override
	public boolean deleteProduct(String serialNumber) {
		for (Product product : products) {
			if(product.getSerialNumber().equals(serialNumber)) {
				products.remove(product);
				return true;
			}
		}
		return false;
	}

	@Override
	public Collection<Product> getAllProducts() {
		Collection<Product> temp = new ArrayList<Product>();
		for (Product product : products)
			temp.add(product);
		return temp;
	}

	@Override
	public Collection<Product> getProductsByName(String name) {
		Collection<Product> temp = new ArrayList<Product>();
		for (Product product : products){
			if(product.getName().contains(name))
				temp.add(product);
		}
		return temp;
	}

	@Override
	public Collection<Product> getProductsByPrice(int price) {
		Collection<Product> temp = new ArrayList<Product>();
		for (Product product : products){
			if(product.getPrice() < price)
				temp.add(product);
		}
		return temp;
	}



}
