package test.com.ssafy.product;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import com.ssafy.product.Product;
import com.ssafy.refrigerator.Refrigerator;
import com.ssafy.tv.Tv;

public class MgrImpl implements MgrInterface, Serializable{
	private Collection <Product> products = new ArrayList<Product>();
	private static boolean read = false;
	private static MgrImpl m;
	
	private MgrImpl() {}
	
	public static MgrImpl getInstance() {
		if(m == null)
			m = new MgrImpl();
		return m;
	}
	
	class ProductClient implements Runnable{
		Socket socket;
		ObjectOutputStream oos;
		ObjectInputStream ois;

		@Override
		public void run() {
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("src/products.dat"));
				
				try {
					for (Product product : products) {
						oos.writeObject(product);
					}
				} catch (Exception e) {
					e.printStackTrace();
					return;
				}
				
				socket = new Socket("70.12.108.202", 8879);
				oos =new ObjectOutputStream(socket.getOutputStream());
				ois = new ObjectInputStream(socket.getInputStream());
				try {
					Collection<Product> tempTv = new ArrayList<Product>();
					Collection<Product> tempRe = new ArrayList<Product>();
					for (Product product : products) {
						if(product instanceof Tv)
							tempTv.add(product);
						else if(product instanceof Refrigerator)
							tempRe.add(product);
					}
					oos.writeObject(tempTv);
					oos.flush();
					oos.writeObject(tempRe);
					oos.flush();
					
					System.out.println(ois.readObject());
				} catch (Exception e) {
				}
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch ( Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void send() {
		ProductClient u = new ProductClient();
		Thread t1 = new Thread(u);
		t1.start();
	}

	@Override
	public boolean addProduct(Product p) throws DuplicateException {
		for (Product product : products) {
			if(product.getSerialNumber().equals(p.getSerialNumber())) {
				throw new DuplicateException("중복된 제품");
			}
		}
		products.add(p);
		return false;
	}

	@Override
	public Collection<Product> getProducts() {
		Collection<Product> temp = new ArrayList<Product>();
		for (Product product : products) 
			temp.add(product);
		return temp;
	}

	@Override
	public Product findBySerialNumber(String serialNumber) throws CodeNotFoundException {
		for (Product product : products) {
			if(product.getSerialNumber().equals(serialNumber))
				return product;
		}
		throw new CodeNotFoundException("없는 제품입니다.");
	}

	@Override
	public Collection<Product> findByName(String name) {
		Collection<Product> temp = new ArrayList<Product>();
		for (Product product : products) {
			if(product.getProductName().contains(name))
				temp.add(product);
		}
		return temp;
	}

	@Override
	public Collection<Tv> findOnlyTv() {
		Collection<Tv> temp = new ArrayList<Tv>();
		for (Product product : products) {
			if(product instanceof Tv)
				temp.add((Tv) product);
		}
		return temp;
	}

	@Override
	public Collection<Refrigerator> findOnlyRefrigerator() {
		Collection<Refrigerator> temp = new ArrayList<Refrigerator>();
		for (Product product : products) {
			if(product instanceof Refrigerator)
				temp.add((Refrigerator) product);
		}
		return temp;
	}

	@Override
	public Collection<Refrigerator> findRefrigeratorByliters() throws ProductNotFoundException {
		Collection<Refrigerator> temp = new ArrayList<Refrigerator>();
		for (Product product : products) {
			if(product instanceof Refrigerator && ((Refrigerator) product).getLiters() >= 400)
				temp.add((Refrigerator) product);
		}
		if(temp == null)
			throw new ProductNotFoundException("해당 제품 없음");
		return temp;
	}

	@Override
	public Collection<Tv> findTvByinches() throws ProductNotFoundException{
		Collection<Tv> temp = new ArrayList<Tv>();
		for (Product product : products) {
			if(product instanceof Tv && ((Tv) product).getInches() >= 50)
				temp.add((Tv) product);
		}
		if(temp == null)
			throw new ProductNotFoundException("해당 제품 없음");
		return temp;
	}

	@Override
	public boolean changePrice(String serialNumber, int price) {
		for (Product product : products) {
			if(product.getSerialNumber().equals(serialNumber)) {
				product.setPrice(price);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteProduct(String serialNumber) {
		for (Product product : products) {
			if(product.getSerialNumber().equals(serialNumber)) {
				products.remove(product);
				return true;
			}
		}
		return false;
	}

	@Override
	public int getSumOfProducts() {
		int sum = 0;
		for (Product product : products) {
			sum += product.getPrice() * product.getQuantity();
		}
		return sum;
	}
	
	public void open() throws ClassNotFoundException, IOException, FileNotFoundException, FileAlreadyReadException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("src/products.dat"));

		try {
			if(read == true)
				throw new FileAlreadyReadException("이미 파일을 읽었습니다.");
			read = true;
			while(true) {
				products.add((Product)ois.readObject());
			}
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	
	}
	
	public void close() throws ClassNotFoundException, IOException {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("src/products.dat"));
		
		try {
			for (Product product : products) {
				oos.writeObject(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	
	}

}
