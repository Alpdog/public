package test.com.ssafy.product;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import com.ssafy.product.Product;
import com.ssafy.refrigerator.Refrigerator;
import com.ssafy.tv.Tv;

public class SimpleServer {
	
	public SimpleServer() {
		try {
			ServerSocket server = new ServerSocket(8879);
			while(true) {
				Socket socket = server.accept();

				System.out.println("다음 사용자가 전송." + socket.getInetAddress());
				ObjectOutputStream oos =new ObjectOutputStream(socket.getOutputStream());
				ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
				
				try {
					Collection<Tv> inputTv = (Collection<Tv>)ois.readObject();
					for (Tv tv : inputTv)
						System.out.println(tv);
					
					Collection<Refrigerator> inputRe = (Collection<Refrigerator>)ois.readObject();
					for (Refrigerator re : inputRe)
						System.out.println(re);

					oos.writeObject("전송 완료");
					oos.flush();

				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new SimpleServer();
	}
}
