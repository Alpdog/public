package test.com.ssafy.product;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

import com.ssafy.refrigerator.Refrigerator;
import com.ssafy.tv.Tv;


public class MgrImplTest implements Serializable {
	MgrImpl p= MgrImpl.getInstance();
	static Scanner sc;

	private MgrImplTest() throws FileNotFoundException, IOException, Exception{
		sc = new Scanner(System.in);
		p= MgrImpl.getInstance();
		StartUI();
	}

	private void StartUI() throws FileNotFoundException, IOException, Exception{

		sc = new Scanner(System.in);

		aaa:while(true) {
			switch (Integer.parseInt(getInput("다음 중 선택\n1. 상품 추가\n2. 전체 상품 출력 \n3. 상품 번호로 검색\n4. 냉장고 400리터 이상 출력\n5. TV 50인치 이상 출력\n6. 데이터 읽기\n7. 서버로 전송\n8. 데이터 저장 및  종료"))) {
			case 1:
				int temp = Integer.parseInt(getInput("추가할 품목 선택: (1) Tv, (2) 냉장고"));
				if( temp == 1)
					p.addProduct(new Tv(getInput("Serial number 입력"), getInput("제품명 입력"), Integer.parseInt(getInput("가격 입력")),
							Integer.parseInt(getInput("수량 입력")), Integer.parseInt(getInput("인치 입력"))));
				else if(temp == 2)
					p.addProduct(new Refrigerator(getInput("Serial number 입력"), getInput("제품명 입력"), Integer.parseInt(getInput("가격 입력")),
							Integer.parseInt(getInput("수량 입력")), Integer.parseInt(getInput("리터 입력"))));
				break;
			case 2:
				System.out.println(p.getProducts());
				break;
			case 3:
				System.out.println(p.findBySerialNumber(getInput("찾고자 하는 serialNumber 입력")));
				break;
			case 4:
				System.out.println(p.findRefrigeratorByliters());
				break;
			case 5:
				System.out.println(p.findTvByinches());
				break;
			case 6:
				p.open();
				break;
			case 7:
				p.send();
				System.out.println("서버로 전송");
				break ;
			case 8:
				p.close();
				System.out.println("시스템 종료");
				exitUI();
				break aaa;
			default:
				System.out.println("잘못된 입력");
				break;
			}
		}
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		new MgrImplTest();
		System.out.println("정상종료");
	}

	private void exitUI() {
		System.out.println("프로그램 종료");
		System.exit(0);	
	}

	public static String getInput(String m) {
		System.out.println(m);
		return sc.next();
	}
}

