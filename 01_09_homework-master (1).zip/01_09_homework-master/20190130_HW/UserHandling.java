package com.ssafy.news;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class UserHandling extends DefaultHandler{

	private String elementFlag = "";
	private NewsVO vo = null;
	private ArrayList<NewsVO> voList = new ArrayList<>();
	
	
	@Override
	public void startDocument() throws SAXException {
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equals("item")) {
			vo = new NewsVO();
		}else if(qName.equals("title")&& vo != null) {
			elementFlag = "title";
		}else if(qName.equals("description")&& vo != null) {
			elementFlag = "description";
		}else if(qName.equals("pubDate")&& vo != null) {
			elementFlag = "pubDate";
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("item")) {
			voList.add(vo);
			vo = null;
		}
		elementFlag = "";
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String temp = new String(ch, start, length).trim();
		switch (elementFlag) {
		case "title":
			vo.setTitle(temp);
			break;
		case "description":
			vo.setDescription(temp);
			break;
		case "pubDate":
			vo.setPubDate(temp);
			break;
		default:
			break;
		}
	}
	
	public ArrayList<NewsVO> getNews() {
		return voList;
	}
}
