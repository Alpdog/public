package com.ssafy.news;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class NewsDAO {
	private SAXParser p;
	private UserHandling u = new UserHandling();
	public NewsDAO() throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		p = factory.newSAXParser();
		p.parse("http://rss.etnews.com/Section902.xml", u);
	}
	
	public ArrayList<NewsVO> getNewsList() throws SAXException, IOException, ParserConfigurationException{
		return u.getNews();
		
	}
}
