import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class Solution1859_백만장자프로젝트 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1859.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <=T; testCase++) {
			int N = Integer.parseInt(br.readLine());
			
			String[] s = br.readLine().split(" ");
			int[] sellPrice = new int[N];
			
			for (int i = 0; i < sellPrice.length; i++)
				sellPrice[i] = Integer.parseInt(s[i]);
			
			int maxPrice = 0;
			int maxIndex = 0;
			long totalSum = 0;
			int startIndex = 0;
			
			while(startIndex != N) {
				for (int i = startIndex; i < sellPrice.length; i++) {
					sellPrice[i] = Integer.parseInt(s[i]);
					if(sellPrice[i] >= maxPrice) {
						maxPrice = sellPrice[i];
						maxIndex = i;
					}
				}
				
				for (int i = startIndex; i <= maxIndex; i++)
					totalSum += (maxPrice - sellPrice[i]);
				
				startIndex = maxIndex+1;
				maxPrice = 0;
			}
			
			System.out.println("#" + testCase + " " + totalSum);
		}
	}

}
