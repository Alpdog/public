import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main1018_십자카드문제_서울9반_장진원 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		Set<Integer> list = new HashSet<>();
		int number1, number2, number3, number4;
		
		for (int i1 = 1; i1 <= 9; i1++) {
			for (int i2 = 1; i2 < 10; i2++) {
				for (int i3 = 1; i3 < 10; i3++) {
					for (int i4 = 1; i4 < 10; i4++) {
						number1 = i1*1000+i2*100+i3*10 + i4;
						number2 = i3*1000+i4*100+i1*10 + i2;
						number3 = i4*1000+i1*100+i2*10 + i3;
						number4 = i2*1000+i3*100+i4*10 + i1;
						
						list.add(Math.min(Math.min(number1, number2), Math.min(number3, number4)));
					}
				}
			}
		}
		
		List<Integer> numberList = new ArrayList<>(list);
		Collections.sort(numberList);
		
		String s[] = br.readLine().split(" ");
		int[] n = new int[4];
		for (int i = 0; i < n.length; i++)
			n[i] = Integer.parseInt(s[i]);
		
		number1 = n[0]*1000+n[1]*100+n[2]*10 + n[3];
		number2 = n[1]*1000+n[2]*100+n[3]*10 + n[0];
		number3 = n[2]*1000+n[3]*100+n[0]*10 + n[1];
		number4 = n[3]*1000+n[0]*100+n[1]*10 + n[2];
		
		int temp = Math.min(Math.min(number1, number2), Math.min(number3, number4));
		
		for (int i : numberList) {
			if(temp == i) {
				System.out.println(numberList.indexOf(i)+1);
				return;
			}
		}
	}

}
