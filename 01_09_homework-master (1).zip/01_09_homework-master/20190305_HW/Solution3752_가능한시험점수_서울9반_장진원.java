import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution3752_가능한시험점수_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input3752.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			int N = Integer.parseInt(br.readLine());
			int[] score = new int[N];
			boolean[] chk = new boolean[10002];
			int answer = 0;
			String[] temp = br.readLine().split(" ");
			
			for (int i = 0; i < temp.length; i++)
				score[i] = Integer.parseInt(temp[i]);
			
			chk[0] = true;
			
			for (int i = 0; i < score.length; i++) {
				for (int j = chk.length-1; j >=0; j--) {
					if(chk[j] == true)
						chk[j+score[i]] = true;
				}
			}
			 
			for (int i = 0; i < chk.length; i++) {
				if(chk[i] == true)
					answer++;
			}
			
			System.out.println("#" + testCase + " " + answer);
		}
	}

}
