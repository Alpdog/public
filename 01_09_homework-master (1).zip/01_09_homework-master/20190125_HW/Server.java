package com.ssafy.java;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;

public class Server {
	
	public Server() {
		try {
			ServerSocket server = new ServerSocket(8879);
			while(true) {
				Socket socket = server.accept();

				System.out.println("다음 사용자가 전송." + socket.getInetAddress());
				ObjectOutputStream oos =new ObjectOutputStream(socket.getOutputStream());
				ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
				
				try {
					ArrayList<Customer> temp = (ArrayList<Customer>)ois.readObject();
					for (Customer c : temp)
						System.out.println(c);
					oos.writeObject("전송 완료");
					oos.flush();

				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new Server();
	}
}
