package com.ssafy.server;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.ssafy.java.Customer;

public class ContactServer {

	public static void main(String[] args) throws IOException {
		ServerSocket ss=new ServerSocket(3000);
		Socket s=null;
		ObjectInputStream ois=null;
		Customer cu=null;
		
		while(true){
			//서버 프로그램//s=ss.accept();//클라이언트가 접속 될때 까지 대기
			//ObjectIO 
		}
	}

}
