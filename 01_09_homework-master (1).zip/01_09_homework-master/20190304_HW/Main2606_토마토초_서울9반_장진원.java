import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main2606_토마토초_서울9반_장진원 {
	
	public static class tomato{
		int x;
		int y;
		int z;
		int timer;
		
		public tomato(int x, int y, int z, int timer) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.timer = timer;
		}
		public int getX() {
			return x;
		}
		public int getY() {
			return y;
		}
		public int getZ() {
			return z;
		}
		public int getTimer() {
			return timer;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] dx = {0,1,0,-1,0,0};
		int[] dy = {-1,0,1,0,0,0};
		int[] dz = {0,0,0,0,1,-1};
		int M = sc.nextInt();
		int N = sc.nextInt();
		int H = sc.nextInt();
		int maxTimer = 0;
		int[][][] box = new int[H][N][M];
		Queue<tomato> q = new LinkedList<>();

		boolean first = true;
		for (int i = 0; i < H; i++) {
			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < M; j2++) {
					box[i][j][j2] = sc.nextInt();
					if(box[i][j][j2] == 1) {
						q.offer(new tomato(j2, j, i, 0));
						first = false;
					}
				}
			}
		}
		
		if(first == true) {
			System.out.println("0");
			return;
		}
		
		while(!q.isEmpty()) {
			tomato temp = q.poll();
			if(temp.getTimer() > maxTimer)
				maxTimer = temp.getTimer();
			
			for (int i = 0; i < 6; i++) {
				int nx = temp.getX()+ dx[i];
				int ny = temp.getY()+ dy[i];
				int nz = temp.getZ()+ dz[i];
				
				if(nx < 0 || ny < 0|| nz < 0 || nx > M-1|| ny > N-1|| nz > H-1)
					continue;
				
				if(box[nz][ny][nx] == 1 || box[nz][ny][nx] == -1)
					continue;
				
				if(box[nz][ny][nx] == 0) {
					box[nz][ny][nx] = 1;
					q.offer(new tomato(nx, ny, nz, temp.getTimer()+1));
				}
			}
		}
		
		for (int i = 0; i < H; i++) {
			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < M; j2++) {
					if(box[i][j][j2] == 0) {
						System.out.println("-1");
						return;
					}
				}
			}
		}
		
		System.out.println(maxTimer);
		
	}

}
