import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main2613_토마토고_서울9반_장진원 {
	static int[] dx = {0,1,0,-1};
	static int[] dy = {-1,0,1,0};
	static int M, N;

	
	public static class tomato{
		int x;
		int y;
		int timer;
		
		public tomato(int x, int y, int timer) {
			this.x = x;
			this.y = y;
			this.timer = timer;
		}
		public int getX() {
			return x;
		}
		public int getY() {
			return y;
		}
		public int getTimer() {
			return timer;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int M = sc.nextInt();
		int N = sc.nextInt();
		int maxTimer = 0;
		int[][] box = new int[N][M];
		Queue<tomato> q = new LinkedList<>();
		int wp = 0;
		int rp = 0;
		boolean first = true;
			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < M; j2++) {
					box[j][j2] = sc.nextInt();
					if(box[j][j2] == 1) {
						q.offer(new tomato(j2, j, 0));
						first = false;
					}
				}
		}
		
		if(first == true) {
			System.out.println("0");
			return;
		}
		
		while(!q.isEmpty()) {
			tomato temp = q.poll();
			if(temp.getTimer() > maxTimer)
				maxTimer = temp.getTimer();
			
			for (int i = 0; i < 4; i++) {
				int nx = temp.getX()+ dx[i];
				int ny = temp.getY()+ dy[i];
				
				if(nx < 0 || ny < 0|| nx > M-1|| ny > N-1)
					continue;
				
				if(box[ny][nx] == 1 || box[ny][nx] == -1)
					continue;
				
				if(box[ny][nx] == 0) {
					box[ny][nx] = 1;
					q.offer(new tomato(nx, ny, temp.getTimer()+1));
				}
			}
		}
		
			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < M; j2++) {
					if(box[j][j2] == 0) {
						System.out.println("-1");
						return;
					}
				}
			}
		
		System.out.println(maxTimer);
		
	}

}
