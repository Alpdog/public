use ssafy;

# 부서 위치가 CHICAGO인 모든 사원에 대해 이름, 업무, 급여 출력
select ename, job, sal from emp, dept where emp.deptno = dept.deptno and loc in (select loc from emp where loc = 'CHICAGO');

# 부하직원이 없는 사원의 사원번호, 이름, 업무, 부서번호 출력
select empno, ename, job, deptno from emp 
where empno not in (select empno from emp where empno in (select mgr from emp));

# BLAKE와 같은 상사를 가진 사원의 이름, 업무, 상사번호 출력
select ename, job, mgr from emp where mgr = (select mgr from emp where ename = 'BLAKE');

# 입사일이 가장 오래된 사람 5명을 검색;
select ename, hiredate ,(SELECT count(ename) FROM emp WHERE hiredate <= e.hiredate) AS ranking
FROM emp e order by ranking LIMIT 5;

# JONES의 부하 직원의 이름, 업무, 부서명을 검색
select ename, job, dname from emp, dept where emp.deptno = dept.deptno and mgr = (select mgr from emp where ename = 'JONES');