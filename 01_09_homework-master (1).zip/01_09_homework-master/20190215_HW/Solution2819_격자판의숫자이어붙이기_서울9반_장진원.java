package DFS;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;

public class Solution2819_격자판의숫자이어붙이기_서울9반_장진원 {
	static int[] dx = {0, 1, 0, -1};
	static int[] dy = {-1, 0, 1, 0};
	static int[][] map;
	static StringBuilder s = new StringBuilder();
	static HashSet<String> c = new HashSet<>();
	
	public static void main(String[] args) throws FileNotFoundException{
		System.setIn(new FileInputStream("res/input2819.txt"));
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int testCase = 1; testCase <= T; testCase++) {
			map = new int[4][4];
			for (int i = 0; i < map.length; i++) {
				for (int j = 0; j < map.length; j++)
					map[i][j] = sc.nextInt();
			}
			
			for (int i = 0; i < map.length; i++) {
				for (int j = 0; j < map.length; j++) {
					s.append(map[i][j]);
					run(i,j,1);
					s.deleteCharAt(0);
				}
			}
			
			System.out.println("#" + testCase + " " + c.size());
			c.clear();
		}
	}

	private static void run(int row, int col, int counter) {
		int startRow = row;
		int startCol = col;
		
		if(s.length() == 7) {
			String temp = s.toString();
			c.add(temp);
			return;
		}
		
		for (int i = 0; i < dx.length; i++) {
			int nx = startCol + dx[i];
			int ny = startRow + dy[i];
			
			if(nx < 0 || ny < 0 || nx > 3|| ny > 3)
				continue;
			
			s.append(map[ny][nx]);
			run(ny, nx, counter+1);
			s.deleteCharAt(counter);
		}
	}
}
