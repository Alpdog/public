import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Main1681_해밀턴순환회로_서울9반_장진원 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int N = Integer.parseInt(br.readLine());
		int[][] cost = new int[N][N];
		int[][] table = new int[1<<19][N];
		int min = 0;
		String[] s;
		for (int i = 0; i < N; i++) {
			s= br.readLine().split(" ");
			for (int j = 0; j < N; j++) {
				cost[i][j] = Integer.parseInt(s[j]);
				if(cost[i][j] == 0)
					cost[i][j] = Integer.MAX_VALUE;
			}
		}
		
		for (int i = 1; i < N; i++)
			table[(1<<i)|1][i] = cost[0][i];
		
		for (int i = 7; i <= (1<<19)-1; i+=2) {
			
			for (int j = 1; j < N; j++) {
				if(check(i,j) == 0)
					continue;
				if(table[i][j] != 0)
					continue;
				
				table[i][j] = Integer.MAX_VALUE;
				
				int temp = clear(i,j);
				for (int k = 1; k < N; k++) {
					if(check(temp, k) == 0)
						continue;
					if(table[temp][k] == Integer.MAX_VALUE)
						continue;
					if(cost[k][j] == Integer.MAX_VALUE)
						continue;
					
					if(table[i][j] > table[temp][k] + cost[k][j])
						table[i][j] = table[temp][k] + cost[k][j];
				}
				
			}
		}
		
		min = Integer.MAX_VALUE;
		for (int i = 1; i < N; i++) {
			if(table[(1<<N)-1][i] == Integer.MAX_VALUE)
				continue;
			if(cost[i][0] == Integer.MAX_VALUE)
				continue;
			if(min > table[(1<<N)-1][i] + cost[i][0])
				min = table[(1<<N)-1][i] + cost[i][0];
		}
		
		System.out.println(min);
	}
	
	public static int check(int bit, int last) {
		return bit & (1<< last);
	}
	
	public static int clear(int bit, int last) {
		return bit & ~(1<< last);
	}

}
