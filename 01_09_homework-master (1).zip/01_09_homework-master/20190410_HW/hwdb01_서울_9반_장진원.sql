show databases;
use ssafy;
show tables;

# 입사일이 2014년도인 모든 사람의 정보
select * from emp where year(hiredate) = 1980;

# 이름에 S가 들어가 있는 사람의 모든 정보
select * from emp where ename like '%S%';

# 커미션이 NULL인 사람의 정보
select * from emp where comm is null;

# 각 부서별 급여의 평균, 최고, 최저, 인원수를 구하여 검색
select avg(sal), max(sal), min(sal), count(empno) from emp group by deptno;

# 30번 부서의 연봉을 계산하여 이름, 부서번호, 급여, 연봉(12개월 월급여 + 연말보너스)를 검색. 단 연말에 급여의 150%를 보너스로 지급한다.
select ename, deptno, sal, (12*sal)+sal*1.5 from emp where deptno = 30;

# 급여가 $2000 이상인 모든 사람은 급여의 15%를 경조비로 낼 때, 이름, 급여, 경조비(소수점 이하 절삭)을 검색.
select ename, sal, sal*0.15 from emp where sal >= 2000;

# 각 부서별 평균 월급, 전체 월급, 최저 월급을 구하여 평균 월급이 많은 순으로 검색
select avg(sal), sum(sal), min(sal) from emp group by deptno order by 1 desc;

select * from emp;
