########## mysql 명령어
show databases;
use ssafy;
show tables;
######### SQ, 명령어는 대문자, skima는 소문자로 입력
DESC EMP;

select * from emp;
select empno, ename, job,mgr, hiredate, sal, comm, deptno
from emp;

select empno AS employeeNumber from emp;
select empno AS 사원번호, sal AS 급여, comm AS 보너스 from emp;
select empno, sal + comm from emp;
select empno, sal + coalesce(comm, 0) from emp;
select empno, sal + IFNULL(comm, 0) from emp;
select empno, if(comm is null, 'true', 'false') from emp;

## 사원의 번호, 이름, 사원 부서 정보를 출력
select EMPNO, ENAME, DEPTNO from emp;

## 급여 : 1000, 보너스 : 0
select CONCAT('급여 : ', sal, ', 보너스 : ', COALESCE(comm, 0) )AS 급여정보 from emp;

select empno, sal from emp;
select empno, sal from emp order by sal, empno desc;
select empno, sal from emp order by 1, empno desc;
select empno, sal from emp order by 2, empno desc;
select empno, sal from emp order by 3, empno desc;
select ename from emp;
select ename from emp where binary ename = 'SMITH';
select ename from emp where binary ename = 'smith';
select ename from emp where binary ename like 'S%';
select ename from emp where binary ename like '_L%';

## 1980년 생년월일을 가진 사람의 이름과 생년월일 출력
select  ename, hiredate from emp where hiredate like '1980%';
select  ename, hiredate from emp where hiredate = '1980-12-17';
select  ename, hiredate from emp where hiredate = '80-12-17';
select  ename, hiredate from emp where hiredate = '801217';

## query문으로 column 갯수 세기
select count(ename) from emp;
select count(comm) from emp;
select sysdate() from dual;
create table simple(s char(1));
insert into simple values('0');
select * from simple;
select now(), curdate(), sysdate(), current_timestamp() from simple;
select now() from simple;
select year(now()), month(now()) from simple;
##최대 급여, 최소 급여, 평균 급여를 출력하도록 하기
select max(sal) from emp;
select min(sal) from emp;
select avg(sal) from emp;

##소수점 둘째자리까지 찾기
select round(avg(sal), 2) from emp;

# 테이블 정보의 구조를 확인하기
select * from emp;

#K로 시작하는 사원 정보
select EMPNO, ename, HIREDATE, SAL from emp where ename like binary 'K%' ;

#입사일이 2000년도인 사람의 모든 정보를 검색
select EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO from emp where hiredate like '1980%';

#커미션이 NULL이 아닌 사람의 모든 정보
select EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO 
	from emp where COMM is not NULL;
    
#부서가 30번이고 급여가 $1500 이상인 사람의 이름, 부서, 월급 검색
select ENAME, DEPTNO, SAL from emp where DEPTNO = 30 and SAL >= 1500;

#부서 번호가 30인 사람 중 사원 번호 SORT하여 출력
select empno from emp where deptno = 30 order by 1, empno desc;

#급여가 많은 순으로 SORT하여 출력
select empno, sal from emp where deptno = 30 order by sal desc;

#부서 번호로 ASCENDING SORT한 후 급여가 많은 사람 순으로 검색
select * from emp order by deptno asc, sal desc;

# 부서번호가 DESCENDING SORT하고, 이름 순으로 ASCENDING SORT,
# 급여 순으로 DESCENDING SORT 하여 출력되도록 검색
select * from emp order by deptno desc, ename asc, sal desc;

#emp table에서 이름, 급여, 커미션 금액, 총액을 구하여 총액이 많은 순서로 검색. 단 커미션이 NULL인 경우는 제외
select ename, sal, comm , sal*comm/100 from emp where comm is not null order by 4 desc;

#10번 부서의 모든 사람들에게 급여의 13%를 보너스로 지불할 때, 이름, 급여, 보너스 금액, 부서 번호를 검색
select ename AS 이름, sal AS 급여, (sal*0.13) AS 보너스금액, deptno AS 부서번호 from emp
 where deptno = 10;
 
 #부서 번호가 20인 사원의 시간당 임금을 계산하여 검색. (이름, 급여, 시간당 임금(소수 첫째 자리에서 반올림)을 검색)
 select ename AS 이름, sal AS 급여, round(sal/(12*5),1) AS 시간당임금 from emp where deptno = 20; 

#급여가 $1500부터 $3000 사이의 사람은 급여의 15%를 회비로 지불할 때 
#이름, 급여, 회비(소숫점 둘째 자리에서 반올림)를 검색
select  ename AS 이름, sal AS 급여, round(sal*0.15, 2) as 회비 from emp
 where sal < 3000 and sal > 1500;
 
 #모든 사원의 실수령액을 계산하여 급여가 많은 순으로 이름, 급여, 실수령액을 검색(실수령액은 급여의 10%를 뺀 금액)
 select ename AS 이름, sal AS 급여, sal*0.9 as 실수령액 from emp order by 2 desc;
 
 #이름의 글자수가 6자 이상인 사람의 이름을 앞에서 3자만 구하여 소문자로만 이름을 검색
 select left(lower(ename), 3) from emp where ename like '______%';
 
 #10번 부서 월급의 평균, 최고, 최저, 인원수를 구하여 검색
 select avg(sal), max(sal), min(sal), count(ename) from emp where deptno = 10;
 
 #각 부서별 같은 업무를 하는 사람의 인원 수를 구하여 부서번호, 업무명, 인원 수를 검색
 select deptno, job, count(*) from emp group by deptno, job order by deptno asc; 
 
 #같은 업무를 하는 사람의 수가 4명 이상인 업무와 인원 수를 검색
 select job, count(*) from emp group by job HAVIng count(*) >= 4;
 
 #입사일로부터 오늘까지의 일수를 구하여 이름, 입사일, 근무일수 검색
 select ename, hiredate, datediff(now(),hiredate) as 근무일수 from emp;
 
 #직원의 이름, 근속년수를 구하여 검색
 select ename, year(now())-year(hiredate) from emp;
