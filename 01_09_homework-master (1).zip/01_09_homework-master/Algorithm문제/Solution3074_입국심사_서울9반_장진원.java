import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Scanner;

public class Solution3074_입국심사_서울9반_장진원 {
	static long[] timer;
	static int N, M;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input3074.txt"));
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int testCase = 1; testCase <= T; testCase++) {
			N = sc.nextInt();
			M = sc.nextInt();
			
			timer = new long[N];
			long max = 0;
			for (int i = 0; i < N; i++) {
				timer[i] = sc.nextInt();
				if(max < timer[i])
					max = timer[i];
			}
			
			
			long time1 = 0;
			long time2 = max*M;
			long min = time2;
			long mid = (time1+time2)/2;
			
			while(time1 <= time2) {
				long cnt = 0;
				mid = (time1+time2)/2;
				
				for (int i = 0; i < N; i++)
					cnt += mid/timer[i];
				
				if(cnt < M)
				{
					time1 = mid+1;
					
				}else {
					if(min > mid)
						min = mid;
					time2 = mid-1;
				}
			}

			System.out.println("#" + testCase + " " + min);
		}
	}
}
