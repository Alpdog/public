import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * (1) 요구사항
 * 	주어진 2진수와 3진수에서 각각 1자리 씩만 바꾸어서 같아지는 숫자를 찾는 것
 * 
 * (2) 입력
 *  3 이상 40 미만의 자릿수를 가진 2진수와 3진수를 입력받는다.
 * 
 * (3) 처리
 *  미리 long 배열로 2의 거듭제곱과 3의 거듭제곱들을 저장해놓는다.
 *  2진수는 자릿수와 같은 갯수의 바뀐 수들이 나오고(최대 40), 3진수는 자릿수*2의 갯수의 바뀐 수들이 나온다(최대 80).
 *  위의 수들을 배열 temp1, temp2에 저장해놓고 0 <= i <= 자릿수-1 의 범위의 i에 대해 temp1[i](2진수 바뀐 수) 와 temp2[2*i], temp2[2*i+1]를
 *  비교하여 같은 숫자를 찾으면 그것이 답이다.
 *  
 *  (4) 출력
 *  위에서 찾은 숫자를 출력.
 *  
 *  * 유의사항
 *  기억하는 숫자는 0을 모두 포함해서 기억하는 것이다. 1010으로 기억하면 00001010과 같은 값들은 계산하지 않는다.
 *  (위와 같은 방식으로 처리하면 1번 테스트케이스에서 266이 출력된다.)
 * */

public class Solution4366_정식이의은행업무_서울9반_장진원 {
	static long[] power2 = new long[40];
	static long[] power3 = new long[40];
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/Solution4366_정식이의은행업무_서울9반_장진원.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		power2[0] =1;
		power3[0] =1;
		
		for (int i = 1; i < power2.length; i++)	// 2와 3의 거듭제곱들을 구해서 저장하는 과정.
			power2[i] = power2[i-1]*2;			
		for (int i = 1; i < power3.length; i++)	// Math.power(a,b) : Math 라이브러리를 대체.
			power3[i] = power3[i-1]*3;
		
		int T = Integer.parseInt(br.readLine());

		test:for (int testCase = 1; testCase <= T; testCase++) {
			String temp = br.readLine();
			String binNumber = temp;
			long decimal1 = deci2(2,temp);
			temp = br.readLine();
			String triNumber = temp;
			long decimal2 = deci3(3,temp);
			long[] temp1 = new long[binNumber.length()];
			long[] temp2 = new long[triNumber.length()*2];

			int length = temp1.length;
			for (int i = 0; i < length; i++) {
				if(binNumber.charAt(i)-'0' == 0)
					temp1[i] = decimal1 + power2[length-1-i];
				else
					temp1[i] = decimal1 - power2[length-1-i];
			}
			
			length = temp2.length/2;
			for (int i = 0; i < length; i++) {
				if(triNumber.charAt(i)-'0' == 0) {
					temp2[2*i] = decimal2 + power3[length-1-i];
					temp2[2*i+1] = decimal2 + 2*power3[length-1-i];
				}
				else if(triNumber.charAt(i)-'0' == 1) {
					temp2[2*i] = decimal2 - power3[length-1-i];
					temp2[2*i+1] = decimal2 + power3[length-1-i];
				}
				else {
					temp2[2*i] = decimal2 - power3[length-1-i];
					temp2[2*i+1] = decimal2 - 2*power3[length-1-i];
				}
			}
			
			for (int i = 0; i < temp1.length; i++) {
				for (int j = 0; j < temp2.length/2; j++) {
					if(temp1[i] == temp2[2*j]) {
						System.out.println("#" + testCase + " " + temp1[i]);
						continue test;
					}
					if(temp1[i] == temp2[2*j+1]) {
						System.out.println("#" + testCase + " " + temp1[i]);
						continue test;
					}
				}
			}
		}

	}
	private static long deci2(int base, String binNumber) {
		long number = 0;
		int length = binNumber.length();
		for (int i = 0; i < length; i++)
			number += power2[length-i-1] * (binNumber.charAt(i)-'0');
		return number;
	}
	
	private static long deci3(int base, String binNumber) {
		long number = 0;
		int length = binNumber.length();
		for (int i = 0; i < binNumber.length(); i++)
			number += power3[length-i-1] * (binNumber.charAt(i)-'0');
		return number;
	}
}
