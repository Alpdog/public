import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution1865_동철이의일분배_서울9반_장진원 {
	static boolean[] chk;
	static int[][] p;
	static int N;
	static double max;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1865.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			N = Integer.parseInt(br.readLine());
			p = new int[N][N];
			
			for (int i = 0; i < N; i++) {
				String[] s = br.readLine().split(" ");
				for (int j = 0; j < N; j++)
					p[i][j] = Integer.parseInt(s[j]);
			}
			
			chk = new boolean[N];
			double result = 1;
			max = 0;
			
			for (int i = 0; i < N; i++) {
				chk[i] = true;
				DFS(1, result*p[0][i] / 100);
				chk[i] = false;
			}
			
			System.out.printf("#%d %6f", testCase, max*100);
			System.out.println();
		}
	}
	private static void DFS(int i, double d) {
		if(d <= max || i == N) {
			if(max < d)
				max = d;
			return;
		}
		
		for (int j = 0; j < N; j++) {
			if(chk[j] != true) {
				chk[j] = true;
				DFS(i+1, (d*p[i][j])/100);
				chk[j] = false;
			}
		}
	}

}
