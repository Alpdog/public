import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution4261_빠른휴대전화키패드_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input4261.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			String order = s[0];
			int wordLengthLimit = order.length();
			int number = Integer.parseInt(s[1]);
			
			String[] temp = br.readLine().split(" ");
			int answer = 0;
			for (int i = 0; i < number; i++) {
				boolean result = true;
				if(temp[i].length() != wordLengthLimit)
					continue;
				for (int j = 0; j < wordLengthLimit; j++) {
					if(check(temp[i].charAt(j)-'a', order.charAt(j)-'0') == false) {
						result = false;
						break;
					}
				}
				
				if(result == true)
					answer++;
			}
			
			System.out.println("#" + testCase + " "+ answer);
		}
				 
	}

	private static boolean check(int charAt, int i) {
		switch (charAt) {
		case 0:	case 1:	case 2:
			if(i ==2)
				return true;
			return false;
		case 3:	case 4:	case 5:
			if(i ==3)
				return true;
			return false;
		case 6:	case 7:	case 8:
			if(i ==4)
				return true;
			return false;
		case 9:	case 10: case 11:
			if(i ==5)
				return true;
			return false;
		case 12: case 13: case 14:
			if(i ==6)
				return true;
			return false;
		case 15: case 16: case 17: case 18:
			if(i ==7)
				return true;
			return false;
		case 19: case 20: case 21:
			if(i ==8)
				return true;
			return false;
		case 22: case 23: case 24: case 25:
			if(i ==9)
				return true;
			return false;
		}
		return false;
	}

}
