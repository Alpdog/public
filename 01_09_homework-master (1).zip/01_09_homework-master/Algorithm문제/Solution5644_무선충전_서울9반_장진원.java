import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Solution5644_무선충전_서울9반_장진원 {
	static int[] dx = {0,0,1,0,-1};
	static int[] dy = {0,-1,0,1,0};
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input5644.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			int M = Integer.parseInt(s[0]);
			int A = Integer.parseInt(s[1]);
			int[][] user1 = new int[M+1][2];
			int[][] user2 = new int[M+1][2];
			int[][] BCList = new int[A][4];
			user1[0][0] = 1;
			user1[0][1] = 1;
			user2[0][0] = 10;
			user2[0][1] = 10;
			s = br.readLine().split(" ");
			for (int i = 1; i <= M; i++) {
				user1[i][0] = user1[i-1][0] + dx[Integer.parseInt(s[i-1])];
				user1[i][1] = user1[i-1][1] + dy[Integer.parseInt(s[i-1])];
			}

			s = br.readLine().split(" ");
			for (int i = 1; i <= M; i++) {
				user2[i][0] = user2[i-1][0] + dx[Integer.parseInt(s[i-1])];
				user2[i][1] = user2[i-1][1] + dy[Integer.parseInt(s[i-1])];
			}

			for (int i = 0; i < BCList.length; i++) {
				s = br.readLine().split(" ");
				BCList[i][0] = Integer.parseInt(s[0]);
				BCList[i][1] = Integer.parseInt(s[1]);
				BCList[i][2] = Integer.parseInt(s[2]); // 충전 범위 C
				BCList[i][3] = Integer.parseInt(s[3]); // 처리량 P
			}

			int sum = 0;

			for (int i = 0; i <= M; i++) {
				ArrayList<Integer> user1BCList = new ArrayList<>();
				ArrayList<Integer> user2BCList = new ArrayList<>();
				for (int j = 0; j < BCList.length; j++) {
					if(Math.abs(user1[i][0] - BCList[j][0]) + Math.abs(user1[i][1] - BCList[j][1]) <= BCList[j][2])
						user1BCList.add(j);
				}

				for (int j = 0; j < BCList.length; j++) {
					if(Math.abs(user2[i][0] - BCList[j][0]) + Math.abs(user2[i][1] - BCList[j][1]) <= BCList[j][2])
						user2BCList.add(j);
				}

				int temp = 0;
				if(user1BCList.size() != 0 && user2BCList.size() != 0) {
					for (int j = 0; j < user1BCList.size(); j++) {
						for (int j2 = 0; j2 < user2BCList.size(); j2++) {
							if(user1BCList.get(j) != user2BCList.get(j2)) {
								temp = temp < BCList[user1BCList.get(j)][3] + BCList[user2BCList.get(j2)][3] ?
										BCList[user1BCList.get(j)][3] + BCList[user2BCList.get(j2)][3] : temp;
							}else {
								temp = temp < (BCList[user1BCList.get(j)][3] + BCList[user2BCList.get(j2)][3])/2 ?
										(BCList[user1BCList.get(j)][3] + BCList[user2BCList.get(j2)][3])/2 : temp;
							}
						}
					}

					for (int j = 0; j < user2BCList.size(); j++) {
						for (int j2 = 0; j2 < user1BCList.size(); j2++) {
							if(user2BCList.get(j) != user1BCList.get(j2)) {
								temp = temp < BCList[user2BCList.get(j)][3] + BCList[user1BCList.get(j2)][3] ?
										BCList[user2BCList.get(j)][3] + BCList[user1BCList.get(j2)][3] : temp;
							}else {
								temp = temp < (BCList[user2BCList.get(j)][3] + BCList[user1BCList.get(j2)][3])/2 ?
										(BCList[user2BCList.get(j)][3] + BCList[user1BCList.get(j2)][3])/2 : temp;
							}
						}
					}
				}else {
					if(user1BCList.size() == 0) {
						for (int j = 0; j < user2BCList.size(); j++)
							temp = temp < BCList[user2BCList.get(j)][3] ? BCList[user2BCList.get(j)][3] : temp;
					}else {
						for (int j = 0; j < user1BCList.size(); j++)
							temp = temp < BCList[user1BCList.get(j)][3] ? BCList[user1BCList.get(j)][3] : temp;
					}
						
				}
				sum += temp;
			}

			System.out.println("#" + testCase + " " + sum);
		}
	}
}
