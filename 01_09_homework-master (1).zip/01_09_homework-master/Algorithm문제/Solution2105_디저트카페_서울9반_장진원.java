import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution2105_디저트카페_서울9반_장진원 {
	static int[][] map;
	static boolean[] picked;
	static boolean[] dirChk;
	static boolean[][] mapChk;
	static int[] dx = {1,1,-1,-1};
	static int[] dy = {-1,1,1,-1};
	static int N, answer;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input2105.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <=T; testCase++) {
			N = Integer.parseInt(br.readLine());
			map = new int[N][N];
			mapChk = new boolean[N][N];
			picked = new boolean[100+1];
			dirChk = new boolean[4];
			picked[0] = true;
			answer = 0;
			String[] s;
			
			for (int i = 0; i < map.length; i++) {
				s = br.readLine().split(" ");
				for (int j = 0; j < s.length; j++)
					map[i][j] = Integer.parseInt(s[j]);
			}
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if(chk(i,j,1) && chk(i,j,2)) {
						picked[map[i + dy[1]][j+dx[1]]] = true;
						mapChk[i + dy[1]][j+dx[1]] = true;
						DFS(i + dy[1],j+dx[1],1, i,j, 1);
						picked[map[i + dy[1]][j+dx[1]]] = false;
						mapChk[i + dy[1]][j+dx[1]] = false;
					}
				}
			}
			
			if(answer >= 4)
				System.out.println("#" + testCase + " " + answer);
			else
				System.out.println("#" + testCase + " -1");
		}
	}
	private static void DFS(int row, int col, int dir, int startRow, int startCol, int ate) {
		if(row == startRow && col == startCol) {
			if(answer < ate)
				answer = ate;
			return;
		}
		
		for (int i = 0; i < 4; i++) {
			if(dirChk[i] == true)
				continue;
			
			int nx = col + dx[i];
			int ny = row + dy[i];
			
			if(nx < 0 || ny < 0 || nx >= N || ny >= N || picked[map[ny][nx]] == true || mapChk[ny][nx] == true)
				continue;
			
			if(dir != i) {
				dirChk[dir] = true;
				picked[map[ny][nx]] = true;
				mapChk[ny][nx] = true;
				DFS(ny,nx,i,startRow,startCol, ate+1);
				dirChk[dir] = false;
				picked[map[ny][nx]] = false;
				mapChk[ny][nx] = false;
			}else {
				picked[map[ny][nx]] = true;
				mapChk[ny][nx] = true;
				DFS(ny,nx,dir,startRow,startCol, ate+1);
				picked[map[ny][nx]] = false;
				mapChk[ny][nx] = false;
			}
		}
	}
	private static boolean chk(int i, int j, int dir) {
		if(j+dx[dir] >= 0 && i + dy[dir] >= 0 &&
				j+dx[dir] < N && i + dy[dir] < N &&
				map[i][j] != map[i + dy[dir]][j+dx[dir]])
			return true;
		return false;
	}

}
