import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Solution2462_키순서_서울9반_장진원 {

	static int forwardSum;
	static int backwardSum;
	static int[][] list;
	static boolean[] p;
	static int N, M;

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String[] s = br.readLine().split(" ");

		N = Integer.parseInt(s[0]);
		M = Integer.parseInt(s[1]);
		list = new int[N][N];

		for (int i = 0; i < M; i++) {
			s = br.readLine().split(" ");
			list[Integer.parseInt(s[0])-1][Integer.parseInt(s[1])-1] = 1;
			list[Integer.parseInt(s[1])-1][Integer.parseInt(s[0])-1] = -1;
		}

		int answer = 0;
		for (int i = 0; i < N; i++) {
			int forwardSum = 0;
			int backwardSum = 0;
			p = new boolean[N];
			p[i] = true;
			for (int j = 0; j < N; j++) {
				if(list[i][j] == 1) {
					p[j] = true;
					forward(j,1);
				}
			}
			
			for (int j = 0; j < p.length; j++) {
				if(p[j] == true)
					forwardSum++;
			}
			
			p = new boolean[N];
			
			p[i] = true;
			for (int j = 0; j < N; j++) {
				if(list[i][j] == -1) {
					p[j] = true;
					forward(j,-1);
				}
			}
			
			for (int j = 0; j < p.length; j++) {
				if(p[j] == true)
					backwardSum++;
			}
			
			if(forwardSum + backwardSum == N+1)
				answer++;

		}
		
		System.out.println(answer);
	}

	private static void forward(int index, int dir) {
		for (int i = 0; i < N; i++) {
			if(list[index][i] == dir && p[i] != true) {
				p[i] = true; 
				forward(i, dir);
			}
		}
	}

}
