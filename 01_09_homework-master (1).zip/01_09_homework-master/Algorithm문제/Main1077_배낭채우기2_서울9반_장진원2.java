import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main1077_배낭채우기2_서울9반_장진원2 {
	public static class gem{
		int price;
		int weight;

		public gem(int weight ,int price) {
			this.price = price;
			this.weight = weight;
		}
	}

	public static gem[] list;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String[] s = br.readLine().split(" ");
		int N = Integer.parseInt(s[0]);
		int W = Integer.parseInt(s[1]);

		list = new gem[N+1];
		int[][] sum = new int[N+1][W+1]; // 물건, 무게

		for (int i = 1; i <= N; i++) {
			s = br.readLine().split(" "); 
			list[i] = new gem(Integer.parseInt(s[0]) ,Integer.parseInt(s[1]));
		}

		sum[0][0] = 0;

		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= W; j++) {
				if(list[i].weight > j) {
					sum[i][j] = sum[i-1][j]; 
				}else {
					int picked = sum[i-1][j-list[i].weight] + list[i].price;
					int unpicked = sum[i-1][j];
					
					sum[i][j] = picked < unpicked ? unpicked : picked;
				}
			}
		}
		
		for (int i = 0; i < N+1; i++) {
			System.out.println(Arrays.toString(sum[i]));
		}

		System.out.println(sum[N][W]);
	}
}
