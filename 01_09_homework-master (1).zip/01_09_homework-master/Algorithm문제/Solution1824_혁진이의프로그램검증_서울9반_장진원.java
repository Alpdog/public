import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class Solution1824_혁진이의프로그램검증_서울9반_장진원 {
	static int[] dx = {0,1,0,-1};
	static int[] dy = {-1, 0, 1, 0};
	static int R,C;
	static char[][] map;
	static int[][] chk;
	static Queue<Location> queue;
	
	public static class Location{
		int row;
		int col;
		int dir;
		int memory;
		
		public Location(int row, int col, int dir, int memory) {
			this.row = row;
			this.col = col;
			this.dir = dir;
			this.memory = memory;
		}
	}

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1824.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			R = Integer.parseInt(s[0]);
			C = Integer.parseInt(s[1]);
			
			map = new char[R][C];
			chk = new int[R][C];
			for (int i = 0; i < R; i++) {
				String temp = br.readLine();
				for (int j = 0; j < C; j++) {
					map[i][j] = temp.charAt(j);
					chk[i][j] = 60;
				}
			}
			
			queue = new LinkedList<>();
			
			if(map[0][0] != '@')
				put(0,0, 1, 0);
			else {
				System.out.println("#" + testCase + " YES");
				continue;
			}
			
			while(!queue.isEmpty()) {
				Location current = queue.poll();
				
				if(map[current.row][current.col] == '@') {
					System.out.println("#" + testCase + " YES");
					break;
				}
				
				if(chk[current.row][current.col] == 0) {
					System.out.println("#" + testCase + " NO");
					break;
				}
				
				chk[current.row][current.col]--;
				put(current.row, current.col, current.dir, current.memory);
			}
		}
	}

	private static void put(int row, int col, int dir, int mem) {
		switch (map[row][col]) {
		case '0': case '1': case '2': case '3': case '4': case '5':
		case '6': case '7': case '8': case '9':
			mem = map[row][col]-'0';
			break;
		case '<':
			dir = 3;
			break;
		case '>':
			dir = 1;
			break;
		case '^':
			dir = 0;
			break;
		case 'v':
			dir = 2;
			break;
		case '_':
			if(mem == 0)
				dir = 1;
			else
				dir = 3;
			break;
		case '|':
			if(mem == 0)
				dir = 2;
			else
				dir = 0;
			break;
		case '?':
			for (int i = 0; i < 4; i++) {
				int ny = row+dy[i];
				int nx = col+dx[i];
				if(nx >= C)
					nx = 0;
				if(nx < 0)
					nx = C-1;
				if(ny >= R)
					ny = 0;
				if(ny <0)
					ny = R-1;
				queue.offer(new Location(ny, nx, i, mem));
			}
			return;
		case '.':
			break;
		case '+':
			if(mem != 15)
				mem = mem +1;
			else
				mem = 0;
			break;
		case '-':
			if(mem != 0)
				mem = mem -1;
			else
				mem = 15;
			break;
		}
		
		int ny = row + dy[dir];
		int nx = col + dx[dir];
		if(nx >= C)
			nx = 0;
		if(nx < 0)
			nx = C-1;
		if(ny >= R)
			ny = 0;
		if(ny <0)
			ny = R-1;
		queue.offer(new Location(ny, nx, dir, mem));
		
	}

}
