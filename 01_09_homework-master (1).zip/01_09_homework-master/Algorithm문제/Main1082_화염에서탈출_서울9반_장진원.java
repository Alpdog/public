import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class Main1082_화염에서탈출_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String[] s = br.readLine().split(" ");
		
		int R = Integer.parseInt(s[0]);
		int C = Integer.parseInt(s[1]);
		char[][] map = new char[R][C];
		Queue<int[]> queue = new LinkedList<>();
		int[] dx = {0,1,0,-1};
		int[] dy = {-1,0,1,0};
		int[] temp1 = new int[2];
		int fireCounter = 0;
		for (int i = 0; i < R; i++) {
			String temp = br.readLine();
			for (int j = 0; j < C; j++) {
				map[i][j] = temp.charAt(j);
				if(map[i][j] == 'S')
					temp1 = (new int[] {i,j});
				else if(map[i][j] == '*') {
					queue.offer(new int[] {i,j});
					fireCounter++;
				}
			}
		}

		map[temp1[0]][temp1[1]] = 'X';
		queue.offer(temp1);
		int knightCounter = 1;
		int min = 0;
		boolean flag = false;
		aaa:while(true) {
			int fire = fireCounter;
			fireCounter = 0;
			while(fire > 0) {
				fire--;
				int[] temp = queue.poll();
				for (int i = 0; i < dy.length; i++) {
					int nx = temp[1] + dx[i];
					int ny = temp[0] + dy[i];
					
					if(nx < 0 || ny < 0 || nx >= C || ny >= R ||
							map[ny][nx] == 'X' || map[ny][nx] == 'D' || map[ny][nx] == '*')
						continue;
					
					map[ny][nx] = '*';
					fireCounter++;
					queue.offer(new int[] {ny, nx});
				}
			}
			
			if(knightCounter == 0)
				break;
			int knight = knightCounter;
			knightCounter = 0;
			min++;
			while(knight > 0) {
				knight--;
				int[] temp = queue.poll();
				for (int i = 0; i < dy.length; i++) {
					int nx = temp[1] + dx[i];
					int ny = temp[0] + dy[i];
					
					if(nx < 0 || ny < 0 || nx >= C || ny >= R ||
							map[ny][nx] == 'X' || map[ny][nx] == '*')
						continue;
					
					if(map[ny][nx] == 'D') {
						flag = true;
						break aaa;
					}
					
					knightCounter++;
					map[ny][nx] = 'X';
					queue.offer(new int[] {ny, nx});
				}
			}
		}

		if(flag == true)
			System.out.println(min);
		else
			System.out.println("impossible");
	}

}
