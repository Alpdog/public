import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution5656_벽돌깨기_서울9반_장진원 {
	static int H, W, N, max;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input5656.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <=T; testCase++) {
			String[] s = br.readLine().split(" ");
			N  =Integer.parseInt(s[0]);
			W  =Integer.parseInt(s[1]);
			H  =Integer.parseInt(s[2]);
			max = 9999;
			int[][] map = new int[H][W];

			for (int i = 0; i < H; i++) {
				s = br.readLine().split(" ");
				for (int j = 0; j < W; j++)
					map[i][j] = Integer.parseInt(s[j]);
			}

			for (int i = 0; i < W; i++) {
				for (int j = 0; j < H; j++) {
					if(map[j][i] != 0) {
						int[][] tempMap = new int[H][W];
						for (int k = 0; k < H; k++) {
							for (int l = 0; l < W; l++) {
								tempMap[k][l] = map[k][l];
							}
						}

						tempMap = delete(j,i, map[j][i], tempMap);
						tempMap = drop(tempMap);
						DFS(j,i, 1, tempMap);
						break;
					}
				}
			}
			
			System.out.println("#"+ testCase + " " + max);
		}
	}

	private static int[][] drop(int[][] tempMap2) {
		for (int i = 0; i < W; i++) {
			for (int j = H-2; j >= 0; j--) {
				if(tempMap2[j+1][i] == 0) {
					int index = j;
					while(index+1 != H && tempMap2[index+1][i] == 0) {
						index++;
					}
					tempMap2[index][i] = tempMap2[j][i];
					tempMap2[j][i] = 0;
				}
			}
		}

		return tempMap2;
	}

	private static void DFS(int row, int col, int counter, int[][] preMap) {
		if(counter == N) {
			int temp1 = 0;
			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++) {
					if(preMap[i][j] != 0)
						temp1++;
				}
			}
			if(max > temp1)
				max = temp1;
			return;
		}

		boolean flag = false;
		for (int i = 0; i < W; i++) {
			for (int j = 0; j < H; j++) {
				if(preMap[j][i] != 0) {
					int[][] tempMap = new int[H][W];
					for (int k = 0; k < H; k++) {
						for (int l = 0; l < W; l++) {
							tempMap[k][l] = preMap[k][l];
						}
					}

					tempMap = delete(j,i, preMap[j][i], tempMap);
					tempMap = drop(tempMap);
					flag = true;
					DFS(j,i, counter+1, tempMap);
					break;
				}
			}
		}
		
		if(flag == false)
			max = 0;
	}

	private static int[][] delete(int row, int col, int length, int[][] preMap) {
		if(row < 0 || row > H-1 || col < 0|| col > W-1)
			return preMap;
		
		preMap[row][col] = 0;
		for (int i = row+1; i < row+length; i++) {
			if(i >= H)
				break;
			
			if(preMap[i][col] == 1)
				preMap[i][col] = 0;
			else if(preMap[i][col] > 1)
				preMap = delete(i,col, preMap[i][col], preMap);
		}
		for (int i = row-1; i > row - length; i--) {
			if(i < 0)
				break;
			if(preMap[i][col] == 1)
				preMap[i][col] = 0;
			else if(preMap[i][col] > 1)
				preMap = delete(i,col, preMap[i][col], preMap);
		}
		for (int i = col+1; i < col+length; i++) {
			if(i >= W)
				break;
			if(preMap[row][i] == 1)
				preMap[row][i] = 0;
			else if(preMap[row][i] > 1)
				preMap = delete(row,i, preMap[row][i], preMap);
		}
		for (int i = col-1; i >col-length; i--) {
			if(i < 0)
				break;
			if(preMap[row][i] == 1)
				preMap[row][i] = 0;
			else if(preMap[row][i] > 1)
				preMap = delete(row,i, preMap[row][i], preMap);
		}

		return preMap;
	}
}
