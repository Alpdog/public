import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class Solution1953_탈주범검거_서울9반_장진원 {
	static int[][] map;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1953.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			int N = Integer.parseInt(s[0]);
			int M = Integer.parseInt(s[1]);
			int R = Integer.parseInt(s[2]);
			int C = Integer.parseInt(s[3]);
			int L = Integer.parseInt(s[4]);
			map = new int[N][M];
			boolean[][] chk = new boolean[N][M];
			
			for (int i = 0; i < N; i++) {
				s = br.readLine().split(" ");
				for (int j = 0; j < M; j++)
					map[i][j] = Integer.parseInt(s[j]);
			}
			
			Queue<int[]> queue = new LinkedList<>();
			queue.offer(new int[] {R,C,map[R][C]});
			L--;
			chk[R][C] = true;
			
			int[] dx = {0,1,0,-1};
			int[] dy = {-1,0,1,0};
			while(L > 0) {
				int list = queue.size();
				while(list != 0) {
					list--;
					int[] temp = queue.poll();
					
					for (int j = 0; j < dx.length; j++) {
						int nx = temp[1] + dx[j]; 
						int ny = temp[0] + dy[j];
						
						if(nx < 0|| ny < 0 || nx > M-1 || ny > N-1 || map[ny][nx] == 0||
								chk[ny][nx] == true || connected(temp[0], temp[1], ny, nx,j) == false)
							continue;
						
						queue.offer(new int[] {ny,nx,map[ny][nx]});
						chk[ny][nx] = true;
					}
				}
				L--;
			}
			
			int answer = 0;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
					if(chk[i][j] == true)
						answer++;
				}
			}
			System.out.println("#" + testCase + " " + answer);
		}
	}

	private static boolean connected(int curR, int curC, int ny, int nx, int dir) {
		switch (map[curR][curC]) {
		case 1:
			if(dir == 0 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 5 || map[ny][nx] == 6))
				return true;
			else if(dir == 1 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 6 || map[ny][nx] == 7))
				return true;
			else if(dir == 2 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 4 || map[ny][nx] == 7))
				return true;
			else if(dir == 3 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 4 || map[ny][nx] == 5))
				return true;
			break;
		case 2:
			if(dir == 0 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 5 || map[ny][nx] == 6))
				return true;
			else if(dir == 2 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 4 || map[ny][nx] == 7))
				return true;
			break;
		case 3:
			if(dir == 1 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 6 || map[ny][nx] == 7))
				return true;
			else if(dir == 3 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 4 || map[ny][nx] == 5))
				return true;
			break;
		case 4:
			if(dir == 0 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 5 || map[ny][nx] == 6))
				return true;
			else if(dir == 1 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 6 || map[ny][nx] == 7))
				return true;
			break;
		case 5:
			if(dir == 2 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 4 || map[ny][nx] == 7))
				return true;
			else if(dir == 1 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 6 || map[ny][nx] == 7))
				return true;
			break;
		case 6:
			if(dir == 2 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 4 || map[ny][nx] == 7))
				return true;
			else if(dir == 3 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 4 || map[ny][nx] == 5))
				return true;
			break;
		case 7:
			if(dir == 0 && (map[ny][nx] == 1 || map[ny][nx] == 2 || map[ny][nx] == 5 || map[ny][nx] == 6))
				return true;
			else if(dir == 3 && (map[ny][nx] == 1 || map[ny][nx] == 3 || map[ny][nx] == 4 || map[ny][nx] == 5))
				return true;
			break;
		}
		return false;
	}

}
