import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution4530_극한의청소작업_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input4530.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			long temp = 0;
			if(s[0].charAt(0) == '-') {
				for (int i = 1; i < s[0].length(); i++) {
					if((s[0].charAt(i) - '0') >= 5) {
						temp += (s[0].charAt(i) - '0'-1)*Math.pow(9, s[0].length()-i-1);
					}else
						temp += (s[0].charAt(i) - '0')*Math.pow(9, s[0].length()-i-1);
				}
				temp *= -1;
			}else {
				for (int i = 0; i < s[0].length(); i++) {
					if((s[0].charAt(i) - '0') >= 5) {
						temp += (s[0].charAt(i) - '0'-1)*Math.pow(9, s[0].length()-i-1);
					}else
						temp += (s[0].charAt(i) - '0')*Math.pow(9, s[0].length()-i-1);
				}
			}



			long temp2 = 0;
			if(s[1].charAt(0) == '-') {
				for (int i = 1; i < s[1].length(); i++) {
					if((s[1].charAt(i) - '0') >= 5) {
						temp2 += (s[1].charAt(i) - '0'-1)*Math.pow(9, s[1].length()-i-1);
					}else
						temp2 += (s[1].charAt(i) - '0')*Math.pow(9, s[1].length()-i-1);
				}
				temp2 *= -1;
			}else {
				for (int i = 0; i < s[1].length(); i++) {
					if((s[1].charAt(i) - '0') >= 5) {
						temp2 += (s[1].charAt(i) - '0'-1)*Math.pow(9, s[1].length()-i-1);
					}else
						temp2 += (s[1].charAt(i) - '0')*Math.pow(9, s[1].length()-i-1);
				}
			}

			if((s[0].charAt(0) == '-' && s[1].charAt(0) != '-') || (s[0].charAt(0) != '-' && s[1].charAt(0) == '-'))
				System.out.println("#" + testCase + " " + (temp2-temp-1));
			else
				System.out.println("#" + testCase + " " + (temp2-temp));
		}

	}

}
