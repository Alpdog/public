
public class bitShift {

	public static void main(String[] args) {
		int a = 27;
		
		
		
		System.out.println(a>>(3-1) & (1));

	}

}
