import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *  (1) 요구사항
 *  	한 방향으로 연속적으로 5알이 놓인 경우를 찾기
 *		(6알 이상은 불가)
 *  (2) 입력
 *  	19x19 바둑판에 검은색 1, 흰색 2, 빈 칸 0으로 나타내어지는 바둑판 상태. 처음 시작이 1~ 임.
 *  
 *  (3) 처리
 *   	DFS를 이용하여 4방향으로 탐색(0130, 0300, 0430, 0600) + chk배열을 이용하여 해당 방향으로는 더 이상 탐색하지 않도록 조절(0130으로 한번 하면 더이상 그 방향으로는 하지 않음)
 *      + 15행 15열까지만 탐색
 *      
 *  (4) 출력
 *   검정 승리 : 1, 흰색 승리 : 2, 무승부 : 0
 *   승리한 지점의 가장 왼쪽 위쪽의 바둑알 좌표 출력
 * */
public class Main1733_오목_서울9반_장진원 {
	static int[][] map;
	static int[][] chk;
	static int[] dx = {-1,1,1,0};
	static int[] dy = {1,0,1,1};
	static boolean finished;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int N = 19+1;
		map = new int[N][N];
		chk = new int[N][N];

		for (int i = 1; i < N; i++) {
			String[] s = br.readLine().split(" ");
			for (int j = 1; j < N; j++)
				map[i][j] = Integer.parseInt(s[j-1]);
		}

		finished = false;
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				if(finished == false && map[i][j] != 0) {
					for (int k = 0; k < dx.length; k++) {
						int nx = j + dx[k];
						int ny = i + dy[k];

						if(nx < 1 || ny < 1 || nx > 19 || ny > 19 ||
								map[i][j] != map[ny][nx] || (chk[ny][nx] >>k & 1) == 1)
							continue;

						chk[i][j] = chk[i][j] | (1<<k);
						DFS(ny,nx,k,map[i][j], 1, false);
					}
				}
			}
		}
		
		if(finished == false)
			System.out.println(0);
	}
	private static void DFS(int currentRow, int currentCol, int dir, int type, int counter, boolean endChk) {
		if(endChk == true) {
			if(counter== 5) {
				if(dir != 0) {
					System.out.println(type);
					System.out.println((currentRow - 4*dy[dir]) + " " + (currentCol - 4*dx[dir]));
				}else {
					System.out.println(type);
					System.out.println(currentRow + " " + currentCol);
				}

				finished = true;
			}
			return;
		}
		
		if(finished == false && map[currentRow][currentCol] == type) {
			int nx = currentCol + dx[dir];
			int ny = currentRow + dy[dir];

			if((nx == 20 || ny == 20) && map[currentRow][currentCol] == type)
				DFS(currentRow,currentCol,dir,map[currentRow][currentCol], counter+1, true);

			if(finished == true || nx < 1 || ny < 1 || nx > 19 || ny > 19 ||
					(chk[ny][nx] >>dir & 1) == 1)
				return;

			if(type != map[ny][nx]) {
				DFS(currentRow,currentCol,dir,map[currentRow][currentCol], counter+1, true);
				return;
			}

			chk[currentRow][currentCol] = chk[currentRow][currentCol] | (1<<dir);
			DFS(ny,nx,dir,map[currentRow][currentCol], counter+1, false);
		}
	}

}
