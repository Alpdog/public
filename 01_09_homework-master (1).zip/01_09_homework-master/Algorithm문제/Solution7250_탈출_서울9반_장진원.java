import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class Solution7250_탈출_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input7250.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			int N = Integer.parseInt(s[0]);
			int M = Integer.parseInt(s[1]);
			int K = Integer.parseInt(s[2]);
			
			char[][] map = new char[N][M];
			Queue<int[]> sQ = new LinkedList<>();
			Queue<int[]> fQ = new LinkedList<>();
			Queue<int[]> vQ = new LinkedList<>();
			
			for (int i = 0; i < N; i++) {
				String temp = br.readLine();
				for (int j = 0; j < M; j++) {
					map[i][j] = temp.charAt(j);
					if(map[i][j] == 'S') {
						int[] k = {i,j,0};
						sQ.offer(k);
					}else if(map[i][j] == 'F') {
						int[] k = {i,j};
						fQ.offer(k);
					}else if(map[i][j] == 'V') {
						int[] k = {i,j};
						vQ.offer(k);
					}
				}
			}
			
			
			
		}
	}

}
