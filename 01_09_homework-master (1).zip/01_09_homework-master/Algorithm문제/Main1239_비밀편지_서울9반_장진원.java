import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main1239_비밀편지_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int N = Integer.parseInt(br.readLine());
		
		int[] list = {0, 15, 19, 28, 38, 41, 53, 58};
		char[] word = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
		String decoded = "";
		String s = br.readLine();
		int temp = 0;
		
		aaa: for (int i = 0; i < N*6; i++) {
			temp += (int) ((s.charAt(i)-'0')* Math.pow(2, (5-i%6)));
			
			if(i%6 == 5) {
				for (int k = 0; k < list.length; k++) {
					if(temp == list[k]) {
						decoded += word[k];
						temp = 0;
						continue aaa;
					}
				}
				
				 for (int j = 0; j < list.length; j++) {
					 int result = list[j] ^ temp;
					
					switch (result) {
					case 1: case 2: case 4: case 8: case 16: case 32:
						if(temp == 0)
							decoded += word[0];
						else 
							decoded += word[j];
						temp = 0;
						continue aaa;
					default:
						break;
					}
				}
				 System.out.println(i/6+1);
				 return;
			}
		}
		
		System.out.println(decoded);
	}

}
