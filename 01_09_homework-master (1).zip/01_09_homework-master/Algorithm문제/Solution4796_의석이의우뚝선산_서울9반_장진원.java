import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
/**
 * 우뚝 선 산의 조건에 해당하는 것의 갯수를 찾아야 한다.
 * = 올라가다가 내려가는 형태의 산
 * 
 *  (1) 입력
 *  테스트 케이스 T
 *  산의 각 지점 높이의 개수 N (3<= N <= 50000)과 각 지점의 높이 h(1<= h <= 10^9) N개. 단, 중복되는 h는 없다.
 *  
 *  (2) 처리
 *	 입력을 받으면서 이전 높이보다 작아지는 부분을 찾아서 저장한다.(boolean[] counter = 해당 부분 인덱스. N크기 배열 하나 선언)
 *	이후 true인 부분에 대해 왼쪽(올라오는 부분)의 길이 l, 오른쪽(내려가는 부분)의 길이 r을 구하고
 *  r*l을 하면 해당 부분에서 나올 수 있는 우.선.산 갯수를 구할 수 있다.
 *  이 값들을 answer += r*l을 해준다.
 *  
 *  (3) 출력
 *  answer(우.선.산 경우의 수들의 합)을 출력
 * */
public class Solution4796_의석이의우뚝선산_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input4796.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <= T; testCase++) {
			int N  = Integer.parseInt(br.readLine());

			String[] s = br.readLine().split(" ");
			int answer = 0;
			int l = 0;
			int r = 0;
			int check = 0;
			for (int j = 1; j < s.length; j++) {
				if((check == 1) && (Integer.parseInt(s[j-1]) < Integer.parseInt(s[j]))) {
					l++;
				}else if((check == 0) && (Integer.parseInt(s[j-1]) < Integer.parseInt(s[j]))) {
					answer += r*l;
					l = 1;
					r = 0;
					check = 1;
				}else if((check == 1) && (Integer.parseInt(s[j-1]) > Integer.parseInt(s[j]))) {
					r=1;
					check = 0;
				}else if((check == 0) && (Integer.parseInt(s[j-1]) > Integer.parseInt(s[j]))) {
					r++;
				}
				
				if(j == N-1) {
					answer += r*l;
				}
			}
			System.out.println("#" + testCase + " " + answer);
		}
	}
}
