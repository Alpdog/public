import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Solution3378_스타일리쉬들여쓰기_서울9반_장진원 {
	static int p, q;
	static int R, a, b, C, c, d, S, e, f;
	static String temp;
	static ArrayList<int[]> list;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input3378.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String[] s;
		int T = Integer.parseInt(br.readLine());

		for (int testCase =1; testCase <= T; testCase++) {
			s = br.readLine().split(" ");
			p = Integer.parseInt(s[0]);
			q = Integer.parseInt(s[1]);
			R = -1;a = 0;b = 0;
			C = -1;c = 0;d = 0;
			S = -1;e = 0;f = 0;
			temp = new String();
			list = new ArrayList<>();

			for (int j = 1; j <= 20; j++) {
				for (int k = 1; k <= 20 ; k++) {
					for (int l = 1; l <= 20; l++)
						list.add(new int[] {j,k,l});
				}
			}

			for (int i = 0; i < p; i++) {
				temp = br.readLine();
				int index = 0;
				while(temp.charAt(index) == '.')
					index++;

				if(a != b || c != d || e != f) {
					for (int j = 0; j < list.size(); j++) {
						if(index != ((list.get(j)[0])*(a-b) + list.get(j)[1]*(c - d) + list.get(j)[2]*(e - f)))
							list.remove(j--);
					}
				}
				count(index);
			}

			R = list.get(0)[0];
			C = list.get(0)[1];
			S = list.get(0)[2];
			if(list.size() != 1) {
				for (int i = 1; i < list.size(); i++) {
					if(list.get(i)[0] != R)
						R = -1;
					if(list.get(i)[1] != C)
						C = -1;
					if(list.get(i)[2] != S)
						S = -1;
				}
			}

			System.out.print("#" + testCase);
			
			for (int i = p; i < p+q; i++) {
				temp = br.readLine();
				int index = 0;

				boolean flag = false;
				int temp2 = (list.get(0)[0]*(a-b) + list.get(0)[1]*(c - d) + list.get(0)[2]*(e - f));
				for (int j = 1; j < list.size(); j++) {
					if(temp2 != (list.get(j)[0]*(a-b) + list.get(j)[1]*(c - d) + list.get(j)[2]*(e - f))) {
						System.out.print(" -1");
						flag = true;
						break;
					}
				}
				if(flag == false)
					System.out.print(" " + temp2);
				
				count(index);
			}
			System.out.println();
		}
	}
	
	public static void count(int index) {
		for (int j = index; j < temp.length(); j++) {
			switch (temp.charAt(j)) {
			case '(':
				a++;
				break;
			case ')':
				b++;
				break;
			case '{':
				c++;
				break;
			case '}':
				d++;
				break;
			case '[':
				e++;
				break;
			case ']':
				f++;
				break;
			}
		}
	}
}
