import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main1350_최대신장트리_서울9반_장진원 {
	static int[] parent;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String[] s = br.readLine().split(" ");
		
		int N = Integer.parseInt(s[0]);
		int M = Integer.parseInt(s[1]);
		int[][] map = new int[N+1][N+1];
		boolean[] chk = new boolean[N+1];
		parent = new int[N+1];
		for (int i = 0; i < M; i++) {
			s = br.readLine().split(" ");
			int row = Integer.parseInt(s[0]);
			int col = Integer.parseInt(s[1]);
			int number = Integer.parseInt(s[2]);
			
			if(map[row][col] > number*-1) {
				map[row][col] = number*-1;
				map[col][row] = number*-1;
			}
		}
		
		int[] list = new int[N];
		list[0] = 1;
		chk[1] = true;
		chk[0] = true;
		
		int sum = 0;
		int picked = 1;
		while(picked != N) {
			int counter = picked;
			int min = 0;
			int minStart = 0;
			int minEnd = 0;
			for (int i = 0; i < counter; i++) {
				for (int j = 1; j <= N; j++) {
					if(map[list[i]][j] != 0 && chk[j] != true && map[list[i]][j] < min) {
						min = map[list[i]][j];
						minStart = list[i];
						minEnd = j;
					}
				}
			}

			chk[minEnd] = true;
			sum += map[minStart][minEnd];
			map[minStart][minEnd] = 0;
			map[minEnd][minStart] = 0;
			picked++;
			list[picked-1] = minEnd;
		}

		System.out.println(sum*-1);
	}
}
