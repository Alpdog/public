import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Solution4050_재관이의대량할인_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int N = Integer.parseInt(br.readLine());
		int [] price = new int[N];
		int sum = 0;
		for (int i = 0; i < N; i++)
			price[i] = Integer.parseInt(br.readLine());
		
		Arrays.sort(price);
		
		int cnt = 0;
		for (int i = N-1; i >= 0; i--) {
			if(cnt == 2) {
				cnt = 0;
				continue;
			}
			sum += price[i];
			cnt++;
		}
		
		System.out.println(sum);
	}

}
