import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution3501_순환소수짧게표현하기_서울9반_장진원 {
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input3501.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T=Integer.parseInt(br.readLine());
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] temp = br.readLine().split(" ");
			int p = Integer.parseInt(temp[0]);
			int q = Integer.parseInt(temp[1]);

			if(p%q == 0) {
				System.out.println("#" + testCase + " " + (p/q));
				continue;
				        }
			int check = q;
			int tenCounter = 0;
			while(true) {
				if(check%10 == 0) {
					tenCounter++;
					check /= 10;
					                    continue;
					                }
				             else if(check%2 ==0) {
					check /= 2;
					                    continue;
					                }
				                else if(check%5 == 0) {
					                    check /= 5;
					                    continue;
					                }
				                break;
				            }
			 
			            String s = "";
			             
			            if(check == 1) {
				                System.out.println("#" + testCase + " " + ((double)p/(double)q));
				            }else {
					                s += (p/q) + ".";
					                int index = tenCounter;
					                String half = "";
					                while(index != 0) {
						                    index--;
						                    p *= 10;
						                    if(p>=q) {
							                        s += (p/q);
							                        p -= (p/q)*q;
							                    }else {
								                        s += "0";
								                    }
						                }
					                 
					                int length = 0;
					                while(true) {
						                    length++;
						                    p*= 10;
						                    if(p>=q) {
							                        half += (p/q);
							                        p -= (p/q)*q;
							                    }else {
								                        half += "0";
								                    }
						                     
						                    if(((length & 1) == 0) && (half.charAt(length-1) == half.charAt(length/2-1)) && half.substring(0, length/2).equals(half.substring(length/2,length)))
							                        break;
						                }
					 
					                System.out.println("#" + testCase + " " + s +"(" + half.substring(0, length/2) + ")");
					            }
			        }
	}
}
