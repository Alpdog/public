import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main2283_RGB마을_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] s;
		int N = Integer.parseInt(br.readLine());
		
		int[][] price = new int[N][3];
		
		for (int i = 0; i < N; i++) {
			s = br.readLine().split(" ");
			price[i][0] = Integer.parseInt(s[0]);
			price[i][1] = Integer.parseInt(s[1]);
			price[i][2] = Integer.parseInt(s[2]);
		}
		
		int[][] sum = new int[N][3];
		sum[0][0] = price[0][0];
		sum[0][1] = price[0][1];
		sum[0][2] = price[0][2];
		
		for (int i = 1; i < N; i++) {
			for (int j = 0; j < 3; j++) {
				if(j == 0) {
					sum[i][0] = Math.min(sum[i-1][1]+price[i][0], sum[i-1][2]+price[i][0]);
				}else if(j==1) {
					sum[i][1] = Math.min(sum[i-1][0]+price[i][1], sum[i-1][2]+price[i][1]);
				}else if(j == 2) {
					sum[i][2] = Math.min(sum[i-1][0]+price[i][2], sum[i-1][1]+price[i][2]);
				}
			}
		}
		int minCost = Math.min(Math.min(sum[N-1][0],sum[N-1][1]), sum[N-1][2]);
		System.out.println(minCost);
	}

}
