import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main2097_지하철_서울9반_장진원 {
	static boolean[] chk;
	static int[][] map;
	static int N, M;
	static int INF = 1000000;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input2097.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] s = br.readLine().split(" ");
		N  = Integer.parseInt(s[0]);
		M  = Integer.parseInt(s[1]);

		map = new int[N+1][N+1];
		chk = new boolean[N+1];

		for (int i = 1; i <= N; i++) {
			s = br.readLine().split(" ");
			for (int j = 1; j <= N; j++) {
				map[i][j] = Integer.parseInt(s[j-1]);
			}
		}
		
		int[] path = new int[N+1];
		int[] dist = new int[N+1];
		for (int i = 1; i <= N; i++)
			dist[i] = INF;
		dist[1] = 0;
		
		for (int k = 1; k <= N; k++) {
			for (int i = 1; i <= N; i++) {
				for (int j = 1; j <= N; j++) {
					if(dist[j] > dist[i] + map[i][j]) {
						dist[j] = dist[i] + map[i][j];
						path[j] = i;
					}
				}
			}
		}
		
		System.out.println(dist[M]);
		int i = M;
		ArrayList<Integer> list = new ArrayList<>();
		list.add(M);
		while(path[i] != 0) {
			list.add(path[i]);
			i = path[i];
		}
		
		for (int j = list.size()-1; j >= 0; j--) {
			System.out.print(list.get(j) + " ");
		}
	}
}
