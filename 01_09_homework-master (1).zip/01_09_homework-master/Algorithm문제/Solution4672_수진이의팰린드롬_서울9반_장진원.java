import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution4672_수진이의팰린드롬_서울9반_장진원 {
	static int[] counter;
	static String s;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input4672.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <= T; testCase++) {
			s = br.readLine();
			counter = new int[26];

			for (int i = 0; i < s.length(); i++)
				counter[s.charAt(i) -'a']++;

			int max = 0;
			for (int i = 0; i < counter.length; i++)
				max += sum(counter[i]);
			System.out.println("#" + testCase + " " + max);
		}
	}

	private static int sum(int length) {
		if(length == 0)
			return 0;

		return sum(length-1) + length;
	}
}
