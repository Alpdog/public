import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main1976_여행가자_서울9반_장진원 {
	static int[] parent;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int N = Integer.parseInt(br.readLine());
		int M = Integer.parseInt(br.readLine());
		parent = new int[N+1];
		
		for (int i = 0; i < parent.length; i++)
			parent[i] = i;
		
		for (int i = 1; i <= N; i++) {
			String[] s = br.readLine().split(" ");
			for (int j = i+1; j <= N; j++) {
				int temp = Integer.parseInt(s[j-1]);
				
				if(temp == 1)
					unionSet(i,j);
			}
		}
		
		String[] s = br.readLine().split(" ");
		if(M >= 1) {
			int index = findSet(Integer.parseInt(s[0]));
			
			if(M >= 2) {
				for (int i = 1; i < M; i++) {
					if(findSet(Integer.parseInt(s[i])) != index) {
						System.out.println("NO");
						return;
					}
				}
			}
		}
		
		System.out.println("YES");
	}

	private static void unionSet(int i, int j) {
			parent[findSet(i)] = findSet(j);
	}

	private static int findSet(int i) {
		if(parent[i] == i)
			return i;
		return parent[i] = findSet(parent[i]);
	}

}
