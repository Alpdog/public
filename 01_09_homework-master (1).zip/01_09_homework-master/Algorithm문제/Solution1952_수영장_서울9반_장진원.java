import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution1952_수영장_서울9반_장진원 {
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1952.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			int[] price = new int[4]; // 1day,  1month, 3month, 1year
			int[] plan = new int[13];
			int[] sum  = new int[13];
			sum[0] = 0;
			
			String[] s = br.readLine().split(" ");
			for (int i = 0; i < 4; i++)
				price[i] = Integer.parseInt(s[i]);
			s = br.readLine().split(" ");
			for (int i = 1; i <= 12; i++)
				plan[i] = Integer.parseInt(s[i-1]);
			
			for (int i = 1; i <= 12; i++) {
				int temp = plan[i]*price[0] > price[1]?
						sum[i-1] + price[1] : sum[i-1] + plan[i]*price[0];
				if(i >= 3)
					temp = (temp > (sum[i-3] + price[2]))? sum[i-3] + price[2] : temp;
				if(i==12)
					temp = (temp > (sum[i-12] + price[3]))? sum[i-12] + price[3] : temp;
				sum[i] = temp;
			}
			
			System.out.println("#" + testCase + " " + sum[12]);
		}
	}
}
