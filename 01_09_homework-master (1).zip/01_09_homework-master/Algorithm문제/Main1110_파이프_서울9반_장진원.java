import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main1110_파이프_서울9반_장진원 {
	static int[][] map;
	static int[][] reversedMap;
	static int[] chk;
	static int M, N;
	
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] s = br.readLine().split(" ");
		
		M = Integer.parseInt(s[0]);
		N = Integer.parseInt(s[1]);
		int[][] temp = new int[N][N];
		int reverseCounter =0;
		
		for (int i = 0; i < M; i++) {
			s = br.readLine().split(" ");
			int row = Integer.parseInt(s[0])-1;
			int col = Integer.parseInt(s[1])-1;
			if(temp[col][row] != 0) {
				temp[row][col] =  Integer.parseInt(s[2]);
				reverseCounter++;
			}else {
				temp[col][row] =  Integer.parseInt(s[2]);
			}
		}
		
		map = new int[N+reverseCounter][N+reverseCounter];
		int index = N;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(i==j)
					continue;
				if(temp[i][j] != 0 && temp[j][i] != 0) {
					map[i][j] = temp[i][index];
					map[j][i] = 0;
					temp[index][i] = temp[i][index];
					index++;
				}
			}
		}
		
		chk[0] = 1;
		chk = new int[N+reverseCounter];
		
		for (int i = 0; i < N+reverseCounter; i++) {
			if(map[0][i] > 0) {
				chk[i] = 2;
				DFS(i, 2);
				chk[i] = 0;
			}
		}
		
		int sum = 0;
		
		for (int i = 0; i < N; i++)
			sum += map[N-1][i];
		
		System.out.println(sum);
		
	}

	private static void DFS(int current, int cnt) {
		if(current == )
	}

}
