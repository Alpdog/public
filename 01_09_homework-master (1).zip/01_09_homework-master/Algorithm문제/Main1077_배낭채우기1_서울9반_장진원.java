import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main1077_배낭채우기1_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String[] s = br.readLine().split(" ");
		int N = Integer.parseInt(s[0]);
		int W = Integer.parseInt(s[1]);

		int[] weight = new int[N+1];
		int[] price = new int[N+1];
		int[] sum = new int[W+1];
		
		for (int i = 1; i <= N; i++) {
			s = br.readLine().split(" "); 
			weight[i] = Integer.parseInt(s[0]);
			price[i] = Integer.parseInt(s[1]);
		}
		
		sum[0] = 0;
		
		for (int i = 1; i <= W; i++) {
			for (int j = 1; j <= N; j++) {
				int temp = 0;
				if(weight[j] <= i) {
					temp = price[j] + sum[i-weight[j]];
				}
				
				if(temp > sum[i])
					sum[i] = temp;
			}
		}
		
		System.out.println(sum[W]);
	}

}
