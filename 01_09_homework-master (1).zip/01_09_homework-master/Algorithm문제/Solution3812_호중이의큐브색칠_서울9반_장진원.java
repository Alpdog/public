import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution3812_호중이의큐브색칠_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input3812.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			int X = Integer.parseInt(s[0]);
			int Y = Integer.parseInt(s[1]);
			int Z = Integer.parseInt(s[2]);
			int A = Integer.parseInt(s[3]);
			int B = Integer.parseInt(s[4]);
			int C = Integer.parseInt(s[5]);
			int N = Integer.parseInt(s[6]);
			long[] numA = new long[N];
			long[] numB = new long[N];
			long[] numC = new long[N];
			
			for (int i = 0; i < X; i++)
				numA[Math.abs(i-A)%N]++;
			for (int i = 0; i < Y; i++)
				numB[Math.abs(i-B)%N]++;
			for (int i = 0; i < Z; i++)
				numC[Math.abs(i-C)%N]++;
			
			long[] temp1 = new long[N];
			long[] temp2 = new long[N];
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++)
					temp1[(i+j)%N] += numA[i]*numB[j];
			}
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++)
					temp2[(i+j)%N] += temp1[i]*numC[j];
			}
			
			System.out.print("#" + testCase);
			for (int i = 0; i < temp2.length; i++)
				System.out.print(" " + temp2[i]);
			System.out.println();
			
		}
	}
}
