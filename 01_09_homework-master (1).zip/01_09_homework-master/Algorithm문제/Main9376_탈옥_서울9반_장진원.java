import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Main9376_탈옥_서울9반_장진원 {
	static int[] dx = {0,1,0,-1};
	static int[] dy = {-1,0,1,0};
	static int[][] chk;
	static char[][] map;
	static int h, w, answer, min;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		for (int testCase = 1; testCase <= T; testCase++) {
			String[] s = br.readLine().split(" ");
			h = Integer.parseInt(s[0]);
			w = Integer.parseInt(s[1]);

			map = new char[h][w];
			chk = new int[h][w];
			Queue<int[]> list = new LinkedList<>();
			Queue<int[]> list2 = new LinkedList<>();
			answer = 0;
			boolean flag = false;
			for (int i = 0; i < h; i++) {
				String temp = br.readLine();
				for (int j = 0; j < w; j++) {
					map[i][j] = temp.charAt(j);
					if(map[i][j] == '$' && flag == false) {
						list.offer(new int[] {i,j,0});
						chk[i][j] = 1;
						flag = true;
					}else if(map[i][j] == '$' && flag == true) {
						list2.offer(new int[] {i,j,0});
					}
				}
			}


			System.out.println(min);

		}
	}
}


/*			while(!list.isEmpty()) {
				int[] location = list.poll();

				for (int i = 0; i < dx.length; i++) {
					int nx = location[1] + dx[i]; 
					int ny = location[0] + dy[i]; 
					int doorCnt = location[2];
					if(nx < 0 || ny < 0 || nx > w-1 || ny > h-1 || chk[ny][nx] == 1 || map[ny][nx] == '*')
						continue;

					if(map[ny][nx] == '#')
						doorCnt++;
					
					if(doorCnt > answer)
						continue;
					
					if(ny == 0 || nx == 0 || ny == h-1 || nx == w-1 && (map[ny][nx]== '#' || map[ny][nx]== '.')) {
						if(doorCnt < answer)
							answer = doorCnt;
						continue;
					}
						
					list.offer(new int[] {ny,nx,doorCnt});
				}
			}
			
			while(!list2.isEmpty()) {
				int[] location = list2.poll();
				if(chk[location[0]][location[1]] == 1)
					
				for (int i = 0; i < dx.length; i++) {
					int nx = location[1] + dx[i]; 
					int ny = location[0] + dy[i]; 
					int doorCnt = location[2];
					if(nx < 0 || ny < 0 || nx > w-1 || ny > h-1 || chk[ny][nx] == 1 || map[ny][nx] == '*')
						continue;

					if(map[ny][nx] == '#')
						doorCnt++;
					
					if(doorCnt > min)
						continue;
					
					list.offer(new int[] {ny,nx,doorCnt});
				}
				
				
			}*/
