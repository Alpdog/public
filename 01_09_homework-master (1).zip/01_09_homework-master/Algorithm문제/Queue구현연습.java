import java.util.Arrays;
import java.util.Scanner;

public class Queue구현연습 {
	public static class Queue {
		int[] queue;
		int front;
		int rear;
		int size;
		public Queue(int N) {
			this.size = N;
			this.queue = new int[size];
			this.front = 0;
			this.rear = 0;
		}
		
		public boolean isEmpty() {
			if(rear == front)
				return true;
			return false;
		}
		
		public boolean isFull() {
			if((rear+1)%size == front)
				return true;
			return false;
		}
		
		public int poll() {
			if(this.isEmpty())
				return 0;
			
			int value = queue[front];
			queue[front] = 0;
			front++;
			if(front == size)
				front = 0;
			return value;
		}
		
		public void offer(int N) {
			if(this.isFull())
				return;
			
			queue[rear++] = N;
			if(rear == size)
				rear = 0;
		}
		
		public void show() {
			for (int i : queue) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Queue q = new Queue(sc.nextInt());
		
		for (int i = 1; i < 10; i++) {
			q.offer(i);
			q.show();
		}
		
		for (int i = 0; i < 15; i++) {
			System.out.println(q.poll());
			q.show();
		}
	}

}
