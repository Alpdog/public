package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution1289_원재의메모리복구하기_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T;
	
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution1289_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			String line = sc.next();
			
			char[] data = line.toCharArray();
			
			int cnt = 0;

			if(data[0] != 0) cnt++;
			
			for (int i = 1; i < data.length-1; i++) {
				if(data[i] != data[i+1]) cnt++;
			}
			
			
//			String loaded = "0";
//			int counter = 0;
//			
//			String temp = sc.next();
//			String[] Origin = new String [temp.length()];
//			
//			Origin = temp.split(""); //배열에 한글자씩 저장하기
//
//			for (int i = 0; i < Origin.length; i++) {
//				if(Origin[i].equals("0") && loaded.equals("1")) {
//					counter++;
//					if(loaded == "0")
//						loaded = "1";
//					else
//						loaded = "0";
//				}
//				else if(Origin[i].equals("1") && loaded.equals("0")) {
//					counter++;
//					if(loaded == "0")
//						loaded = "1";
//					else
//						loaded = "0";
//				}
//				else
//					continue;	
			System.out.println("#"+test_case+ " " + cnt);
			}

	}
}
		