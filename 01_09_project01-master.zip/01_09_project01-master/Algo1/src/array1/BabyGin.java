package array1;

import java.util.Scanner;

public class BabyGin {
	static int[] numbers = new int [10];

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < 6; i++)
			numbers[sc.nextInt()]++;

		tripletFinder();
	}

	private static void tripletFinder() {
		int tripletCnt = 0;
		for (int i = 0;i < numbers.length; i++) {
			if(numbers[i] >= 3) {
				numbers[i--] -= 3;
				tripletCnt++;
			}
		}

		if(tripletCnt == 2) {
			System.out.println("BabyGin!");
			return;
		}
		else {
			runFinder(2-tripletCnt);
		}	
	}

	private static void runFinder(int i) {
		int runCnt = 0;

		for (int j = 0;j < numbers.length-2; j++) {
			if(numbers[j] != 0 && numbers[j+1] != 0 && numbers[j+2] != 0) {
				numbers[j]--;
				numbers[j+1]--;
				numbers[j+2]--;
				runCnt++;
				j--;
			}

			if(runCnt == i) {
				System.out.println("BabyGin!");
				return;
			}
		}

		System.out.println("Not BabyGin!");
	}
}
