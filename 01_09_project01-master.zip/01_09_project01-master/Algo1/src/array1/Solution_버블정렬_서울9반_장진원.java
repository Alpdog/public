package array1; //제출시 삭제

import java.util.Arrays;
import java.util.Scanner;

public class  Solution_버블정렬_서울9반_장진원 { //제출시 Solution 만 남기고 지우기

	public static void main(String[] args) throws Exception{
		
		int[] data = {55, 7, 78, 12, 42};
		
		for (int i = data.length -1 ; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				if(data[j] >= data[j+1]) {
					int temp = data[j];
					data[j] = data[j+1];
					data[j+1] = temp;
				}
			}
		}
		
//		for (int j = 0; j < data.length-1; j++) {
//			for (int i = 0; i < data.length-1-j; i++) {
//				if(data[i] >= data[i+1]) {
//					int temp = data[i];
//					data[i] = data[i+1];
//					data[i+1] = temp;
//					}
//			}
//
//		}

		System.out.println("result = "  + Arrays.toString(data));
		
	}
}