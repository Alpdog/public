package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution5431_민석이의과제체크하기_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T, N, K;

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution5431_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			N = sc.nextInt();
			K = sc.nextInt();
			int[] chk = new int[N+1];
			
			for (int i = 1; i <= K; i++) {
				chk[sc.nextInt()]++;
			}
			
			System.out.print("#" + test_case + " ");
			
			for (int i = 1; i < chk.length; i++) {
				if(chk[i] == 0) System.out.print(i + " ");
			}
			
			System.out.println();
		}
	}
}