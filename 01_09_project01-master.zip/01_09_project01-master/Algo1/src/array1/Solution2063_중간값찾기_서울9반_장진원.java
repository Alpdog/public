package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution2063_중간값찾기_서울9반_장진원 { //제출시 Solution 만 남기고 지우기


	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution2063_input.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int numbers = sc.nextInt();
		int [] array = new int [numbers];

		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}


		for (int i = array.length -1 ; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				if(array[j] >= array[j+1]) {
					int temp = array[j];
					array[j] = array[j+1];
					array[j+1] = temp;
				}
			}
			if(i == (array.length-1)/2) {
				break;
			}
		}

		System.out.println(array[(array.length-1)/2]);
	}
}