package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution1204_최빈수구하기_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T;
	
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution1204_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			int max = 0;
			int max_score = 0;
			test_case = sc.nextInt();
			int[] score = new int[101];
			
			for (int i = 0; i < 1000; i++) {
				int temp = sc.nextInt();
				score[temp]++;
			}

			for (int i = 0; i < 101; i++) {
				if(score[i] >= max) {
					max = score[i];
					max_score = i;
				}
			}
				
			System.out.println("#"+test_case+ " " + max_score);
			}

	}
}
		