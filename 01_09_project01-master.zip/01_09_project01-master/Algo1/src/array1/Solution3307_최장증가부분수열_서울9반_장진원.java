package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution3307_최장증가부분수열_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T;
	
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution3307_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int max = 0;
			int N = sc.nextInt();
			int [] array = new int [N];
			int[] dp = new int[N];
			
			for (int i = 0; i < N; i++) {
				array[i] = sc.nextInt();
			}

			dp[0] = 1;

			for(int i=1;i<N;i++) {
			    dp[i] = 1;
			    // i 를 기준으로 인덱스 0 에서부터 i-1까지 체크한다 
			    // 길이를 기준
			    for(int j=0;j<i;j++) {
			        if (array[i] > array[j] && dp[j] + 1 > dp[i]) {
			            // 증가 수열
			            dp[i] = dp[j] + 1;
			        }
			    }

			    if (max < dp[i]) {
			        max = dp[i];
			    }

			}
			
			System.out.println("#"+test_case+ " " + max);
		}
	}
}
