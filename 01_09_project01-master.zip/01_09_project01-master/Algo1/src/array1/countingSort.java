package array1;

import java.util.Arrays;

public class countingSort {

	public static void main(String[] args) {
		int[] data = { 0, 4, 1, 3, 1, 2, 4, 1};
		int[] counts = new int[4+1];
		int[] temp = new int[data.length];

		for (int i = 0; i < data.length; i++) {
			counts[data[i]]++; 
		}
		
//		int k = 0;
//		
//		for (int i = 0; i < counts.length; i++) {
//			for (int j = 0; j < counts[i]; j++) {
//				data[k++] = i; 
//			}
//		} 이렇게 하면 연산량이 N^2 이 되므로 큰 단위의 숫자에는 적절하지 않음.
		
		for (int i = 1; i < counts.length; i++) {
			counts[i] += counts[i-1];
		}
		
		for (int i = data.length-1; i >= 0; i--) {
			counts[data[i]]--;
			temp[counts[data[i]]] = data[i];
		}
		
		System.out.println(Arrays.toString(temp));
	}

}
