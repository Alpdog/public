package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution_Gravity_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T;
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution_gravity_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int maxDistance = 0;
			int maxHeight = 0;
			int chk = 0;
			int fallingDistance = 0;
			
			int rows = sc.nextInt();
			int [] boxes = new int[rows];
			
			for (int i = 0; i < boxes.length; i++) {
				boxes[i] = sc.nextInt();
				if(boxes[i] > maxHeight) {
					maxHeight = boxes[i];
					chk = i;
				}
			}
			
			fallingDistance = rows-1;
			
			for (int i = 0; i < boxes.length; i++) {
				if(boxes[i] >= maxHeight)
					fallingDistance--;
			}
			maxDistance = (fallingDistance+1 > maxDistance) ? fallingDistance+1 : maxDistance;
	
			System.out.println("#"+test_case+ " " + maxDistance);	
		}
	}
}