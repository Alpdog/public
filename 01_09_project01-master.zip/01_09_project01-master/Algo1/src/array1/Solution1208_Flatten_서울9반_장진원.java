package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Scanner;

public class  Solution1208_Flatten_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T, dump;
	static int[] boxes = new int[100];

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution1208_input.txt"));
		Scanner sc = new Scanner(System.in);

		for(int test_case = 1; test_case <= 13; test_case++)
		{
			dump = sc.nextInt();
			
			for (int i = 0; i < 100; i++) {
				boxes[i] = sc.nextInt();
			}
			Arrays.sort(boxes);
			flat();
			System.out.println("#"+test_case + " " + (boxes[99]-boxes[0]));
		}
	}

	private static void flat() {
		if(dump == 0 || boxes[0] == boxes[99])
			return;
		
		dump--;
		boxes[99]--;
		boxes[0]++;
		Arrays.sort(boxes);		
		flat();
	}
}