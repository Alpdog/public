package array1; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution5215_햄버거다이어트_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int T;
	static int max_sum = 0;

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/Solution5215_input.txt"));
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for(int test_case = 1; test_case <= T; test_case++)
		{
			int cal_sum = 0;
			int point_sum = 0;
			int numberOfRes =0;
			int numberOfLimit = 0;

			numberOfRes = sc.nextInt();
			numberOfLimit = sc.nextInt();

			int [][] kinds = new int [numberOfRes][2];

			for (int i = 0; i < numberOfRes; i++) {
				for (int j = 0; j < 2; j++) {
					kinds[i][j] = sc.nextInt();
				}
			}

			for (int i = 0; i < numberOfRes; i++) {
				make(kinds, cal_sum, point_sum, i, numberOfRes, numberOfLimit);
			}

			System.out.println("#"+test_case+ " " + max_sum);
			max_sum = 0;
		}
	}

	private static void make(int[][] kinds, int calSum, int pointSum, int pick, int numberOfRes, int numberOfLimit) {

		if(pick >= numberOfRes) {
			max_sum = (pointSum > max_sum)? pointSum : max_sum;
			return;
		}	
		
		if(calSum + kinds[pick][1] > numberOfLimit)
			make(kinds, calSum, pointSum, pick+1,numberOfRes, numberOfLimit);
		else
			make(kinds, calSum + kinds[pick][1], pointSum + kinds[pick][0], pick+1, numberOfRes, numberOfLimit);
			make(kinds, calSum, pointSum, pick+1,numberOfRes, numberOfLimit);		
	}
}
