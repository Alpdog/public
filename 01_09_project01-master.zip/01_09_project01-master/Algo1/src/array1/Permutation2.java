package array1;

import java.util.Arrays;
import java.util.Scanner;

public class Permutation2 {
	public static int n, r, data[], caseCount;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		r = sc.nextInt();
		data = new int[r];
		
		permutation(0);
		
		System.out.println(caseCount);
		sc.close();
	}
	
	public static void permutation(int count) {
		//if(count == n) {
		if(count == r) {
			caseCount++;
			System.out.println(Arrays.toString(data));
			return;
		}

		for (int i = 1; i <= n; i++) {
			data[count] = i;
			permutation(count+1);
		}
	}
}
