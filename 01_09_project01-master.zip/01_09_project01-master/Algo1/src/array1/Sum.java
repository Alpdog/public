package array1;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

public class Sum {
	public static void main(String[] args) {
		System.out.println(sum(100));
		System.out.println(sumR(100));
		System.out.println(facR(24));
		System.out.println(fibR(3));
		System.out.println(gcd(12, 6));
		System.out.println(gcdR(111, 22));
	}
	
	public static int sum(int N) {
		int sum  = 0;
		
		for (int i = 1; i <= N; i++)
			sum+= i;

		return sum;
	}
	
	public static int sumR(int N) {
		if(N == 1) return 1;
		return N + sumR(N-1);	
	}
	
	public static int facR(int N) {
		if(N == 1) return 1;
		return N * facR(N-1);
	}
	
	public static int fibR(int N) {
		if(N == 1 || N == 0) return N;
		return fibR(N-2) + fibR(N-1);
	}
	
	public static int gcd(int a, int b) {
		int x = (a > b)? a : b;
		int y = (a > b)? b : a;

		while(y != 0) {
			int n = x % y;
			x = y;
			y = n;
		}
		return x;
	}
	
	public static int gcdR(int a, int b) {
		
		if(b == 0)
			return a;

		return gcdR(b, a % b);
	}
}
