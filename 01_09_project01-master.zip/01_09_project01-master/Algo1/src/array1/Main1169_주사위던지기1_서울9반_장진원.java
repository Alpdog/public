package array1;

import java.util.Scanner;

public class Main1169_주사위던지기1_서울9반_장진원 {
	static int data[], chk[], caseCount, n;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		
		data = new int[n];
		chk = new int[7];
		
		int select = sc.nextInt();
		
		switch (select) {
		case 1:
			permutation(1,0);
			break;
		case 2:
			permutation2(1,0);
			break;
		default:
			combination(0);
			break;
		}
		sc.close();

	}
	public static void permutation(int before, int count) {
		if(count == n) {
			printout();
			return;
		}

		for (int i = 1; i <= 6; i++) {
			data[count] = i;
			permutation(i, count+1);
		}
	}
	
	public static void permutation2(int before, int count) {
		if(count == n) {
			printout();
			return;
		}

		for (int i = before; i <= 6; i++) {
			data[count] = i;
			permutation2(i, count+1);
		}
	}

	public static void combination(int count) {
		if(count == n) {
			printout();
			return;
		}

		for (int i = 1; i <= 6; i++) {
			if(chk[i] == 0) {
				chk[i] = 1;
				data[count] = i;
				combination(count+1);
				chk[i] = 0;
			}
		}
	}
	
	public static void printout() {
		for (int i = 0; i < data.length; i++) {
			System.out.print(data[i] + " ");
		}
		System.out.println();
	}
	
}
