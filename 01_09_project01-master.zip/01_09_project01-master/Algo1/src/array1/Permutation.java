package array1;

public class Permutation {

	public static void main(String[] args) {
		int[] data = {0, 1, 2, 3};
		
		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j <= 3; j++) {
				for (int k = 1; k <= 3; k++) {
					if(i == j || i == k || j == k)
						continue;
					System.out.println(i + " " + j + " " + k + " ");
				}
			}
		}

	}

}
