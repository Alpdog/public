package array1;

import java.util.Arrays;
import java.util.Scanner;

public class Permutation3 {
	public static int n, r, data[], caseCount;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		//r = sc.nextInt();
		data = new int[n];
		//data = new int[r];
		
		//permutation(1,0);
		combination(0,1);
		
		System.out.println(caseCount);
		sc.close();
	}
	
	public static void permutation(int before, int count) {
		//if(count == n) {
		if(count == r) {
			for (int i = 0; i < r; i++) {
				for (int j = i+1; j < r; j++) {
					if(data[i] == data[j]) return;
				}
				
			}
			caseCount++;
			System.out.println(Arrays.toString(data));
			return;
		}

		for (int i = before; i <= n; i++) { // 중복이 없는 조합 (1,2) = (2, 1)
			data[count] = i;
			permutation(i, count+1);
		}
	}
	
	public static void combination(int count, int picked) {
		if(count == 3) {
			caseCount++;
			System.out.println(Arrays.toString(data));
			return;
		}
		
		for (int i = picked; i <= 6; i++) {
			data[count] = i;
			combination(count+1, i+1);
		}
	}
}
