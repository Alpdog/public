package tree;
/*class Node{
	char data;
	Node left, right;
}

class Tree{
	Node root;
	
	public Node makeTree(Node left, char data, Node right) {
		Node node = new Node();
		node.left = left;
		node.right = right;
		node.data = data;
		return node;
	}
}*/
public class Traversal {
	public static void main(String[] args) {
		Tree t = new Tree();
		Node d = t.makeTree(null, 'D', null);
		Node h = t.makeTree(null, 'H', null);
		Node i = t.makeTree(null, 'I', null);
		Node f = t.makeTree(null, 'F', null);
		Node g = t.makeTree(null, 'G', null);
		
		Node e = t.makeTree(h, 'E', i);
		Node b = t.makeTree(d, 'B', e);
		Node c = t.makeTree(f, 'C', g);
		Node a = t.makeTree(b, 'A', c);
		t.root = a;
		
		traversalPreOrder(a);
		System.out.println();
		traversalInOrder(a);
		System.out.println();
		traversalPostOrder(a);
		System.out.println();
		
		Tree t2 = new Tree();
		
		Node j2 = t2.makeTree(null, 'J', null);
		Node e2 = t2.makeTree(j2, 'E', null);
		Node k2 = t2.makeTree(null, 'K', null);
		Node f2 = t2.makeTree(null, 'F', k2);
		Node l2 = t2.makeTree(null, 'L', null);
		Node m2 = t2.makeTree(null, 'M', null);
		Node g2 = t2.makeTree(l2, 'G', m2);
		Node h2 = t2.makeTree(null, 'H', null);
		Node i2 = t2.makeTree(null, 'I', null);
		Node d2 = t2.makeTree(h2, 'D', i2);
		Node c2 = t2.makeTree(f2, 'C', g2);
		Node b2 = t2.makeTree(d2, 'B', e2);
		Node a2 = t2.makeTree(b2, 'A', c2);
		t2.root = a2;
		
		traversalPreOrder(a2);
		System.out.println();
		traversalInOrder(a2);
		System.out.println();
		traversalPostOrder(a2);
	}

	private static void traversalPreOrder(Node root) {
		if(root != null) {
			System.out.print(root.data + " ");
			traversalPreOrder(root.left);
			traversalPreOrder(root.right);
		}
	}
	private static void traversalInOrder(Node root) {
		if(root != null) {
			traversalInOrder(root.left);
			System.out.print(root.data + " ");
			traversalInOrder(root.right);
		}
	}
	private static void traversalPostOrder(Node root) {
		if(root != null) {
			traversalPostOrder(root.left);
			traversalPostOrder(root.right);
			System.out.print(root.data + " ");
		}
	}
}
