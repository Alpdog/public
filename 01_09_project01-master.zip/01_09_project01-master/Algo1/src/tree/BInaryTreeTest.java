package tree;

class BinaryTree{
	class Node{
		int data;
		Node left, right;
		Node(int data){
		 this.data = data;	
		}
	}
	Node root;
	public void makeTree(int[] a) {
		root = makeTree(a,0,a.length-1);
	}
	private Node makeTree(int[] a, int start, int end) {
		 if(start > end)
			 return null;
		 int mid = (start+end)/2;
		 Node node = new Node(a[mid]);
		 node.left = makeTree(a, start, mid-1);
		 node.right = makeTree(a, mid+1, end);
		return node;
	}
	public void inOrder(Node root) {
		if(root!= null) {
			inOrder(root.left);
			System.out.print(root.data + " ");
			inOrder(root.right);
		}
	}
	public void search(Node root, int data) {
		if(data < root.data) {
			System.out.println("Smaller " + root.data);
			search(root.left, data);
		}
		else if(data > root.data) {
			System.out.println("Bigger " + root.data);
			search(root.right, data);
		}
		else
			System.out.println("Found!");
	}
}
/*
0 1 2 3 4 5 6 7 8 9

         4
  	  1      7
	 0 2   5   8
        3   6   9
1,4,9,11,14,15,22,27,38,49
         14
  	  4      27
	1   9   15   38
         11   22    49
*/
public class BInaryTreeTest {
	public static void main(String[] args) {
//		int[] a = new int[10];
//		for (int i = 0; i < a.length; i++)
//			a[i] = i;
		int[] a = {1,4,9,11,14,15,22,27,38,49};
		
		BinaryTree t = new BinaryTree();
		t.makeTree(a);
		//t.inOrder(t.root);
		t.search(t.root, 22);
	}
}
