package tree;

import java.util.Scanner;

/*13
A B C D E F G H I J K L M*/
public class TreeArray {
	
	static int N;
	static char[] a;
	
	public static void preorder(int i) {
		if(i <= N && a[i] != '\u0000') {
			System.out.print(a[i] + " ");
			preorder(i*2);
			preorder(i*2+1);
		}
	}
	
	public static void inorder(int i) {
		if(i <= N && a[i] != '\u0000') {
			inorder(i*2);
			System.out.print(a[i] + " ");
			inorder(i*2+1);
		}
	}
	
	public static void postorder(int i) {
		if(i <= N && a[i] != '\u0000') {
			postorder(i*2);
			postorder(i*2+1);
			System.out.print(a[i] + " ");
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		a = new char[N+1];
		for (int i = 1; i <= N; i++) {
			a[i] = sc.next().charAt(0);
		}
		preorder(1);
		System.out.println();
		inorder(1);
		System.out.println();
		postorder(1);
		System.out.println();
	}
}
