package tree;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/*class Node{
	char data;
	int left, right;
}

class Tree{
	Node root;

	public Node makeTree(int left, char data, int right) {
		Node node = new Node();
		node.left = left;
		node.right = right;
		node.data = data;
		return node;
	}
}*/

public class Solution1231_중위순회_서울9반_장진원 {
	
	static Node[] nodes;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputInorder.txt"));
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		for (int testCase = 1; testCase <= 10; testCase++) {
			int N = Integer.parseInt(sc.readLine());

			nodes = new Node[N+1];
			
			for (int i = 1; i <= N; i++) {
				String[] string = sc.readLine().split(" ");
				
				nodes[i] = new Node();
				nodes[i].data = string[1].charAt(0);
				
				if(string.length > 2)
					nodes[i].left = Integer.parseInt(string[2]);
				else
					nodes[i].left = 0;
				if(string.length > 3)
					nodes[i].right = Integer.parseInt(string[3]);
				else
					nodes[i].right = 0;
			}
			System.out.print("#" + testCase + " ");
			inorder(1);
			System.out.println();
		}
	}

	private static void inorder(int rootIndex) {
		if(nodes[rootIndex].left != 0)
			inorder(nodes[rootIndex].left);
		
		System.out.print(nodes[rootIndex].data);
		
		if(nodes[rootIndex].right != 0)
			inorder(nodes[rootIndex].right);
	}		
}

