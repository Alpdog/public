package tree;

import java.util.Scanner;

/*class Node{
	int data;
	int left, right;
}

class Tree{
	Node root;

	public Node makeTree(int left, int data, int right) {
		Node node = new Node();
		node.left = left;
		node.right = right;
		node.data = data;
		return node;
	}
}*/

public class TreePreorder_서울9반_장진원 {
	static Node[] nodes;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int V = sc.nextInt();
		nodes = new Node[V+1];
		Tree t = new Tree();

		for (int i = 1; i <= V-1; i++) {
			int temp =sc.nextInt();
			if(nodes[temp] == null) {
				int next = sc.nextInt();
				nodes[temp] = t.makeTree(next, temp, 0);
				nodes[next] = t.makeTree(0, next, 0);
			}
			else if(nodes[temp] != null && nodes[temp].left == 0) {
				int next = sc.nextInt();
				nodes[temp] = t.makeTree(next, temp, 0);
				nodes[next] = t.makeTree(0, next, 0);
			}
			else{
				int next = sc.nextInt();
				nodes[temp] = t.makeTree(nodes[temp].left, temp, next);
				nodes[next] = t.makeTree(0, next, 0);
			}
		}

		traversalPreOrder(nodes[1]);
	}

	private static void traversalPreOrder(Node root) {
		if(root != null) {
			System.out.print(root.data + " ");
			if(nodes[root.left] != null)
				traversalPreOrder(nodes[nodes[root.left].data]);
			if(nodes[root.right] != null)
				traversalPreOrder(nodes[nodes[root.right].data]);
		}
	}
}
