package tree;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Solution1233_사칙연산유효성검사_서울9반_장진원2 {
	static class Node{
		String data;
		String left, right;
	}

	static class Tree{
		Node root;

		public Node makeTree(String left, String data, String right) {
			Node node = new Node();
			node.left = left;
			node.right = right;
			node.data = data;
			return node;
		}
	}
	
	static int length;
	static boolean flag;
	static Node[] nodes;
	
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1232.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		for (int testCase = 1; testCase <= 10; testCase++) {
			length = Integer.parseInt(br.readLine());
			nodes = new Node[length+1];
			
			for (int i = 1; i <= length; i++) {
				String[] string = br.readLine().split(" ");
				
				nodes[i] = new Node();
				nodes[i].data = string[1];
				
				if(string.length > 2)
					nodes[i].left = string[2];
				else
					nodes[i].left = null;
				if(string.length > 3)
					nodes[i].right = string[3];
				else
					nodes[i].right = null;
			}
			flag = true;
			calculate(1);
			
			if(flag == true)
				System.out.println("#" + testCase + " 1");
			else
				System.out.println("#" + testCase + " 0");
		}
	}
	private static boolean result(int index) {
		if(nodes[index].data.equals("+") || nodes[index].data.equals("-")|| nodes[index].data.equals("*")||nodes[index].data.equals("/"))
			return true;
		else
			return false;
	}

	private static void calculate(int index) {
		if(nodes[index].left == null || nodes[index].right == null) {
			if(nodes[index].data.equals("+") || nodes[index].data.equals("-")|| nodes[index].data.equals("*")||nodes[index].data.equals("/"))
					flag = false;
		}

		if(!(nodes[index].data.equals("+") || nodes[index].data.equals("-")|| nodes[index].data.equals("*")||nodes[index].data.equals("/"))){
			if(result(Integer.parseInt(nodes[index].left)) == true || result(Integer.parseInt(nodes[index].right)) == true)
				flag = false;
		}
	}
}
