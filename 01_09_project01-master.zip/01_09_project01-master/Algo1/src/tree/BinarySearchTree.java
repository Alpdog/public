package tree;

import tree.BinaryTree.Node;

class BST{
	class Node{
		int data;
		Node left, right;
		Node(int data){
			this.data = data;
		}
	}

	Node root;
	public void insert(int data) {
		root = insert(root, data);
	}
	
	private Node insert(Node root, int data) {
		if(root == null) {
			root = new Node(data);
			return root;
		}
		if(data < root.data) {
			root.left = insert(root.left, data);
		}
		else if(data > root.data) {
			root.right = insert(root.right, data);
		}
		return root;
	}
	
	public void inOrder(Node root) {
		if(root!= null) {
			inOrder(root.left);
			System.out.print(root.data + " ");
			inOrder(root.right);
		}		
	}
	
	public void preOrder(Node root) {
		if(root!= null) {
			System.out.print(root.data + " ");
			preOrder(root.left);
			preOrder(root.right);
		}		
	}
	
	public Node search(Node root, int data) {
		if(root == null || data == root.data) {
			return root;
		}
		if(data < root.data) {
			return search(root.left, data);
		}
		else {
			return search(root.right, data);
		}
	}
	
	public void inOrder() {
		inOrder(root);
		System.out.println();
	}
	public void PreOrder() {
		preOrder(root);
		System.out.println();
	}
	
	public void delete(int data) {
		root = delete(root, data);
	}
	private Node delete(Node root, int data) {
		if(root == null)
			return root;

		if(data < root.data) {
			root.left = delete(root.left, data);
		}
		else if(data > root.data) {
			root.right = delete(root.right, data);
		}else {
			if(root.left == null && root.right == null)
				return null;
			else if(root.left == null)
				return root.right;
			if(root.right == null)
				return root.left;
			
			root.data = findMin(root.right);
			root.right = delete(root.right, root.data);
		}
		return root;
	}
	private int findMin(Node root) {
		int min = root.data;
		while(root.left != null) {
			min = root.left.data;
			root = root.left; //트리의 제일 작은 값은 왼쪽 제일 아래에 있기 때문.
		}
		return min; 
	}
}
/*
			4
		2       6
	  1   3   5   7
 */

public class BinarySearchTree {
	public static void main(String[] args) {
		BST t  = new BST();
		int[] a = {4, 2, 3, 6, 7, 5, 1};
		for (int i = 0; i < a.length; i++)
			t.insert(a[i]);
		tree.BST.Node node = t.search(t.root, 1);
		t.inOrder();
		t.delete(7);
		t.inOrder();
		t.delete(6);
		t.inOrder();
		t.delete(2);
		t.inOrder();
		t.delete(4);
		t.inOrder();
		t.PreOrder();
		
	}
}
