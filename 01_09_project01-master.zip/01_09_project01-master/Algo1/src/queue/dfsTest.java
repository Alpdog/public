package queue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class dfsTest {
	public static int V, E, top; //정점 V, 간선 E, index top
	public static int[] stack; 
	public static int[][] graph;
	public static boolean[] visit;
	private static int[] queue;
	private static int front;
	private static int rear;
	
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputDFS.txt"));
		Scanner sc = new Scanner(System.in);
		int[][] map = new int[7][7];
		int [] chk = new int[7];
		
	
		V = sc.nextInt();
		E = sc.nextInt();
		graph = new int[V][V];
		visit = new boolean[V];
		stack = new int[100];
		top = -1;
		
		for (int i = 0; i < E; i++) {
			int v1 = sc.nextInt();
			int v2 = sc.nextInt();
			graph[v1][v2] = graph[v2][v1]=1;
		}

		BFS(0);
		/*	System.out.print("#2 iterative ");
		DFSr(0);
		System.out.println();*/
	}

	private static void BFS(int node) {
		queue[++rear] = node; // enqueue();
		while(front != rear) {
			int curr = queue[++front];
			if(visit[curr] == false) {
				visit[curr] = true;
				System.out.println(curr + " ");
				
				for (int next = 0; next < V; next++) {
					if(visit[next] == false && graph[node][next] == 1) {
						DFSr(next);
					}
				}
			}
		}
	}

	public static void DFSr(int node) {
		visit[node] = true;
		System.out.print(node + " ");
		for (int next = 0; next < V; next++) {
			if(visit[next] == false && graph[node][next] == 1) {
				DFSr(next);
			}
		}
	}
}
