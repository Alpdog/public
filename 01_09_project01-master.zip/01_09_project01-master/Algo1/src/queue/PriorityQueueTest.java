package queue;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueTest {
	public static int[] queue = new int[100];
	public static int front = -1;
	public static int rear = -1;
	public static int n = 10;

	public static boolean isEmpty() {
		if(front == rear)
			return true;
		else
			return false;
	}

	public static boolean isFull() {
		if((1+rear)%n == front) 
			return true;
		return false;

	}	
	public static void enqueue(int item) {
		if(isFull()) {
			System.out.println("Full");
			return;
		}
		queue[++rear] = item;
		int k = rear;
		for (int j = k-1; j > front; j--) { // 0이 아니라 front 바로 앞까지만 한다
			if(queue[j] > queue[k]) {
				int T = queue[j];
				queue[j] = queue[k];
				queue[k] = T;
				k = j;
				System.out.println(Arrays.toString(queue));
			}
		}
	}
	public static int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		return  queue[(++front)%n];
	}

	public static int qpeek() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		return  queue[(1+front)%n];
	}
	public static void main(String[] args) {
		Queue <Integer> pq = new PriorityQueue<>();
		pq.offer(3);
		pq.offer(2);
		pq.offer(1);
		System.out.println(pq.poll());
		System.out.println(pq.poll());
		System.out.println(pq.poll());
	}
}
