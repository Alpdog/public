package queue;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueTest2 {
	public static int[] queue = new int[100];
	public static int front = -1;
	public static int rear = -1;
	public static int n = 10;

	public static boolean isEmpty() {
		if(front == rear)
			return true;
		else
			return false;
	}

	public static boolean isFull() {
		if((1+rear)%n == front) 
			return true;
		return false;

	}	
	public static void enqueue(int item) {
		if(isFull()) {
			System.out.println("Full");
			return;
		}
		queue[(++rear)%n] = item;
	}
	public static int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		return  queue[(++front)%n];
	}

	public static int qpeek() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		return  queue[(1+front)%n];
	}
	public static void main(String[] args) {
		enqueue(3);
		enqueue(2);
		enqueue(1);
		System.out.println(qpeek());
		
		Queue <Integer> pq = new PriorityQueue<>();
		pq.offer(3);
		pq.offer(2);
		pq.offer(1);
		System.out.println(pq.poll());
		System.out.println(pq.poll());
		System.out.println(pq.poll());
	}
}
