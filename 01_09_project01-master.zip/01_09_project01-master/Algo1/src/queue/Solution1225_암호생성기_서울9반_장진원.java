package queue;

import java.io.FileInputStream;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Solution1225_암호생성기_서울9반_장진원 {
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input암호생성기.txt"));
		Scanner sc = new Scanner(System.in);
		
		for (int testCase = 1; testCase <= 10; testCase++) {
			int n = sc.nextInt();
			
			Queue<Integer> q = new LinkedList<Integer>();
			
			for (int i = 0; i < 8; i++)
				q.offer(sc.nextInt());
			
			int temp = 1;
			aaa:while(true) {
				while(temp <6) {
					int temp2 = q.poll()-(temp);
					if(temp2 <= 0) {
						q.offer(0);
						break aaa;
					}
					q.offer(temp2);
					temp++;
				}
				temp = 1;
			}
			System.out.println("#" + testCase + " " + q.toString().replace("[", "").replace("]", "").replace(",", ""));
		}
	}
}
