package queue;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Solution_마이쮸_서울9반_장진원 {
	public static void main(String[] args) {
		Queue<Integer> man = new LinkedList<Integer>();
		Queue<Integer> candy = new LinkedList<Integer>();
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		System.out.println("찾고자 하는 마이쮸 갯수 입력");
		int candyNumber = sc.nextInt();
		
		candy.offer(1);
		man.offer(1);
		int manCounter = 1;
		
			while(sum < candyNumber) {
				sum+= candy.peek();
				System.out.println("받은 총 마이쮸 개수 " + sum);
				if(sum >= candyNumber) break;
				candy.offer((candy.poll())+1);
				System.out.println("큐에서 받을 마이쮸 개수" + candy);
				man.offer((man.poll()));
				System.out.println("큐에 있는 사람	 " + man);
				candy.offer(1);
				man.offer(++manCounter);
		}
		
			System.out.println(candyNumber + "번째 마이쮸를 받은 사람 : " + man.peek());
		
	}
}
