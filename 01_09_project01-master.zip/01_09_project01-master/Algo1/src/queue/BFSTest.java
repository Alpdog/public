package queue;

import java.io.FileInputStream;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class BFSTest {
	public class Way{
		public int current;
		public int destination;
	}

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputDFS.txt"));
		Scanner sc = new Scanner(System.in);
		
		int[][] map = new int[8][8];
		int [] chk = new int[8];
		
		Queue<Integer> q = new LinkedList<Integer>();
		int x1 = sc.nextInt();
		int x2 = sc.nextInt();
		
		for (int i = 1; i <= 8; i++) {
			int v1 = sc.nextInt();
			int v2 = sc.nextInt();
			map[v1][v2] = map[v2][v1]=1;
		}
		q.offer(1);
		
		while(!q.isEmpty()) {
			int temp = q.poll();
			chk[temp] = 1;
			System.out.print(" " + temp);
			
			for (int i = 1; i <= 7; i++) {
				if(map[temp][i] == 1 && chk[i] != 1) {
					q.offer(i);
					chk[i] = 1;
				}
			}
		}
	}

}
