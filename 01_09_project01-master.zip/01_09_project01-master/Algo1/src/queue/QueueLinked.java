package queue;

import java.util.LinkedList;
import java.util.Queue;
class Node{
	int data;
	Node link;

	Node(int data, Node link){
		this.data = data;
		this.link = link;
	}
	Node(int data){
		this(data, null);
	}
}
public class QueueLinked {
	public static Node front = null;
	public static Node rear = null;

	public static boolean isEmpty() {
		if(front == null)
			return true;
		else
			return false;
	}

	public static void enqueue(int item) {
		Node end = new Node(item);
		if(front == null) {
			front = end;
			rear = end;
		}else {
			rear.link = end;
			rear = end;
		}
	}
	public static int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		int data = front.data;
		front = front.link;
		if(front == null)
			rear = null;
		System.gc();
		return data;
	}

	public static int qpeek() {
		if(isEmpty()) {
			System.out.println("Queue Empty.");
			return -1;
		}
		int data = front.data;
		return data;
	}
	public static void main(String[] args) {
		enqueue(1);
		enqueue(2);
		enqueue(3);
		enqueue(4);
		enqueue(5);
		enqueue(6);
		System.out.println(qpeek());
	}
}
