import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution_서울_9반_장진원 {
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		String s = br.readLine();
		String[] sa = br.readLine().split(" ");
	}
}
