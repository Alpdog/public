package list;

import java.util.Arrays;

public class insertionSort {
	public static int[] a = {10, 69, 30, 2, 16, 8, 31, 22};
	
	public static void main(String[] args) {
	
		for (int i = 1; i < a.length; i++) { // 0번째 인덱스는 정렬되어 있다고 가정
			int k = i;
			for (int j = k-1; j >= 0; j--) {
				if(a[j] > a[k]) {
					int T = a[j];
					a[j] = a[k];
					a[k] = T;
					k = j;
					System.out.println(Arrays.toString(a));
				}
			}
		}
		System.out.println(Arrays.toString(a));
	}
}
