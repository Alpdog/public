package list;

class PLinkedStack{
	Node header = null;
	Node top = header;

	void print() {
		if(header == null)
			return;
		Node n = header;
		while(n.next != null) {
			System.out.print(n.data + " -> ");
			n= n.next;
		}
		System.out.println(n.data);
	}

	boolean push(int value) {
		Node neew = new Node();
		neew.data = value;
		neew.next = top;
		top =neew;
		return true;
	}

	int pop() {
		Node temp = top;
		if(top == null)
			return -1;
		
		int value = temp.data;
		top = temp.next;
		
		return value;
	}
	
	int peek() {
		if(top == null) return -1;
		int value = top.data;
		return value;
	}
}
public class PLinkedStack_서울9반_장진원 {

	public static void main(String[] args) {
		LinkedList ll = new LinkedList();
		ll.push(3);
		ll.push(1);
		ll.push(2);
		ll.push(4);
		ll.print();
		System.out.println(ll.pop());
		System.out.println(ll.pop());
		System.out.println(ll.pop());
		System.out.println(ll.pop());
		ll.print();
	}
}


