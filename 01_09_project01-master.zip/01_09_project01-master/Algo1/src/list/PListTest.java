package list;

class PLinkedList{
	Node header = new Node();

	void addFirst(int data) {
		Node n = new Node();
		n.data = data;
		n.next = header.next;
		header.next = n;
	}

	void print() {
		if(header == null)
			return;
		Node n = header;
		while(n.next != null) {
			System.out.print(n.data + " -> ");
			n= n.next;
		}
		System.out.println(n.data);
	}

	void append(int data) {
		if(header == null)
			addFirst(data);
		else {
			Node end = new Node();
			end.data= data;
			Node n = header;
			while(n.next != null)
				n= n.next;
			n.next =end;
		}
	}
	
	void add(int data) {
		if(header == null)
			addFirst(data);
		else {
		Node end = new Node();
		end.data = data;
		Node n = header;
		while(n.next != null) {
			if(n.next.data > data) {
				end.next = n.next;
				n.next = end;
				return;
			}else {
				n = n.next;
			}
		}
		n.next = end;
		}
		
	}

	void delete(int data) {
		if(header == null)
			return;
		Node n = header;
		while(n.next != null) {
			if(n.next.data == data) {
				n.next = n.next.next;
				return;					
			}else {
				n= n.next;
			}
		}
	}
}
public class PListTest {

	public static void main(String[] args) {
		PLinkedList ll = new PLinkedList();
		ll.add(3);
		ll.add(2);
		ll.add(1);
		ll.add(5);
		ll.add(4);
		ll.print();
	}
}


