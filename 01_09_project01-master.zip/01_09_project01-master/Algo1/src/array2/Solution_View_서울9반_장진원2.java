package array2;

import java.io.FileInputStream;
import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

public class Solution_View_서울9반_장진원2 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/inputView.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		for (int testCase = 1; testCase <= 10; testCase++) {
			int T = sc.nextInt();
			int[] map = new int[T];
			int counter = 0;
			
			for (int i = 0; i < T; i++) 
				map[i] = sc.nextInt();
			
			for (int i = 2; i < T-2; i++) {
				if(map[i] > map[i-1] && map[i] > map[i+1] && map[i] > map[i-2] && map[i] > map[i+2]) {
					counter += map[i] - Math.max(Math.max(Math.max(map[i-2], map[i+2]), map[i-1]), map[i+1]);
				}
			}
			
			System.out.println("#" + testCase + " " + counter);
			counter = 0;
		}
	}	
}