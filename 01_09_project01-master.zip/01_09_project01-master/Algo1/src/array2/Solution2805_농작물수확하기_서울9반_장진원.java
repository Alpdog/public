package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution2805_농작물수확하기_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input2805.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int testCase = 1; testCase <= T; testCase++) {
			int sum = 0;
			int N = sc.nextInt();
			int[][] map = new int[N][N];

			for (int j = 0; j < N; j++) {
				String temp = sc.next();
				for (int k = 0; k < N; k++) {
					map[j][k] = (int)(temp.toCharArray()[k]-'0');
				}
			}
			int cx = N/2;
			int cy = N/2;
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if(Math.abs(cx-i) + Math.abs(cy-j) <= N/2)
						sum+= map[j][i];
				}
			}

			System.out.println("#" + testCase +  " " + sum);
			sum = 0;
		}
	}
}
