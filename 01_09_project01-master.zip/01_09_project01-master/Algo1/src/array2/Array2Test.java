package array2;

import java.util.Arrays;

public class Array2Test {
	public static int[][] data = {{1,2,3}, {4,5,6}, {7,8,9}};
	public static int[] dy = {-1,1,0,0};
	public static int[] dx = {0,0,-1,1};
	public static int N = data.length;
	public static int M = data.length;

	public static void main(String[] args) {
		System.out.println(Arrays.deepToString(data));

		for (int[] a : data) System.out.println(Arrays.toString(data));

		System.out.println();

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) 
				System.out.print(data[i][j]+ " ");

			System.out.println();
		}
		System.out.println();

		for (int j = 0; j < N; j++) {
			for (int i = 0; i < M; i++) 
				System.out.print(data[i][j]+ " ");

			System.out.println();
		}
		System.out.println();

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				//System.out.print(data[i][j+(M-1-2*j)*(i%2)]+ " ");
				System.out.print(data[i][j+(M-1-2*j)*(i&1)]+ " ");
			}

			System.out.println();
		}
		System.out.println();

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				int sum = 0;
				for (int d = 0; d < dx.length; d++) {
					int di = i + dx[d];
					int dl = j + dy[d];
					if(di >= 0 && dl >= 0 && di<N && dl<N)
						sum+= data[dl][di];
					
				}
				System.out.print(sum + " ");
			}
			System.out.println();
		}
		System.out.println();

		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[i].length; j++) {
					if(i<j) {
						int temp = data[i][j];
						data[i][j] = data[j][i];
						data[j][i] = temp;
					}
					System.out.print(data[i][j]+ " ");
			}
			System.out.println();
		}

	}


}
