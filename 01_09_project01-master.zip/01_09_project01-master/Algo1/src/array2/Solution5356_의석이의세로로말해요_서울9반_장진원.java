package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution5356_의석이의세로로말해요_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input5356.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int i = 1; i <= T; i++) {
			System.out.print("#" + i + " ");
			int[] length = new int[5];
			String[] words = new String[5];
			char[][] wordsCharArr = new char[5][];

			for (int j = 0; j < 5; j++) {
				words[j] = sc.next();
				length[j] = words[j].length();
				wordsCharArr[j] = words[j].toCharArray();
			}

			boolean flag = true;
			int col = 0;
			do {
				flag = false;
				for (int j = 0; j < 5; j++) {
					if(length[j] != 0) {
						System.out.print(wordsCharArr[j][col]);
						length[j]--;
						flag = true;
					}
				}
				col++;
			} while (flag);

			System.out.println();
		}	
	}
}