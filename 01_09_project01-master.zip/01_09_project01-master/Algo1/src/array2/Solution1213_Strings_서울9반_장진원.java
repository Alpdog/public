package array2;

import java.util.Scanner;

public class Solution1213_Strings_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);

		for (int testCase = 1; testCase <= 10; testCase++) {
			int T = sc.nextInt();
			String temp = sc.next();
			String allLine = sc.next();
			
			System.out.println("#" + testCase + " " + (allLine.split(temp, -1).length-1));
		}
	}	
}