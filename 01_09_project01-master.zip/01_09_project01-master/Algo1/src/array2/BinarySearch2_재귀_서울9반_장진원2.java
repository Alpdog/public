package array2;

import java.util.Scanner;

public class BinarySearch2_재귀_서울9반_장진원2 {

	public static void main(String[] args) {
		int[] data = {2,4,7,9,11,19,23};

		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();

		System.out.println(binarySearch(data, 0, 6, key)); // 없으면 -1 출력, 있으면 그 숫자 출력

	}

	private static int binarySearch(int[] data, int low, int high, int key) {
		int middle = (low+high)/2;
		
		if (low > high) 
			return -1;

		if(key == data[middle])
			return data[middle];
		else if(key < data[middle])
			return binarySearch(data, low, middle-1, key);
		else
			return binarySearch(data, middle+1, high, key);
	}
}
