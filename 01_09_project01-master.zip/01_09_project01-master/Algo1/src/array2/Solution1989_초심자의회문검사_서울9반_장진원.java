package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1989_초심자의회문검사_서울9반_장진원 {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input1989.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int testCase = 1; testCase <= T; testCase++) {
			String temp = sc.next();
			char[] tempArray = temp.toCharArray();
			System.out.print("#" + testCase + " ");
			
			for (int i = 0; i < tempArray.length/2; i++) {
				if(tempArray[i] == tempArray[tempArray.length-1-i]) {
					if(i == tempArray.length/2-1)
						System.out.println("1");
				}
				else {
					System.out.println("0");
					break;
				}
			}
		}
	}
}
