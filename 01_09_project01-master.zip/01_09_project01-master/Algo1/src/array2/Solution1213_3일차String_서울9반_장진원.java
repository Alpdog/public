package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1213_3일차String_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1213.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		

		for (int testCase = 1; testCase <= 10; testCase++) {
			int T = sc.nextInt();
			String temp = sc.next();
			String allLine = sc.next();
			
			if(allLine.endsWith(temp))
				System.out.println("#" + testCase + " " + (allLine.split(temp).length));
			else
				System.out.println("#" + testCase + " " + (allLine.split(temp).length-1));
		}
	}	
}