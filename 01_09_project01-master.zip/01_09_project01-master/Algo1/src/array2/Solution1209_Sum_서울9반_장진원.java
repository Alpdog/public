package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1209_Sum_서울9반_장진원 {
	static int max = 0;

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1209.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		for (int i = 1; i <= 10; i++) {
			int T = sc.nextInt();
			int[][] map = new int[100][100];

			for (int k = 0; k < 100; k++) {
				for (int j = 0; j < 100; j++)
					map[k][j] = sc.nextInt();
			}

			for (int j = 0; j < 100; j++)
				sum(map, j, 0);
			for (int j = 0; j < 100; j++)
				sum(map, j, 1);
			for (int j = 0; j < 100; j++)
				sum(map, j, 2);
			
			System.out.println("#" + i + " " +max);	
			max = 0;
		}	
	}

	private static void sum(int[][] map, int line, int type) {
		int sum1 = 0;
		int sum2 = 0;

		if(type == 0) {
			for (int i = 0; i < 100; i++) {
				sum1 += map[line][i];
				sum2 += map[i][line];
			}
			max = (max < sum1)? sum1:max;
			max = (max < sum2)? sum2:max;
		}
		else if(type == 1) {
			for (int i = 0; i < 100; i++)
				sum1 += map[i][99-i];
			max = (max < sum1)? sum1:max;
		}
		else if(type == 2) {
			for (int i = 0; i < 100; i++)
				sum2 += map[i][i];
			max = (max < sum2)? sum2:max;			
		}
	}
}