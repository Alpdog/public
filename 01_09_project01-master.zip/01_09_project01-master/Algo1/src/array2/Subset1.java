package array2;

import java.util.Arrays;

public class Subset1 {

	public static void main(String[] args) {
		int[] bit = new int [4];
		int c = 0;
		
		for (int i = 0; i < 2; i++) {
			bit[0] = (i%2 == 0)? 0 : 1;
			for (int j = 0; j < 2; j++) {
				bit[1] = (j%2 == 0)? 0 : 1;
				for (int j2 = 0; j2 < 2; j2++) {
					bit[2] = (j2%2 == 0)? 0 : 1;
					for (int k = 0; k < 2; k++) {
						bit[3] = (k%2 == 0)? 0 : 1;
						System.out.printf("%s %d\n", Arrays.toString(bit), c++);
					}
				}
			}
		}

	}

}
