package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1210_Ladder1_서울9반_장진원 {
	static int row, col;
	
	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1210.txt"));
		Scanner sc = new Scanner(System.in);
		
		for(int test_case = 1; test_case <= 10; test_case++) {
			int T = sc.nextInt();
			System.out.print("#" + test_case + " ");
			int[][] map = new int[100][100];
			int cnt = -1;
			for (int i = 0; i < 100; i++) {
				for (int j = 0; j < 100; j++) {
					map[i][j] = sc.nextInt();
			
					if(map[i][j] == 2) {
						row = 99;
						col = j;
					}
				}
			}
			goUp(map);
		}
	}

	private static void goUp(int[][] map) {
		int[] dx = {-1, 1};
		
		while(row > 0) {
			for (int i = 0; i < 2; i++) {
				int nx = col+dx[i];
				
				if(nx < 0 || nx > 99)
					continue;
				
				if(map[row][nx] == 1) {
					goSide(map, dx[i]);
					break;
				}
			}
			row--;			
		}
		System.out.println(col);
	}

	private static void goSide(int[][] map, int dir) {
		while(!(col+dir < 0 || col + dir > 99 || map[row][col + dir] == 0))
			col += dir;
	}
}