package array2; //제출시 삭제

import java.io.FileInputStream;
import java.util.Scanner;

public class  Solution2817_부분수열의합_서울9반_장진원 { //제출시 Solution 만 남기고 지우기
	static int answer, N, K;

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input2817.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int i = 1; i <= T; i++) {

			N = sc.nextInt();
			K = sc.nextInt();

			int[] numbers = new int[N];
			
			for (int j = 0; j < (1<<N); j++) {
				numbers[j] = sc.nextInt();
			}

			for (int j = 0; j < (1<<N); j++) {
				picking(numbers ,numbers[j], j);
			}

			System.out.println("#" + i + " "+ answer);
			answer = 0;
		}
	}

	private static void picking(int[] numbers, int sum, int start) {


		if(sum >= K) {
			if(sum == K)
				answer++;
			return;
		}

		if(start+1 >= N)
			return;

		picking(numbers, sum+numbers[start+1], start+1);
		picking(numbers, sum, start+1);

	}
}