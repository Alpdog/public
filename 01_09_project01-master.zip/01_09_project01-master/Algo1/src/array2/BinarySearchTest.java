package array2;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearchTest {
	public static int[] data = { 2, 3, 5,6, 8, 9,10, 15, 21};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();
		
		System.out.println(binarySearch(key));
		System.out.println(data[Arrays.binarySearch(data, key)]);
	}

	private static boolean binarySearch(int key) {
		int start = 0;
		int end = data.length-1;
		
		while(start <= end) {
			int middle = (start+end)/2;
			
			if(data[middle] == key)
				return true;
			if(data[middle] > key)
				end = middle -1;
			if(data[middle] < key)
				start = middle + 1;
			
		}
		return false;
	}
	public static boolean binarySearchRec(int low, int high, int key) {
		if(low > high) return false;
		int middle = (low+high)/2;
				
		if(data[middle] == key) return true;
	
	if(data[middle] > key)
		return binarySearchRec(low, middle -1, key);
	else if (data[middle] < key)
		return binarySearchRec(middle + 1, high, key);
	else
		return true;
	}


}
