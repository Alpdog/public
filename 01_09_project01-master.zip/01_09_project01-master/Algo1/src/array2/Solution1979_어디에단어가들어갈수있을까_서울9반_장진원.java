package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1979_어디에단어가들어갈수있을까_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1979.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int i = 1; i <= T; i++) {
			int counter = 0;
			int N = sc.nextInt();
			int K = sc.nextInt();
			int[][] map = new int[N][N];

			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < N; j2++)
					map[j][j2] = sc.nextInt();
			}

			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < N; j2++) {
					if(map[j][j2] == 1) {
						if(countingDown(map, j, j2, N, K)) 
							counter++;
						if(countingRight(map, j, j2, N, K)) 
							counter++;
					}
				}
			}
			System.out.println("#" + i +  " " + counter);
			counter = 0;
		}
	}

	private static boolean countingDown(int[][] map, int row, int col, int N, int K) {
		int counter = 0;

		if(row >= 1 && map[row -1][col] == 1 )
			return false;

		for (int i = row; i < N; i++) {
			if(map[i][col] == 1)
				counter++;
			if(map[i][col] == 0)
				break;
		}
		if(counter == K)
			return true;
		return false;
	}
	private static boolean countingRight(int[][] map, int row, int col, int N, int K) {
		int counter = 0;
		if(col >= 1 && map[row][col-1] == 1 )
			return false;	

		for (int i = col; i < N; i++) {
			if(map[row][i] == 1)
				counter++;
			if(map[row][i] == 0)
				break;
		}
		if(counter == K)
			return true;
		return false;
	}
}
