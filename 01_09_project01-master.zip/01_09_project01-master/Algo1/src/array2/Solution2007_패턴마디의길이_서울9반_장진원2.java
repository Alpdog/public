package array2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution2007_패턴마디의길이_서울9반_장진원2 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input2007.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int testCase = 1; testCase <= T; testCase++) {

			String temp = sc.next();

			aaa:for (int i = 2; i < 11; i++) {

				String temp1 =  temp.substring(0, i);
				String temp2 = temp.substring(i,2*i);

				if(temp1.equals(temp2)) {
					System.out.println("#" + testCase + " " + temp1.length());
					break aaa;
				}
			}
		}
	}	
}