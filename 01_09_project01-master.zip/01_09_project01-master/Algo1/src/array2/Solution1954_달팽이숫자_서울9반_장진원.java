package array2;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Scanner;

public class Solution1954_달팽이숫자_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1954.txt")); //제출시 삭제
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();

		for (int testCase = 1; testCase <= T; testCase++) {
			int N = sc.nextInt();
			System.out.println("#"+ testCase);
			int counter = 1;
			int counter3 = 0;

			int[][] map = new int[N][N];
			while(counter != N*N+1) {
				for (int j = counter3; j < N-counter3; j++) {
					map[counter3][j] = counter++;
					if(counter == N*N+1) break;
				}
				for (int j = counter3+1; j < N-1-counter3; j++) {
					map[j][N-1-counter3] = counter++;
					if(counter == N*N+1) break;
				}
				for (int j = N-1-counter3; j > counter3 ; j--) {
					map[N-1-counter3][j] = counter++;
					if(counter == N*N+1) break;
				}
				for (int j = N-1-counter3; j > counter3; j--) {
					map[j][counter3] = counter++;
					if(counter == N*N+1) break;
				}
				counter3++;
			}
			for (int i = 0; i < map.length; i++) {
				for (int j = 0; j < map.length; j++) {
					System.out.print(map[i][j] + " ");
				}
				System.out.println();
			}
		}
	}
}
