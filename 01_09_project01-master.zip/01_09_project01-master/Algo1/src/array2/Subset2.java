package array2;

public class Subset2 {
	public static int[] data = {1,2,3,4};
	
	public static void main(String[] args) {
		int sum = 0;
		int counter = 0;
		for (int i = 0; i < (1<<data.length); i++) {
			for (int j = 0; j < data.length; j++) {
				if((i&(1<<j)) == (1<<j)) 
					sum+= data[j];
			}
			if(sum == 5)
				counter++;
			sum = 0;
		}
		System.out.println(counter);
	}
}
