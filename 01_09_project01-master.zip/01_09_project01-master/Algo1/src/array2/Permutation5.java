package array2;

import java.util.Arrays;
import java.util.Scanner;

public class Permutation5 {
	public static int n, r, data[], caseCount;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		n = 6; //주사위 6까지 있음
		r = 3; //뽑는 개수
		data = new int[r];

		permutation(1, 0, 0);

		System.out.println(caseCount);
		sc.close();
	}

	public static void permutation(int before, int flag, int count) {
		if(count == r) {
			caseCount++;
			System.out.println(Arrays.toString(data));
			return;
		}

		for (int i = before; i <= n; i++) { // 1부터 시작하면 순열, before 부터 시작하면 조합
			if((flag&1<<i) == 0) {
				data[count] = i;
				permutation(i+1, flag|1<<i, count+1); // 사용된 번째의 숫자는 flag를 | 연산을 이용하여 1로 바꿔줌
			}
		}
	}
}
