package string;

import java.util.Arrays;

public class StringTest {
	public static void main(String[] args) {
		String s = "123";
		int i = Integer.parseInt(s);
		String i2 = new Integer(i).toString();
		
		System.out.println(s+4);
		System.out.println(i+4);
		System.out.println(i2+4);
		System.out.println(""+i+4);
		
/*		String s1 = "홍길동";
		String s2 = "홍길동";
		String t1 = new String("홍길동");
		String t2 = new String("홍길동");
		
		String[] sa = s1.split(" ");
		System.out.println(s1.substring(0,2));
		System.out.println(s1.substring(0,1));
		System.out.println(s1.substring(0,0));
		
		StringBuilder sb = new StringBuilder(s1);
		StringBuilder tb = new StringBuilder(s1);
		
		System.out.println(sb== tb);
		System.out.println(sb.toString().equals(tb.toString()));*/
		
/*		sb.reverse()
				.append(")")
				.insert(0,"[")
				.setLength(2);;
		
		String s = sb.toString();
		System.out.println(s);
		System.out.println("AVC".length());
		
		System.out.println(s1==  t1);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s2);
		System.out.println(s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(t1));*/
	
	}
}
