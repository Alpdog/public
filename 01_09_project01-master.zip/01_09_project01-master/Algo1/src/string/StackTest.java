package string;

import java.util.Stack;

public class StackTest {
	public static int[] stack = new int[1000];
	public static int top = 1;
	
	public static boolean push(int value) {
		if(top>stack .length)
			return false;
		stack[++top] = value;
		return true;
	}
	
	public static int pop() {
		if(top == -1 )
			return -1;
		int value = stack[top--];
		return value;
	}
	
	public static void main(String[] args) {
		push(1);
		System.out.println(pop());
		push(2);
		System.out.println(pop());
		push(3);
		System.out.println(pop());
		
		Stack<String> s = new Stack();
		System.out.println(pop());
	}


}
