package stack2;

import java.util.Arrays;

public class QuickSort {
	public static int[] a = {69, 19, 40, 2, 16, 8, 31, 22};
	public static void main(String[] args) {
		
		System.out.println(Arrays.toString(a));
		quick(0, a.length-1);
		System.out.println(Arrays.toString(a));
	}
	private static void quick(int start, int end) {
		if(start >= end)
			return;
		int T = start;
		int P = end;
		int L;
		
		for (L = start; L < P; L++) {
			if(a[L] > a[P]) {
				int temp = a[T];
				a[T] = a[L];
				a[L] = temp;
				T++;
			}
		}
		
		int temp = a[P];
		a[P] = a[T];
		a[T] = temp;
		
		quick(start, T-1);
		quick(T+1, end);
	}
}
