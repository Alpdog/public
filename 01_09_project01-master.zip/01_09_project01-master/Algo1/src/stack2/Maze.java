package stack2;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Maze {
	public static int[][] maze = new int[16][16];
	public static int cnt;
	public static int top;
	public static int[] di = {0,1,0,-1};
	public static int[] dj = {1,0,-1,0};
	public static int[] stack;
	public static int mapSize = 16;
	
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputMaze.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		for (int testCase = 1; testCase <= 10; testCase++) {
			stack = new int[(mapSize+1)*(mapSize+1)];
			top = -1;
			cnt = 0;
			
			for (int i = 0; i < args.length; i++) {
				String s = br.readLine();
				for (int j = 0; j < args.length; j++) {
					maze[i][j] = s.charAt(j) - '0';
				}
			}
			System.out.println("#" + testCase + " " + solve(1,1));
		}

	}
	private static int solve(int i, int j) {
		stack[++top] = i*(mapSize+1) + j;
		while(top != -1) {
			int curr = stack[top--];
			i = curr/(mapSize+1);
			j = curr%(mapSize+1);
			if(maze[i][j] <= 0) {
				maze[i][j] = --cnt;
				
				if(maze[i][j] == 3)
					return 1;
				
				for (int d = 0; d < 4; d++) {
					int ii = i + di[d];
					int jj = j + dj[d];
					if(( 0<= ii && ii <16) && (0 <= jj && jj < 16) && maze[ii][jj] == 0) {
						stack[++top]= ii*16 + jj;
					}
				}
			}
		}
		return 0;
	}
	
	private static void solver(int i, int j) {
		System.out.println();
		
		for (int[] a : maze)
			System.out.println(Arrays.toString(a));
		
		if(i == 15 && j == 15)
			return;
		
		for (int d = 0; d < 4; d++) {
			int ii = i + di[d];
			int jj = j + dj[d];
			if(( 0<= ii && ii <15) && (0 <= jj && jj < 15) && maze[ii][jj] == 0) {
				maze[ii][jj] = maze[i][j] -1;
				solver(ii,jj);
			}
		}
	}
}
