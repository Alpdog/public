package stack2;

public class Calculator {
	public static void main(String[] args) throws Exception {

		String s = "6528-*2/+";
		
		int[] stack = new int[100];
		int top = -1;
		
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			
			if('0' <= c && c <= '9')// char에서 정수를 판별하기 위해 이와 같은 수식을 사용
				stack[++top] = c - '0'; // push()
			else {
				int n2 = stack[top--]; //pop()
				int n1 = stack[top--]; //pop()
				int nn = 0;
				switch (c) {
				case '+': nn = n1 + n2; break;
				case '-': nn = n1 - n2; break;
				case '*': nn = n1 * n2; break;
				case '/': nn = n1 / n2; break;
				}
				stack[++top] = nn;
			}
		}
		System.out.print(stack[top]);
	}

}
