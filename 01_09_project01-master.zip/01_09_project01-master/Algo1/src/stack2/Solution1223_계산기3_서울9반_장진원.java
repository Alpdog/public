package stack2;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1223_계산기3_서울9반_장진원 {
	public static String s;
	public static char[] stack = new char[100];
	public static int top = -1;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputCalc2.txt"));
		Scanner sc = new Scanner(System.in);
		
		int[] stack2 = new int[100];
		int top2 = -1;

		for (int testCase = 1; testCase <= 10; testCase++) {
			int T = sc.nextInt();
			s =sc.next();
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < s.length(); i++) {
				char  c = s.charAt(i);

				if('0' <= c && c <= '9')		// 정수에 대한 부분
					sb.append(c);
				
				else if(c== ')') {  			// )에 대한 부분
					char t;
					while((t = stack[top--]) != '(')  	//pop
						sb.append(t);
					
				}else { 		// (, +, -, *, /에 대한 부분
					while(getICP(c) <= getISP()) {
						char t = stack[top--]; //pop();
						sb.append(t);
					}
					stack[++top] = c;
				}
			}
			
			while(top != -1)
				sb.append(stack[top--]);
			
			

			for (int i = 0; i < sb.length(); i++) {
				char c = sb.charAt(i);

				if('0' <= c && c <= '9')// char에서 정수를 판별하기 위해 이와 같은 수식을 사용
					stack2[++top2] = c - '0'; // push()
				else {
					int n2 = stack2[top2--]; //pop()
					int n1 = stack2[top2--]; //pop()
					int nn = 0;
					switch (c) {
					case '+': nn = n1 + n2; break;
					case '-': nn = n1 - n2; break;
					case '*': nn = n1 * n2; break;
					case '/': nn = n1 / n2; break;
					}
					stack2[++top2] = nn;
				}
			}
			System.out.println("#" + testCase + " " + stack2[top2]);
		}
	}

	private static int getISP() {
		char c = (top== -1)? '(' : stack[top]; // peek();

		switch (c) {
		case '+':
		case '-':
			return 1;	
		case '*':
		case '/':
			return 2;
		case '(':
			return 0;
		}
		return 0;
	}

	private static int getICP(char c) {
		switch (c) {
		case '+':
		case '-':
			return 1;	
		case '*':
		case '/':
			return 2;
		case '(':
			return 3;
		}
		return 0;
	}
}
