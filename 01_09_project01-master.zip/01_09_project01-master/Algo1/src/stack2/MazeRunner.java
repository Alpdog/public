package stack2;

import java.io.FileInputStream;
import java.util.Scanner;

public class MazeRunner {
	public static int[][] map = new int[16][16];
	static int[] dx = {0,1,0,-1};
	static int[] dy = {-1,0,1,0};
	static int testCase = 0;
	static boolean flag = false;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputMaze.txt"));
		Scanner sc = new Scanner (System.in);

		int T = 10;
		int sx = 0, sy = 0;

		for (testCase = 1; testCase <= 10; testCase++) {
			int g = sc.nextInt();

			for (int i = 0; i < 16; i++) {
				char[] temp = sc.next().toCharArray();
				for (int j = 0; j < 16; j++) {
					map[i][j] = (int)(temp[j]-'0');
					if(map[i][j] == 2) {
						sx = j;
						sy = i;
					}
				}
			}

			map[sy][sx] = 1;
			run(sx, sy);

			if(flag == true)
				System.out.println("# " + testCase + " 1");
			else
				System.out.println("# " + testCase + " 0"); 
			flag = false;
		}
	}

	private static void run(int col, int row) {
		int nx = col;
		int ny = row;


		for (int j = 0; j < 4; j++) {
			nx = col + dx[j];
			ny = row + dy[j];

			if(nx < 0 || ny < 0|| nx > 15 || ny > 15 || map[ny][nx] == 1)
				continue;

			if(map[ny][nx] == 3) {
				flag = true; 
				return;
			}
			if(map[ny][nx] == 0) {
				map[ny][nx] = 1;
				run(nx, ny);
				map[ny][nx] = 0;
			}
		}
	}
}
