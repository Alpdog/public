package DP;

import java.io.FileInputStream;
import java.util.Scanner;

public class Theater {
public static void main(String[] args) throws Exception {
	System.setIn(new FileInputStream("res/inputtheater.txt"));
	Scanner sc = new Scanner(System.in);
	
	int N = sc.nextInt();
	int[] seats = new int[N];
	int M = sc.nextInt();
	
	for (int i = 0; i < M; i++)
		seats[sc.nextInt()-1] = -1;
	
	int counter =0;
	int sum =1;
	
	for (int i = 0; i < N; i++) {
		counter++;
		if(seats[i] == -1) {
			sum *= add(counter-1);
			counter = 0;
		}
		else if(i == N-1) {
			sum *= add(counter);
			counter = 0;
		}
	}
		
	
	System.out.println(sum);
}

private static int add(int count) {
	int[] way = new int[41];
	way[0] = 1;
	way[1] = 1;
	way[2] = 2;
	if(count == 0)
		return 1;
	if(count == 1)
		return 1;
	if(count == 2)
		return 2;
	
	return way[count-1] + way[count-2];
}
}
