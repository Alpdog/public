package stack;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution5432_쇠막대기자르기_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input5432.txt"));
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		for (int testCase = 1; testCase <= T; testCase++) {
			String input = sc.next();
			
			char[] inputArray = input.toCharArray();
			int counter = 1;
			int sum = 0;
			
			for (int i = 1; i < inputArray.length; i++) {
				if(inputArray[i] == '(')
					counter++;
				else if(inputArray[i] == ')') {
					if(inputArray[i-1] == '(')
						sum+= counter-1;
					else
						sum++;

					counter--;
				}
			}
			
			System.out.println("#" + testCase + " " + sum);
		}
	}	
}