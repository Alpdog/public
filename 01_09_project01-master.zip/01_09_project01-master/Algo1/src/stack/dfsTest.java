package stack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class dfsTest {
	public static int V, E, top; //정점 V, 간선 E, index top
	public static int[] stack; 
	public static int[][] graph;
	public static boolean[] visit;
	
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/inputDFS.txt"));
		Scanner sc = new Scanner(System.in);
		V = sc.nextInt();
		E = sc.nextInt();
		graph = new int[V][V];
		visit = new boolean[V];
		stack = new int[100];
		top = -1;
		
		for (int i = 0; i < E; i++) {
			int v1 = sc.nextInt();
			int v2 = sc.nextInt();
			graph[v1][v2] = graph[v2][v1]=1;
		}
		
/*		System.out.print("#1 recursive ");
		DFSr(0);
		System.out.println();*/
		System.out.print("#2 iterative ");
		DFS(0);
		System.out.println();
	}

	private static void DFS(int node) {
		stack[++top] = node; // push
		while(top!=-1) {
			int current = stack[top--]; //pop
			if(visit[current] == false) {
				visit[current] = true;
				System.out.print(current + " ");
				
				for (int next = 0; next < V; next++) {
					if(visit[next] == false && graph[current][next] == 1) {
						stack[++top] = next; //push()
					}
				}
			}
		}
	}

	public static void DFSr(int node) {
		visit[node] = true;
		System.out.print(node + " ");
		for (int next = 0; next < V; next++) {
			if(visit[next] == false && graph[node][next] == 1) {
				DFSr(next);
			}
		}
	}
}
