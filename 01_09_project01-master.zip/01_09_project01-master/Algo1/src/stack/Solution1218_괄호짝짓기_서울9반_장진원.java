package stack;

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution1218_괄호짝짓기_서울9반_장진원 {

	public static void main(String[] args) throws Exception{
		System.setIn(new FileInputStream("res/input1218.txt"));
		Scanner sc = new Scanner(System.in);

		aaa:for (int testCase = 1; testCase <= 10; testCase++) {
			int length = sc.nextInt();
			String temp = sc.next();
			char[] tempCharArray = temp.toCharArray();
			char[] stack = new char[length];
			
			int counter = 0;
			
			for (int i = 0; i < tempCharArray.length; i++) {
				if(tempCharArray[i] == '(' || tempCharArray[i] == '[' || tempCharArray[i] == '{' || tempCharArray[i] == '<')
					stack[counter++] = tempCharArray[i];
				else if(tempCharArray[i] == ')') {
					if(stack[counter-1] == '(')
						counter--;
					else {
						System.out.println("#" + testCase + " 0");
						counter = 0;
						continue aaa;
					}
				}
				else if(tempCharArray[i] == ']') {
					if(stack[counter-1] == '[')
						counter--;
					else {
						System.out.println("#" + testCase + " 0");
						counter = 0;
						continue aaa;
					}
				}
				else if(tempCharArray[i] == '}' ) {
					if(stack[counter-1] == '{') 
						counter--;
					else {
						System.out.println("#" + testCase + " 0");
						counter = 0;
						continue aaa;
					}
				}
				else if(tempCharArray[i] == '>') {
					if(stack[counter-1] == '<')
						counter--;
					else {
						System.out.println("#" + testCase + " 0");
						counter = 0;
						continue aaa;
					}
				}
			}
			
			if(counter == 0)
				System.out.println("#" + testCase + " 1");
			else
				System.out.println("#" + testCase + " 0");
			
			counter = 0;
		}
	}	
}