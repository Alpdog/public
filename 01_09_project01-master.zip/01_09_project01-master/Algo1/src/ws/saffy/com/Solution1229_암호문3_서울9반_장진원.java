package ws.saffy.com;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Solution1229_암호문3_서울9반_장진원 {
	public static void main(String[] arg) throws Exception {
		System.setIn(new FileInputStream("res/inputPwd3.txt"));
		Scanner sc = new Scanner(System.in);

		for (int testCase = 1; testCase <= 10; testCase++) {
			int length = sc.nextInt();
			ArrayList<Integer> numbers = new ArrayList<Integer>();
			for (int i = 0; i < length; i++) {
				numbers.add(sc.nextInt());
			}

			int numberOfOrders = sc.nextInt();
			int counter = 0;
			while(counter<numberOfOrders) {
				String temp = sc.next();
				if(temp.equals("I")) {
					counter++;
					int index = sc.nextInt();
					int orderLength = sc.nextInt();
					for (int i = 0; i < orderLength; i++) {
						numbers.add(index++, sc.nextInt());
					}
				}
				else if(temp.equals("D")) {
					counter++;
					int index = sc.nextInt();
					int deleteLength = sc.nextInt();
					for (int i = 0; i < deleteLength; i++) {
						numbers.remove(index);
					}
				}
				else if(temp.equals("A")) {
					counter++;
					int addLength = sc.nextInt();
					for (int i = 0; i < addLength; i++) {
						numbers.add(sc.nextInt());
					}
				}

			}
			System.out.print("#" + testCase);
			for (int i = 0; i < 10; i++)
				System.out.print(" " + numbers.get(i));
			System.out.println();
		}
	}
}
