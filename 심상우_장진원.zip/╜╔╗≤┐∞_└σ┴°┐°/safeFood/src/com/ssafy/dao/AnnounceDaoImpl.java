package com.ssafy.dao;

import java.util.LinkedList;
import java.util.List;
import com.ssafy.vo.Announce;

public class AnnounceDaoImpl implements AnnounceDao{
	private List<Announce> announces = null;
	private int idx;
	public AnnounceDaoImpl() {
		if(announces==null) {
			announces = new LinkedList<Announce>();
			idx = 0;
		}
	}
	@Override
	public void add(Announce announce) {
		announce.setIdx(idx++);
		announces.add(announce);
		return ;
	}
	@Override
	public List<Announce> searchAll() {
		List<Announce> total = new LinkedList<>();
		for (Announce announce : announces) {
			total.add(announce);
		}
		return total;
	}

	@Override
	public Announce search(int idx) {
		for (Announce announce : announces) {
			if (announce.getIdx()==idx) {
				return announce;
			}
		}
		return null;
	}

	@Override
	public boolean delete(int idx) {
		for (Announce announce : announces) {
			if (announce.getIdx()==idx) {
				announces.remove(announce);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean update(Announce announce) {
		for (Announce ann : announces) {
			if (announce.getIdx()==ann.getIdx()) {
				announces.set(announce.getIdx(), announce);
				return true;
			}
		}
		return false;
	}
	
}
