package com.ssafy.notice;

import java.sql.SQLException;
import java.util.List;

public interface NoticeDAOInterface {
	//등록
	void addNotice(NoticeVO vo) throws SQLException;
	//수정
	void setNotice(NoticeVO vo) throws SQLException;
	//삭제
	void deleteNotice(int noticeIdx) throws SQLException;
	//검색(모두, 번호, 사용자, 제목)
	List<NoticeVO> getAllNotice() throws SQLException;
	NoticeVO getNotice(int noticeIdx) throws SQLException;
	List<NoticeVO> getNoticeByUser(String user) throws SQLException;
	List<NoticeVO> getNoticeByTitle(String title) throws SQLException;
}
