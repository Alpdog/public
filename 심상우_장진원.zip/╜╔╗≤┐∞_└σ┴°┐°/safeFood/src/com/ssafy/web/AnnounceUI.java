package com.ssafy.web;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.notice.NoticeDAO;
import com.ssafy.notice.NoticeVO;

public class AnnounceUI implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		 try {
			List<NoticeVO> list=new NoticeDAO().getAllNotice();
			request.setAttribute("noticeList", list);
		} catch (ClassNotFoundException | SQLException e) {
			// 에러 페이지 전달
			e.printStackTrace();
		}		
		return "announcementBoard.jsp";
	}

}
