package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProductInfo implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return "productInfo.jsp";
	}

}
