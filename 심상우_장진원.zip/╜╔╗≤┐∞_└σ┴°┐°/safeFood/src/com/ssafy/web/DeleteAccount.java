package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteAccount implements Controller {
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		request.getSession(true).setAttribute("id", null);
		return "/main.jsp";
	}
}
