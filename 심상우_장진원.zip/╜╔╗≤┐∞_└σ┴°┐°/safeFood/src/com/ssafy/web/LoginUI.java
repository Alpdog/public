package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginUI implements Controller {
	
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "/login.jsp";
	}
}
