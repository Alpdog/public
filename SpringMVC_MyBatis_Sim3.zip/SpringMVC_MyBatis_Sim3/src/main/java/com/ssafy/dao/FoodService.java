package com.ssafy.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.vo.Food;
import com.ssafy.vo.FoodPageBean;

@Service
public interface FoodService {
	public List<Food> searchAll(FoodPageBean bean);
	public Food search (int code);
	public List<Food> searchBest();
	public List<Food> searchBestIndex();
}
