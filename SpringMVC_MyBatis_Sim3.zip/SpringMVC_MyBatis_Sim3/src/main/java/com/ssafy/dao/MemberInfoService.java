package com.ssafy.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ssafy.dao.MemberInfoDAO;

@Service
public class MemberInfoService {

	@Autowired
	MemberInfoDAO memberInfoDao;
	
	public boolean addMemberInfo(String id, String pw, String name, String allergy){
		return memberInfoDao.addMemberInfo(id, pw, name, allergy);
	}
	
	public boolean deleteMemberInfo(String id){
		return memberInfoDao.deleteMemberInfo(id);
	}
	
	public boolean updateMemberInfo(String id, String pw, String name, String allergy){
		return memberInfoDao.updateMemberInfo(id, pw, name, allergy);
	}
	
	public String searchMemberInfo(String id, String pw) {
		return memberInfoDao.searchMemberInfo(id, pw);
	}
	
	
	public List<Map<String, Object>> getAllBooks(){
		return memberInfoDao.getAllMemberInfo();
	}
	
}
