package com.ssafy.emp;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository   //mybatis -- jdbc
public class NoticeDAO {
	@Autowired
    private SqlSessionTemplate sqlSession;
	
	public boolean noticeInsertint (String title,int category, String user, String content,
			String attached_file) {
		int s = (int)sqlSession.insert("notice.NoticeInsert",new NoticeVO(0, title, null, category, user, content, attached_file, false, 0));
		if(s!=0) return true;
		return false;
	}
	public List<Map<String, Object>> getAllNotices(){
		System.out.println("getAllNotices sqlSession: "+sqlSession);
		return sqlSession.selectList("notice.NoticeName");
	}
	public NoticeVO getNoticeByIdx(int notice_idx){
		return sqlSession.selectOne("notice.NoticeNameByIdx", notice_idx);
	}
	public boolean NoticeDelete(int notice_idx) {
		int s = (int)sqlSession.delete("notice.NoticeDelete",notice_idx);
		if(s!=0) return true;
		return false;
	}
	public boolean setNotice(NoticeVO noticeVO) {
		int s = (int)sqlSession.update("notice.NoticeUpdate",noticeVO);
		if(s!=0) return true;
		return false;
	}
	public boolean noticeCheckDelAction(String notice_idx) {
		int s = (int)sqlSession.delete("notice.noticeCheckDelAction",notice_idx);
		if(s==notice_idx.split(",").length) return true;
		return false;
	}
}
