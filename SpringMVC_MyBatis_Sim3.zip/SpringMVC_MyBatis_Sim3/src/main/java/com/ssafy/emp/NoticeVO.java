package com.ssafy.emp;

import org.springframework.stereotype.Repository;

@Repository   //mybatis -- jdbc
public class NoticeVO {
	private int notice_idx;
	private String title;
	private String date;
	private int category;
	private String user;
	private String content;
	private String attached_file;
	private boolean isDeleted;
	private int view;
	
	public NoticeVO() {}

	public NoticeVO(int notice_idx, String title, String date, int category,  String content,String attached_file) {
		this.notice_idx = notice_idx;
		this.title = title;
		this.date = date;
		this.category = category;
		this.content = content;
		this.attached_file = attached_file;
	}
	public NoticeVO(int notice_idx, String title, String date, int category, String user, String content,
			String attached_file, boolean isDeleted, int view) {
		this.notice_idx = notice_idx;
		this.title = title;
		this.date = date;
		this.category = category;
		this.user = user;
		this.content = content;
		this.attached_file = attached_file;
		this.isDeleted = isDeleted;
		this.view = view;
	}
	public int getNotice_idx() {
		return notice_idx;
	}
	public void setNotice_idx(int notice_idx) {
		this.notice_idx = notice_idx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAttached_file() {
		return attached_file;
	}
	public void setAttached_file(String attached_file) {
		this.attached_file = attached_file;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public int getView() {
		return view;
	}
	public void setView(int view) {
		this.view = view;
	}
	@Override
	public String toString() {
		return "NoticeVO [notice_idx=" + notice_idx + ", title=" + title + ", date=" + date + ", category=" + category
				+ ", user=" + user + ", content=" + content + ", attached_file=" + attached_file + ", isDeleted="
				+ isDeleted + ", view=" + view + "]";
	}
	
}
