package com.ssafy.emp;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NoticeService {
	@Autowired
	NoticeDAO noticeDao;

	public List<Map<String, Object>> getAllNotices(){
		return noticeDao.getAllNotices();
	}
	public boolean NoticeInsertint (String title,int category, String user, String content,
			String attached_file) {
		return noticeDao.noticeInsertint(title,category, user, content, attached_file);
	}
	public NoticeVO getNotice(int notice_idx) {
		return noticeDao.getNoticeByIdx(notice_idx);
	}
	public boolean NoticeDelete(int NoticeNum) {
		return noticeDao.NoticeDelete(NoticeNum);
	}
	public boolean setNotice(NoticeVO noticeVO) {
		return noticeDao.setNotice(noticeVO);
	}
	public boolean noticeCheckDelAction(String notice_idx) {
		return noticeDao.noticeCheckDelAction(notice_idx);
	}
	
}
