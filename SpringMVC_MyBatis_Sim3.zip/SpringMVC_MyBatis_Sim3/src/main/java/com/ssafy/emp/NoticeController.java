package com.ssafy.emp;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class NoticeController {
	@Autowired
	NoticeService noticeService;
	
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	
	@RequestMapping(value = "/noticeInsertUI", method = RequestMethod.GET)
	public String noticeInsertUI () {
		return "noticeInsertUI";
	}
	
	@RequestMapping(value = "/noticeListUI", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView noticeListUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeListUI");
		mv.addObject("list", noticeService.getAllNotices());
		return mv;
	}
	@RequestMapping(value = "/noticeInsertAction", method = RequestMethod.POST)
	public ModelAndView noticeInsertAction(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeResultUI");
		String title = request.getParameter("title");
		String category = request.getParameter("category");
		String content = request.getParameter("content");
		if(noticeService.NoticeInsertint(title, Integer.parseInt(category), "추가바람", content, null)) {
			mv.addObject("result", "정상적으로 추가되었습니다.");
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	@RequestMapping(value = "/noticeViewUI", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView noticeViewUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeViewUI");
		String notice_idx = request.getParameter("notice_idx");
		System.out.println(notice_idx);
		NoticeVO temp = noticeService.getNotice(Integer.parseInt(notice_idx));
		System.out.println(temp);
		mv.addObject("selected", temp);
		
		return mv;
	}
	@RequestMapping(value = "/noticeCheckDelAction", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView noticeCheckDelAction(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeResultUI");
		String[] notice_idxs = request.getParameterValues("notice_idx");
		String notice_idx="";
		for (int i = 0; i < notice_idxs.length-1; i++) {
			notice_idx+=notice_idxs[i]+",";
		}
		notice_idx+=notice_idxs[notice_idxs.length-1];
		if(noticeService.noticeCheckDelAction(notice_idx)) {
			mv.addObject("result", "정상적으로 삭제 되었습니다.");
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	@RequestMapping(value = "/noticeDeleteAction", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView noticeDeleteAction(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeResultUI");
		String notice_idx = request.getParameter("notice_idx");

		if(noticeService.NoticeDelete(Integer.parseInt(notice_idx))) {
			mv.addObject("result", "정상적으로 삭제 되었습니다.");
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	@RequestMapping(value = "/noticeUpdateUI", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView noticeUpdateUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeUpdateUI");
		String notice_idx = request.getParameter("notice_idx");
		mv.addObject("selected", notice_idx);
		return mv;
	}
	
	@RequestMapping(value = "/noticeUpdateAction", method = RequestMethod.POST)
	public ModelAndView noticeUpdateAction(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeResultUI");
		int notice_idx = Integer.parseInt(request.getParameter("notice_idx"));
		String title = request.getParameter("title");
		int category = Integer.parseInt(request.getParameter("category"));
		String content = request.getParameter("content");
		boolean temp = noticeService.setNotice(new NoticeVO(notice_idx, title, null, category, null, content, null, false, 0));
		if(temp) {
			mv.addObject("selected", temp);
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	
//	@RequestMapping(value = "/main", method = RequestMethod.GET)
//	public ModelAndView mainUI(HttpServletRequest request) {
//		ModelAndView mv = new ModelAndView("main");
//		mv.addObject("foods", foodService.searchAll(null));
//		return mv;
//	}

	
//	@ExceptionHandler(RuntimeException.class)
//	public ModelAndView exceptionPage(RuntimeException e) {
//		Map<String, String> model = new HashMap<String, String>();
//		model.put("exception_info", e.getMessage());
//		model.put("code", "5XX");
//		return new ModelAndView("error/error_page", model);
//	}
}
