package com.ssafy.emp;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.dao.FoodService;
import com.ssafy.dao.FoodServiceImpl;
import com.ssafy.dao.MemberInfoService;

@Controller
public class FoodController {
	@Autowired
	FoodServiceImpl foodService;
	
	private static final Logger logger = LoggerFactory.getLogger(FoodController.class);
	
	@RequestMapping(value = "/mainUI", method = RequestMethod.GET)
	public ModelAndView mainUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("main");
		mv.addObject("foods", foodService.searchAll(null));
		return mv;
	}

//	@ExceptionHandler(RuntimeException.class)
//	public ModelAndView exceptionPage(RuntimeException e) {
//		Map<String, String> model = new HashMap<String, String>();
//		model.put("exception_info", e.getMessage());
//		model.put("code", "5XX");
//		return new ModelAndView("error/error_page", model);
//	}
}
