package com.ssafy.emp;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.dao.FoodService;
import com.ssafy.dao.FoodServiceImpl;
import com.ssafy.dao.MemberInfoService;

@Controller
public class MemberController {
	@Autowired
	MemberInfoService memberInfoService;
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@RequestMapping(value = "/loginUI", method = RequestMethod.GET)
	public String loginUI () {
		return "login";
	}
	
	@RequestMapping(value = "/loginAction", method = RequestMethod.POST)
	public ModelAndView loginAction(HttpServletRequest request) {
		ModelAndView mv;
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String loginID = memberInfoService.searchMemberInfo(id, pw);
		if(loginID != null) {
			mv = new ModelAndView("main");
			mv.addObject("loginID", loginID);
		}else {
			mv = new ModelAndView("login");
		}
		return mv;
	}
	
	
/*	@RequestMapping(value = "/mainUI", method = RequestMethod.GET)
	public ModelAndView mainUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("main");
		mv.addObject("foods", foodService.searchAll(null));
		return mv;
	}*/


	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		return "home";
	}
	
//	@ExceptionHandler(RuntimeException.class)
//	public ModelAndView exceptionPage(RuntimeException e) {
//		Map<String, String> model = new HashMap<String, String>();
//		model.put("exception_info", e.getMessage());
//		model.put("code", "5XX");
//		return new ModelAndView("error/error_page", model);
//	}
}
