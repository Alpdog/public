package com.ssafy.vo;

public class MemberInfoVO {

	private String id;
	private String pw;
	private String name;
	private String allergy;
	
	public MemberInfoVO(String id, String pw, String name, String allergy) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.allergy = allergy;
	}
	
	public MemberInfoVO(String id) {
		super();
		this.id = id;
	}
	
	public MemberInfoVO(String id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAllergy() {
		return allergy;
	}
	public void setAllergy(String allergy) {
		this.allergy = allergy;
	}
	@Override
	public String toString() {
		return "MemberInfoVO [id=" + id + ", pw=" + pw + ", name=" + name + ", allergy=" + allergy + "]";
	}
}
