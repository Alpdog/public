package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.servlet.http.HttpSession;

import com.ssafy.vo.Client;



public class LoginDAO implements LoginDAOInterface {

	private static Connection conn;
	private static LoginDAO ldao;
	
	private LoginDAO() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");	//new String() new Driver()
		String url ="jdbc:mysql://127.0.0.1:3306/my_schema?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		conn = DriverManager.getConnection(url, "root","root");
	}
	
	public static LoginDAO getInstance() throws ClassNotFoundException, SQLException {
		if(ldao == null)
			ldao = new LoginDAO();
		return ldao;
	}
	
	@Override
	public String loginSearch(String id, String pw) throws SQLException {
		String sql = "select id from member_info where id = ? and password = ?";
		String resultId = "";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				resultId = rs.getString(1);
				System.out.println(resultId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultId;
	}

	@Override
	public void addUser(Client c) throws SQLException {
		String sql = "insert into member_info values(?,?,?, ?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, c.getId());
			pstmt.setString(2, c.getPassword());
			pstmt.setString(3, c.getName());
			pstmt.setString(4, Arrays.deepToString(c.getAllergy()));
			pstmt.executeUpdate();
			} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public String findPassword(String id) throws SQLException {
		String sql = "select pw from member_info where id = ?";
		String found = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				found = rs.getString(1);
			}
			
			} catch (Exception e) {
			e.printStackTrace();
		}
		
		return found;
	}

	@Override
	public void updatePassword(String id) throws SQLException {
		
		//c.get(((Client) sess.getAttribute("client")).getId()).setPw(req.getParameter("pw"));
		String sql = "update pw from member_info where id = ?";
		String found = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				found = rs.getString(1);
			}
			
			} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Client getClientInfo(String id) throws SQLException {
		String sql = "select id, name, allergy from member_info where id = ?";
		Client found = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				found = new Client(rs.getString(1), "", rs.getString(2), rs.getString(3).split(","));
			}
			
			} catch (Exception e) {
			e.printStackTrace();
		}
		
		return found;
	}
	
	
}
