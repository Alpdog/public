package com.ssafy.dao;

import java.sql.SQLException;

import com.ssafy.vo.Client;

public interface LoginDAOInterface {

	String loginSearch(String id, String pw) throws SQLException ;
	void addUser(Client c) throws SQLException;
	String findPassword(String id) throws SQLException;
	void updatePassword(String id) throws SQLException;
	Client getClientInfo(String id) throws SQLException;
}
