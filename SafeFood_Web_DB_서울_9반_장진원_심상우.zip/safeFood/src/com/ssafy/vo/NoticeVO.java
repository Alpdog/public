package com.ssafy.vo;

public class NoticeVO {
	private int noticeIdx;
	private String title;
	private int category;
	private String user;
	private String content;
	private String attachedFile;
	private boolean isDeleted;
	private int views;
	public NoticeVO() {}
	public NoticeVO(int noticeIdx, String title, int category, String user, String content, String attachedFile,
			boolean isDeleted, int views) {
		this.noticeIdx = noticeIdx;
		this.title = title;
		this.category = category;
		this.user = user;
		this.content = content;
		this.attachedFile = attachedFile;
		this.isDeleted = isDeleted;
		this.views = views;
	}
	public int getNoticeIdx() {
		return noticeIdx;
	}
	public void setNoticeIdx(int noticeIdx) {
		this.noticeIdx = noticeIdx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAttachedFile() {
		return attachedFile;
	}
	public void setAttachedFile(String attachedFile) {
		this.attachedFile = attachedFile;
	}
	public boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	@Override
	public String toString() {
		return "noticeVO [noticeIdx=" + noticeIdx + ", title=" + title + ", category=" + category + ", user=" + user
				+ ", content=" + content + ", attachedFile=" + attachedFile + ", isDeleted=" + isDeleted + ", views="
				+ views + "]";
	}
	
}
