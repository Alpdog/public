package com.ssafy.vo;

public class Client {
	String id;
	String password;
	String name;
	String[] allergy;
	
	public Client(String id, String password, String name, String[] allergy) {
		super();
		this.id = id;
		this.password = password;
		this.name = name;
		this.allergy = allergy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String[] getAllergy() {
		return allergy;
	}

	public void setAllergy(String[] allergy) {
		this.allergy = allergy;
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", password=" + password + ", name=" + name + ", allergy=" + allergy + "]";
	}

}
