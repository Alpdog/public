package com.ssafy.util;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.ssafy.vo.Food;

/**
 * FoodNutritionSAXHandler와 FoodSAXHandler를 이용해서 식품 정보를 load하는 SAX Parser 프로 그램  
 *
 */
public class FoodSaxParser {
	private String[] allergys={"대두","땅콩","우유","게","새우","참치","연어","쑥","소고기","닭고기","돼지고기","복숭아","민들레","계란흰자"}; 
	private String nutritionFilePath = "db/FoodNutritionInfo.xml";
	private String foodFilePath = "db/foodInfo.xml"; 
	private StringBuilder xml ;
	private List<Food> foods;
	private static Connection conn;
	public FoodSaxParser() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");	//new String() new Driver()
		String url ="jdbc:mysql://127.0.0.1:3306/my_schema?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		conn = DriverManager.getConnection(url, "root","root");
		loadData();
	}

	/**
	 * FoodNutritionSAXHandler와 FoodSAXHandler를 이용 파싱한 식품 정보와 식품 영양 정보를  Food에 병합한다. 
	 */
	private void loadData() {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		try{
			SAXParser parser = factory.newSAXParser();
			FoodSAXHandler handler = new FoodSAXHandler();
			FoodNutritionSAXHandler nHandler = new FoodNutritionSAXHandler();
			parser.parse(foodFilePath,handler);
			parser.parse(nutritionFilePath,nHandler);
			Map<String, Food> foodMap = handler.getFoods();
			foods = nHandler.getList();
			Food find;
			for (Food food : foods) {
				find = foodMap.get(food.getName());
				if(find!=null) {
					food.setCode(find.getCode());
					food.setName(find.getName());
					food.setMaker(find.getMaker());
					food.setMaterial(find.getMaterial());
					food.setImg(find.getImg());

					String tempAllergy = "";
					for (String allergy : allergys) {
						if (food.getMaterial().contains(allergy)) {
							tempAllergy += allergy+",";
						}
					}
					if(tempAllergy.length()!=0) {
						tempAllergy=tempAllergy.substring(0,tempAllergy.length()-1);
					}
					food.setAllergy(tempAllergy);
					String sql = "insert into food values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,0)";
					try {
						PreparedStatement pstmt = conn.prepareStatement(sql);
						pstmt.setInt(1, food.getCode());
						pstmt.setString(2, food.getName());
						pstmt.setDouble(3, food.getSupportpereat());
						pstmt.setDouble(4, food.getCalory());
						pstmt.setDouble(5, food.getCarbo());
						pstmt.setDouble(6, food.getProtein());
						pstmt.setDouble(7, food.getFat());
						pstmt.setDouble(8, food.getSugar());
						pstmt.setDouble(9, food.getNatrium());
						pstmt.setDouble(10, food.getChole());
						pstmt.setDouble(11, food.getFattyacid());
						pstmt.setDouble(12, food.getTransfat());
						pstmt.setString(13, food.getMaker());
						pstmt.setString(14, food.getMaterial());
						pstmt.setString(15, food.getImg());
						pstmt.setString(16, food.getAllergy());
						pstmt.executeUpdate();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public List<Food> getFoods() {
		String sql = "SELECT code, name, supportpereat, calory, carbo, protein, fat, sugar, natrium, chole, fattyacid, transfat, maker, material, img, allergy, views FROM FOOD";
		List<Food> temp = new ArrayList<>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				temp.add(new Food(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getDouble(4),
						rs.getDouble(5), rs.getDouble(6), rs.getDouble(7), rs.getDouble(8),
						rs.getDouble(9), rs.getDouble(10), rs.getDouble(11), rs.getDouble(12),
						rs.getString(13),rs.getString(14),rs.getString(15),rs.getString(16),
						rs.getInt(17)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return temp;
	}
	public void setFoods(List<Food> foods) {
		this.foods = foods;
	}

}
