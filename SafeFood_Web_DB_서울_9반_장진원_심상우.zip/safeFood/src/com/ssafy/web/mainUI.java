package com.ssafy.web;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.service.FoodServiceImpl;
import com.ssafy.vo.FoodPageBean;

public class mainUI implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		FoodPageBean fpb = new FoodPageBean((String)request.getAttribute("key"), (String)request.getAttribute("word"), null, 1);
		
		try {
			request.setAttribute("foods", new FoodServiceImpl().searchAll(fpb));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "main.jsp";
	}

}
