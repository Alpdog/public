package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchNotice implements Controller {
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "/noticeBoard.jsp";
	}
}
