package com.ssafy.web;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.dao.NoticeDAO;
import com.ssafy.vo.NoticeVO;

public class NoticeUI implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		 try {
			List<NoticeVO> list= NoticeDAO.getInstance().getAllNotice();
			request.setAttribute("noticeList", list);
		} catch (ClassNotFoundException | SQLException e) {
			// 에러 페이지 전달
			e.printStackTrace();
		}		
		return "noticeBoard.jsp";
	}

}
