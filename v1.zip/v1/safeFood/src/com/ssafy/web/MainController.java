package com.ssafy.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.LoginDAO;
import com.ssafy.dao.NoticeDAO;
import com.ssafy.service.FoodService;
import com.ssafy.service.FoodServiceImpl;
import com.ssafy.vo.Client;
import com.ssafy.vo.FoodPageBean;

@WebServlet("*.do")
public class MainController extends HttpServlet {
	private FoodService foodService;
	private NoticeDAO dao;
	private LoginDAO ldao;
	private static final long serialVersionUID = 1L;
	private Map<String, Controller> list;
	private HashMap<String, Client> c;
	
	HttpSession sess;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(req.getRequestURI());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(req.getRequestURI() + " at post");
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			dao = NoticeDAO.getInstance();
			ldao = LoginDAO.getInstance();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			foodService = new FoodServiceImpl();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c = new HashMap<String, Client>();

		list = new HashMap<>();
		list.put("/main.do", new mainUI());
		list.put("/login.do", new LoginUI());
		list.put("/logout.do", new LogOut());
		list.put("/join.do", new JoinUI());
		list.put("/reqJoin.do", new JoinUI());
		list.put("/search.do", new Search());
		list.put("/searchFoodInfo.do", new SearchFoodInfo());
		list.put("/detailFoodInfo.do", new DetailFoodInfo());
		list.put("/productInfo.do", new ProductInfo());
		list.put("/memberInfo.do", new MemberInfo());
		list.put("/itemInfo.do", new itemInfo());
		list.put("/findPW.do", new FindPW());
		list.put("/update.do", new Update());
		list.put("/delete.do", new Delete());
		list.put("/notice.do", new NoticeUI());
		list.put("/insertNotice.do", new InsertNotice());
		list.put("/searchNotice.do", new SearchNotice());
		list.put("/detailNotice.do", new DeleteNotice());
		list.put("/updateNotice.do", new UpdateNotice());

	};

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String cmd = (req.getRequestURI().substring(req.getContextPath().length()));
		String url = null;
		sess = req.getSession(true);

		if (cmd.equals("/*.do") || cmd.equals("/main.do"))
			url = "main.jsp";
		else if (cmd != null)
			url = list.get(cmd).getUrl(req, resp);

		switch (url.replace("/", "")) {
		case "main.jsp":
			if (req.getParameter("keyword") != null) {
				req.setAttribute("foods",
						foodService.searchAll(new FoodPageBean((String) req.getParameter("filter"), "신라면", null, 1)));
			} else {
				req.setAttribute("foods", foodService.searchAll(null));
			}
			break;
		case "productInfo.jsp":
			req.setAttribute("foods", foodService.searchAll(null));
			break;
		case "login.jsp":
			if (req.getParameter("id") != null && req.getParameter("pw") != null) {
				String temp = "";
				try {
					temp = ldao.loginSearch(req.getParameter("id"), req.getParameter("pw"));
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				if (temp.equals(""))
					System.out.println("invalid PW");
				else {
						// log on
						System.out.println("logon");
						sess.setAttribute("client", temp);
						url = "main.jsp";
						break;
					}
			}
			break;
		case "join.jsp":
			if (req.getParameter("id") != null && req.getParameter("pw") != null && req.getParameter("name") != null) {
				c.put((String) req.getParameter("id"),
						new Client(req.getParameter("id"), req.getParameter("pw"), req.getParameter("name")));
				url = "main.jsp";
			}
			break;
		case "findPW.jsp":
			System.out.println(req.getParameter("id"));
			if (c.containsKey(req.getParameter("id"))) {
				req.setAttribute("client", c.get(req.getParameter("id")));
				url = "alertPW.jsp";
			} else {
				// invalid id
				System.out.println("invalid ID");
			}
			break;
		case "update.jsp":
			c.get(((Client) sess.getAttribute("client")).getId()).setPw(req.getParameter("pw"));
			url = "main.jsp";
			break;

		case "delete.jsp":
			c.remove(((Client) sess.getAttribute("client")).getId());
			sess.setAttribute("client", null);
			url = "main.jsp";
			break;
		case "announcementBoard.jsp":
			try {
				req.setAttribute("noticeList", dao.getAllNotice());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

//		case "insertAnnounce.jsp":
//			announceDaoImpl.add(new Announce((String) req.getParameter("title"), "a", (String) req.getParameter("date"),
//					(String) req.getParameter("content")));
//			req.setAttribute("announces", announceDaoImpl.searchAll());
//			url = "announcementBoard.jsp";
//			break;
//
//		case "detailAnnounce.jsp":
//			announceDaoImpl.add(new Announce((String) req.getParameter("title"), "a", (String) req.getParameter("date"),
//					(String) req.getParameter("content")));
//			req.setAttribute("announces", announceDaoImpl.searchAll());
//			break;
		}

		req.getRequestDispatcher(url).forward(req, resp);
	}
}
	
