package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogOut implements Controller {
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		request.getSession(true).setAttribute("client", null);
		return "main.jsp";
	}
}
