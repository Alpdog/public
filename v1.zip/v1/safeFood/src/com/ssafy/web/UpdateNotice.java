package com.ssafy.web;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.dao.NoticeDAO;
import com.ssafy.vo.NoticeVO;

public class UpdateNotice implements Controller {
	public String getUrl(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		//NoticeDAO.getInstance().setNotice(new NoticeVO(noticeIdx, title, category, user, content, attachedFile, isDeleted, views));

		return "/noticeBoard.jsp";
	}
}
