package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddNotice implements Controller {

	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "/addNotice.jsp";
	}
}
