package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.NoticeVO;

public class NoticeDAO implements NoticeDAOInterface{
	private static Connection conn; 
	private static NoticeDAO dao;
	private NoticeDAO() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");	//new String() new Driver()
		String url ="jdbc:mysql://127.0.0.1:3306/my_schema?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		conn = DriverManager.getConnection(url, "root","root");
	}
	
	public static NoticeDAO getInstance() throws ClassNotFoundException, SQLException {
		if(dao == null)
			dao = new NoticeDAO();
		return dao;
	}
	@Override
	/**
	 * insert into notice_info values(1,'안녕',sysdate(),0,'심상우','안녕하세요',null,false,0);
	 */
	public void addNotice(NoticeVO vo) throws SQLException {
		String sql = "insert into notice_info values(?,?,sysdate(),?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getNoticeIdx());
			pstmt.setString(2, vo.getTitle());
			pstmt.setInt(3, vo.getCategory());
			pstmt.setString(4, vo.getUser());
			pstmt.setString(5, vo.getContent());
			pstmt.setString(6, vo.getAttachedFile());
			pstmt.setBoolean(7, vo.getIsDeleted());
			pstmt.setInt(8, vo.getViews());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setNotice(NoticeVO vo) throws SQLException {
		String sql = "update notice_info set title = ?, category = ?, user = ?, content = ?, attached_file = ?, date = sysdate() where notice_idx = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getTitle());
			pstmt.setInt(2, vo.getCategory());
			pstmt.setString(3, vo.getUser());
			pstmt.setString(4, vo.getContent());
			pstmt.setString(5, vo.getAttachedFile());
			pstmt.setInt(6, vo.getNoticeIdx());
			int i = pstmt.executeUpdate();

			if(i == 1)
				System.out.println("수정 완료");
			else
				System.out.println("수정 오류");
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	@Override
	public void deleteNotice(int noticeIdx) throws SQLException {
		String sql = "update notice_info set isdeleted = 1, date = sysdate()  where notice_idx = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, noticeIdx);
			int i = pstmt.executeUpdate();

			if(i == 1)
				System.out.println("삭제 완료");
			else
				System.out.println("삭제 오류");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public List<NoticeVO> getAllNotice() throws SQLException {
		List<NoticeVO> temp = new ArrayList<>();
		String sql = "select NOTICE_IDX, TITLE, DATE, CATEGORY, USER, CONTENT, ATTACHED_FILE, ISDELETED, VIEWS from notice_info";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				if(!rs.getBoolean(8))
				temp.add(new NoticeVO(rs.getInt(1), rs.getString(2), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getBoolean(8), rs.getInt(9)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return temp;
	}
	@Override
	public NoticeVO getNotice(int noticeIdx) throws SQLException {
		NoticeVO temp = null;
		String sql = "select NOTICE_IDX, TITLE, DATE, CATEGORY, USER, CONTENT, ATTACHED_FILE, ISDELETED, VIEWS from notice_info"
				+ " where NOTICE_IDX = ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, noticeIdx);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
				if(!rs.getBoolean(8))
				temp = new NoticeVO(rs.getInt(1), rs.getString(2), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getBoolean(8), rs.getInt(9));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return temp;
	}
	@Override
	public List<NoticeVO> getNoticeByUser(String user) throws SQLException {
		List<NoticeVO> temp = new ArrayList<>();
		String sql = "select NOTICE_IDX, TITLE, DATE, CATEGORY, USER, CONTENT, ATTACHED_FILE, ISDELETED, VIEWS from notice_info"
				+ " where USER = ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				if(!rs.getBoolean(8))
				temp.add(new NoticeVO(rs.getInt(1), rs.getString(2), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getBoolean(8), rs.getInt(9)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return temp;
	}
	@Override
	public List<NoticeVO> getNoticeByTitle(String title) throws SQLException {
		List<NoticeVO> temp = new ArrayList<>();
		String sql = "select NOTICE_IDX, TITLE, DATE, CATEGORY, USER, CONTENT, ATTACHED_FILE, ISDELETED, VIEWS from notice_info"
				+ " where TITLE like ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + title + "%");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				if(!rs.getBoolean(8))
				temp.add(new NoticeVO(rs.getInt(1), rs.getString(2), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getBoolean(8), rs.getInt(9)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return temp;
	}

}
