package com.ssafy.dao;

import java.sql.SQLException;

public interface LoginDAOInterface {

	String loginSearch(String id, String pw) throws SQLException ;
}
