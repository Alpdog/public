package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;



public class LoginDAO implements LoginDAOInterface {

	private static Connection conn;
	private static LoginDAO ldao;
	
	private LoginDAO() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");	//new String() new Driver()
		String url ="jdbc:mysql://127.0.0.1:3306/my_schema?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		conn = DriverManager.getConnection(url, "root","root");
	}
	
	public static LoginDAO getInstance() throws ClassNotFoundException, SQLException {
		if(ldao == null)
			ldao = new LoginDAO();
		return ldao;
	}
	
	@Override
	public String loginSearch(String id, String pw) throws SQLException {
		String sql = "select id from member_info where id = ? and password = ?";
		String resultId = "";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				resultId = rs.getString(1);
				System.out.println(resultId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultId;
	}
}
