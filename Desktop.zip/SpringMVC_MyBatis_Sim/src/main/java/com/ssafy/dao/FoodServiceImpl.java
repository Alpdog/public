package com.ssafy.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.dao.FoodDao;
import com.ssafy.dao.FoodDaoImpl;
import com.ssafy.vo.Food;
import com.ssafy.vo.FoodPageBean;

@Service
public class FoodServiceImpl implements FoodService{
	private FoodDao dao;
	private String[] allergys;
	
	public FoodServiceImpl() throws ClassNotFoundException, SQLException {
		this.dao = new FoodDaoImpl();
	}

	@Override
	public List<Food> searchAll(FoodPageBean bean) {
		return dao.searchAll(bean);
	}

	@Override
	public Food search(int code) {
		return dao.search(code);
	}

	@Override
	public List<Food> searchBest() {
		return dao.searchBest();
	}

	@Override
	public List<Food> searchBestIndex() {
		return dao.searchBestIndex();
	}

}
