package com.ssafy.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.vo.MemberInfoVO;

@Repository
public class MemberInfoDAO {
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	public boolean addMemberInfo(String id, String pw, String name, String allergy) {
		int s = sqlSession.insert("member.add", new MemberInfoVO(id, pw, name, allergy));

		if(s == 1)
			return true;
		return false;
	}
	
	public boolean updateMemberInfo(String id, String pw, String name, String allergy) {
		int s = sqlSession.update("member.update", new MemberInfoVO(id, pw, name, allergy));

		if(s != 0)
			return true;
		return false;
	}
	
	public boolean deleteMemberInfo(String id) {
		int s = sqlSession.delete("member.delete", new MemberInfoVO(id));

		if(s != 0)
			return true;
		return false;
	}
	
	public String searchMemberInfo(String id, String pw) {
		return sqlSession.selectOne("member.search", new MemberInfoVO(id, pw));
	}
	
	public List<Map<String, Object>> getAllMemberInfo(){
		return sqlSession.selectList("member.getAllMemberInfo");
	}
}
