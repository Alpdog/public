package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.service.FoodServiceImpl;
import com.ssafy.vo.FoodPageBean;

public class mainUI implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		FoodPageBean fpb = new FoodPageBean((String)request.getAttribute("key"), (String)request.getAttribute("word"), null, 1);
		
		request.setAttribute("foods", new FoodServiceImpl().searchAll(fpb));
		
		return "main.jsp";
	}

}
