package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DetailAnnounce implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "detailAnnounce.jsp";
	}

}
