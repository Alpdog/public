package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddAnnounce implements Controller {

	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "/addBoard.jsp";
	}
}
