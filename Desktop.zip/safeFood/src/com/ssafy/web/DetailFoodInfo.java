package com.ssafy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DetailFoodInfo implements Controller {

	@Override
	public String getUrl(HttpServletRequest request, HttpServletResponse response) {
		return "detailProduct.jsp";
	}

}
