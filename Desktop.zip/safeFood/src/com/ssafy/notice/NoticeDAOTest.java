package com.ssafy.notice;

import java.sql.SQLException;

public class NoticeDAOTest {

	public static void main(String[] args) {
		try {
			NoticeDAO e = new NoticeDAO();
			System.out.println("conn OK");
			System.out.println(e.getAllNotice());
			e.addNotice(new NoticeVO(2, "SSAFY인", 1, "장진원", "역량테스트 A+", null, false, 0));
			e.addNotice(new NoticeVO(3, "삼성인", 1, "장진원", "안녕하세요", null, false, 0));
			e.addNotice(new NoticeVO(4, "오늘의 점심", 3, "심상우", "돈까스", null, false, 0));
			e.addNotice(new NoticeVO(5, "오늘의 저녁", 1, "심상우", "집", null, false, 0));
			System.out.println(e.getAllNotice().size());
			e.deleteNotice(5);
			System.out.println(e.getAllNotice());
			e.setNotice(new NoticeVO(4, "오늘의 아침", 3, "심상우", "콘푸로스트", null, false, 0));
			System.out.println(e.getAllNotice());
			
			System.out.println("-------------------");
			System.out.println(e.getNoticeByUser("장진원"));
			System.out.println(e.getNoticeByTitle("오늘"));
			System.out.println(e.getNotice(1));

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		System.out.println("end");
	}

}
