package com.ssafy.dao;

import java.util.List;

import com.ssafy.vo.Announce;
import com.ssafy.vo.Food;

public interface AnnounceDao {
	public List<Announce> searchAll();
	public Announce search(int idx);
	public void add(Announce announce);
	public boolean delete(int idx);
	public boolean update(Announce announce);
}
