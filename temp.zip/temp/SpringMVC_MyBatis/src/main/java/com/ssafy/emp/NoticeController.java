package com.ssafy.emp;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class NoticeController {
	NoticeService noticeService;
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	
	@RequestMapping(value = "/noticeInsertUI", method = RequestMethod.GET)
	public String noticeInsertUI () {
		return "noticeInsertUI";
	}
	
	@RequestMapping(value = "/noticeListUI", method = RequestMethod.POST)
	public ModelAndView noticeListUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeListUI");
		List<NoticeVO> temp = noticeService.getAllNotices();
		if(temp != null) {
			mv.addObject("list", temp);
		}
		return mv;
	}
	
	@RequestMapping(value = "/noticeUpdateUI", method = RequestMethod.POST)
	public ModelAndView noticeUpdateUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeUpdateUI");
		String notice_idx = request.getParameter("notice_idx");
		NoticeVO temp = noticeService.getNotice("notice_idx");
		if(temp != null) {
			mv.addObject("selected", temp);
		}
		return mv;
	}
	
	
	@RequestMapping(value = "/noticeUpdateAction", method = RequestMethod.POST)
	public ModelAndView noticeUpdateAction(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeResultUI");
		String notice_idx = request.getParameter("notice_idx");
		String title = request.getParameter("notice_idx");
		String date = request.getParameter("notice_idx");
		String category = request.getParameter("notice_idx");
		String content = request.getParameter("notice_idx");
		String attached_file = request.getParameter("notice_idx");
		boolean temp = noticeService.setNotice(new NoticeVO(notice_idx, title, date, category, content, attached_file));
		if(temp) {
			mv.addObject("selected", temp);
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	
	@RequestMapping(value = "/noticeViewUI", method = RequestMethod.POST)
	public ModelAndView noticeViewUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeViewUI");
		String notice_idx = request.getParameter("notice_idx");
		NoticeVO temp = noticeService.getNotice(notice_idx);
		
		if(temp != null) {
			mv.addObject("selected", temp);
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	
	
	@RequestMapping(value = "/noticeListUI", method = RequestMethod.POST)
	public ModelAndView noticeListUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeListUI");
		List<NoticeVO> temp = noticeService.getAllNotices();
		if(temp != null) {
			mv.addObject("list", temp);
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	
	@RequestMapping(value = "/noticeListUI", method = RequestMethod.POST)
	public ModelAndView noticeListUI(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("noticeListUI");
		List<NoticeVO> temp = noticeService.getAllNotices();
		if(temp != null) {
			mv.addObject("list", temp);
		}else {
			mv.addObject("result", "ERROR");
		}
		return mv;
	}
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		return "home";
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ModelAndView exceptionPage(RuntimeException e) {
		Map<String, String> model = new HashMap<String, String>();
		model.put("exception_info", e.getMessage());
		model.put("code", "5XX");
		return new ModelAndView("error/error_page", model);
	}
}
