#include <stdio.h>

#if 0
int b = 20;

void func() {
	extern int a;
	a++;
	b++;

	printf("a = %d\n", a);
	printf("b = %d\n", b);
}

#endif

#if 0
extern int a;
static int b = 20;
static int c = 30;

void func(void) {
	a++;
	b++;
	c++;

	printf("a = %d\n", a);
	printf("b = %d\n", b);
	printf("c = %d\n", c);
}

#endif
