#include<stdio.h>
#include<malloc.h>
#include<string.h>

#if 0

int main() {


	return 0;
}

#endif

#if 0

void func(char *p, int size) {

	for (int i = 0; i<size; i++) {
		printf("%c", *(p + i));
	}

	printf("\n");
}

int get_length(char const *p) {
	int counter = 0;

	while (*p++) {
		counter++;
	}

	return counter;
}

int main() {

	char p[] = "Hello";

	func(p, get_length(p));
	
	return 0;
}

#endif //ÃÃÂ¼Ã¶ÃÃ Â¹Ã¨Â¿Â­ ÃÃ¼Â´Ã Â¿Â¬Â½Ã + Â¹Ã¨Â¿Â­ÃÃ Â±Ã¦ÃÃ ÃÃ¸ÃÂ¤

#if 0

void str_add(char *d, const char *s) {
	while (*d != '\0') {
		d++;
	}
	while (*d++ = *s++); // *sÂ°Â¡ NULLÃÂ» Â°Â¡Â¸Â®ÃÂ³ Â¶Â§ Â´Ã«ÃÃÂ¿Â¬Â»ÃªÃÃ ÃÃÃÃ NULLÃÃ ÂµÃÂ¹ÃÂ·Ã Â¸ÃÃÃÂ°Ã ÂµÃ
}

int main() {

	char a[15] = "Willtek";
	char b[15] = "Corp";

	str_add(a, b);

	printf("%s\n", a);

	return 0;
}

#endif // Â¹Ã¨Â¿Â­+ while Â¹Â® ÃÂ°Â¿Ã«

#if 0

int main() {
	int required = 40;
	int *p;
	int i;

	//p = malloc(40);
	p = calloc(10, sizeof(int));
	required = 80;
	p = realloc(p, required);

	for (i = 0; i<(required/ sizeof(p)); i++) {
		*(p+i) = i;
	}

	for (i = 0; i < (required /sizeof(p)); i++)
	{
		printf("%d ", p[i]);
	}

	free(p);
	return 0;
}

#endif // malloc(ÃÃÂ´Ã§ÃÃ ÃÂ©Â±Ã¢), calloc(ÂºÃ­Â·Ã Â°Â¹Â¼Ã¶, ÂºÃ­Â·Ã Â»Ã§ÃÃÃÃ®), realloc(Â¿Ã¸Â·Â¡ ÃÃÂ¼Ã, Â¼Ã¶ÃÂ¤ ÃÃÃÃ ÃÃ¼ÃÂ¼ Â¸ÃÂ¸Ã°Â¸Â® ÃÂ©Â±Ã¢)


#if 0

struct st { // stÂ´Ã tag
	int a; //member. ÃÃÂ¼Ã¶ ÃÂ¦Â¿ÃÃÃ Â¹Ã¨Â¿Â­, ÃÃ·ÃÃÃÃ, ÂºÂ¯Â¼Ã¶ Â°Â¡Â´Ã
	char b;
}y = {102, 'B'}, z; // ÂµÃ»Â·Ã Â¼Â±Â¾Ã°ÃÂ» ÃÃÃÃ¶ Â¾ÃÃÂ¸Â¸Ã© ÃÃÃÃÂ¸Â´Â¸Â¸ Â¼Â±Â¾Ã°ÂµÃ Â°ÃÃÃÂ¸Ã§, ÂºÂ¯Â¼Ã¶Â°Â¡ Â»Ã½Â±Ã¤ Â°ÃÃÂº Â¾ÃÂ´Ã

struct st x = {101, 'A'};
int main() {
	struct st xy = x; //Â±Â¸ÃÂ¶ÃÂ¼ Â³Â¢Â¸Â® Â´Ã«ÃÃÃÃÂ¸Ã© Â¸Ã¢Â¹Ã¶ÂµÃ©ÃÃ ÂºÂ¹Â»Ã§ÂµÃ
	printf("%d %c\n", x.a, x.b); //ÃÂ£ÃÃ¢ Â¹Ã¦Â½Ã x.a
	printf("%d %c\n", y.a, y.b);
	printf("%d %c\n", z.a, z.b);
	printf("%d %c\n", xy.a, xy.b);
	return 0;
}

#endif // Â±Â¸ÃÂ¶ÃÂ¼ Â¼Â±Â¾Ã° Â¹Ã ÃÂ°Â¿Ã«

#if 0

int y = 200;
struct st {
	int a;
	int b[4];
	int *p;
}new_st = { 100, {1,2,3,4}};


int main() {

	printf("%d\n", new_st.a);
	printf("%d\n", new_st.b[3]);
	printf("%p\n", new_st.p);

	new_st.a = y;
	new_st.b[3] = y;
	new_st.p = &y;

	printf("%d\n", new_st.a);
	printf("%d\n", new_st.b[3]);
	printf("%p\n", new_st.p);

	return 0;
}

#endif // Â±Â¸ÃÂ¶ÃÂ¼Â¿Â¡ ÃÃ·ÃÃÃÃ, Â¹Ã¨Â¿Â­ Â¼Â±Â¾Ã°ÃÃÂ¼Â­ Â»Ã§Â¿Ã«ÃÃÂ±Ã¢ : Â±ÃÂ³Ã new_st.b[3] ÃÃÂ·Â¸Â°Ã Â¾Â²Â¸Ã© ÂµÃ

#if 0

struct st {
	char st_words[15];
} x = {"Origin words"};

int main() {
	char words[15] = "New String";

	printf("%s\n", x.st_words);


	strcpy(x.st_words, words);

	printf("%s\n", x.st_words);

	memcpy(x.st_words, "Last change", sizeof("Last change"));

	printf("%s\n", x.st_words);

	return 0;
}

#endif // Â¹Â®ÃÃÂ¿Â­ ÂºÂ¹Â»Ã§ : strcpy, memcpy ÃÂ°Â¿Ã« : Â±Â¸ÃÂ¶ÃÂ¼ÃÃ Â¸Ã¢Â¹Ã¶Â´Ã Â¸Ã¢Â¹Ã¶ ÃÃÃÂ¼ÃÃ ÃÂ¸ÃÃÂ°Ãº Â°Â°ÃÂ¸Â¹ÃÂ·Ã ÃÃÂ¹ÃÃÃ»ÃÃ Â¹Â®ÃÃÂ¿Â­Â°Ãº Â°Â°ÃÃ Â´Ã«ÃÃÃÂ» ÃÃ«ÃÃ Â¼Ã¶ÃÂ¤ ÂºÃÂ°Â¡

#if 0
struct st {
	int a;
	char b[5];
}x[3] = {{ 1, "ABCD" }, {2, "EFGH"}, {3, "IJKL"}};

int main() {
	struct st *p;

	p = x;
	for(int i = 0; i < 3; i++)
		printf("%d, %s\n", x[i].a, x[i].b);

	printf("%c\n", *((x[0].b)+1));

	printf("%d\n", (*(p+2)).a); // Â¿Â¬Â»ÃªÃÃ Â¼Ã¸Â¼Â­Â¿Â¡ ÂµÃ»Â¶Ã³ *p.a = *(p.a)ÃÃÂ¹ÃÂ·Ã (*p).aÂ·Ã ÃÃÃÃ Â¾ÃÃÃ
	printf("%c\n", *((*(p+2)).b + 2));
	printf("%c\n", *((p+2)->b + 2)); // ÃÃ·ÃÃÃÃ ÂºÂ¯Â¼Ã¶ÃÃ Â°Ã¦Â¿Ã¬ p -> a Â¿Ã Â°Â°ÃÃ Â»Ã§Â¿Ã« Â°Â¡Â´Ã ((*p).aÂ¿Ã Â°Â°ÃÂº ÃÃÂ¹Ã)


	return 0;
}
#endif // Â±Â¸ÃÂ¶ÃÂ¼ Â¹Ã¨Â¿Â­Â°Ãº Â±Â¸ÃÂ¶ÃÂ¼ ÃÃ·ÃÃÃÃÂ¿Â¡Â¼Â­ Â°Â¢Â°Â¢ÃÃ Â¸Ã¢Â¹Ã¶ ÃÂ°Â¿Ã«ÃÃÂ±Ã¢ ( * Â¿Â¬Â»ÃªÃÃÃÃ Â¿Ã¬Â¼Â±Â¼Ã¸ÃÂ§Â¿Â¡ ÃÃÃÃÃÃ Â°Ã!)

#if 0

struct st {
	int id;
	char * name;
	struct st *p;
}x, y;

int main() {
	y.id = 2;
	y.name = "Jang";
	y.p = 0x0;

	x.id = 1;
	x.name = "Kim";
	x.p = &y;

	printf("%d\n", x.id);
	printf("%s\n", x.name);
	printf("%d\n", (x.p)->id);
	printf("%s\n", (x.p)->name);
	printf("%s\n", ((x.p)->name + 1));
	printf("%c\n", *((x.p)->name + 1));

	return 0;
}


#endif // ÃÃÂ±Ã¢ ÃÃ¼ÃÂ¶ Â±Â¸ÃÂ¶ÃÂ¼ ÃÂ°Â¿Ã«

#if 0

#define SWAP(p,q){\
int t = *p;\
*p = *q;\
*q = t;\
}

#define PRT(n) printf("NO_"#n" = %d\n", NO_##n)

int main() {

	int NO_1 = 100;
	int NO_2 = 200;
	int NO_3 = 300;
	int a = 3;
	int b = 5;
	SWAP(&a, &b);

	printf("%d %d", a, b);
	PRT(1);
	PRT(2);
	PRT(3);
}

#endif // Â¸ÃÃÂ©Â·Ã Â¹Ã ÂºÂ¹ÃÃÂ¹Â®. Â¸ÃÃÂ©Â·ÃÃÃ Â°Ã¦Â¿Ã¬ ÃÃ ÃÃÂ·Ã ÃÃÂ¼ÂºÃÃÂ¾Ã ÃÃÂ¹ÃÂ·Ã ÃÃÂ¹ÃÂ²Ã±ÃÂ» ÃÂ¥Â½ÃÃÃÂ´Ã \Â¸Â¦ ÃÃÂ¿Ã«ÃÃÂ¼Â­ ÃÃÂ¼ÂºÃÃÂ¾ÃÃÃÂ´Ã.
// #ÃÂº Â¹Â®ÃÃÂ¿Â­ÃÂ­ #n = "n" Â°Ãº Â°Â°ÃÂ¸Â¸Ã§, ##nÃÃ Â°Ã¦Â¿Ã¬ NO_n ÃÃ¼Â½ÃÃÂ¸Â·Ã Â¹ÃÂ²ÃÂ´ÃÂµÂ¥ Â»Ã§Â¿Ã«ÂµÃÂ´Ã
#if 0

#define get_length(x) sizeof(a)/sizeof(int)
int main() {
	int a[5] = {1,2,3,4,5};
	for (int i = 0; i < get_length(a); i++) {
		printf("%d ", a[i]);
	}

	return 0;
}

#endif // Â¹Ã¨Â¿Â­ÃÃ Â¿Ã¤Â¼ÃÂ¼Ã¶ Â±Â¸ÃÃÂ´Ã Â¸ÃÃÂ©Â·Ã. ÃÃÂ¼Ã¶ÃÃ argumentÂ·Ã Â³ÃÂ°ÃÃÃÂ´Ã Â°ÃÂ°ÃºÂ´Ã Â´ÃÂ¸Â£Â°Ã Â±ÃÂ³Ã sizeof(a)ÃÃÂ¸Ã© Â¹Ã¨Â¿Â­ ÃÃ¼ÃÂ¼ÃÃ ÃÂ©Â±Ã¢Â°Â¡ Â»Ã½Â±Ã¨