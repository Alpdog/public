#include <stdio.h>


#if 0
int main() {


	return 0;
}

#endif


#if 0
int main() {

	int number = 0;
	printf("Type number : \n");
	scanf("%d", &number);
	printf("10ÃÃ¸Â¼Ã¶ : %d\n", number);
	printf("8ÃÃ¸Â¼Ã¶ : %o\n", number);
	printf("16ÃÃ¸Â¼Ã¶ : %X\n", number);

	return 0;
}

#endif // ÃÃ¸Â¹Ã½ ÂºÂ¯ÃÂ¯

#if 0
int main() {

	printf("%#x\n", 0x123456789ABCDEF0LL);
	printf("%#llx\n", 0xABCDEF0);

	return 0;
}


#endif //format ÃÃ¶Â½ÃÃÃ ÃÂ°Â¿Ã«

#if 0

int y1 = 100;
int y2 = 32;

int main() {

	int x1 = 10;
	int x2 = 20;

	printf("%d %d %d %d\n", x1, x2, y1, y2);
	printf("x1 = %#.8X\nx2 = %#.8X\ny1 = %#.8X\ny2 = %#.8X\n", &x1, &x2, &y1, &y2);

	return 0;
}

#endif // ÂºÂ¯Â¼Ã¶ÃÃ Â¸ÃÂ¸Ã°Â¸Â® ÃÃÂ´Ã§

#if 0

int main() {

	int x = 0;
	int y = 0;
	int z = 0;

	char a;
	char b;

	//for (;;) {
	//	printf("input x, y, z : \n");
	//	scanf("%d %d %d", &x, &y, &z);
	//	printf("%d %d %d\n", x, y, z);
	//}

	for (;;) {
		printf("2Â±ÃÃÃ ÃÃÂ·Ã");
		scanf(" %c %c", &a, &b);
		fflush(stdin);
		printf("%c%c", a,b);
	}

	return 0;
}

#endif // scanf ÃÂ°Â¿Ã«

#if 0

int main() {

	int a = 100;// 1100100;

	//a |= (1 << 1) | (1 << 3);
	//a &= ~(1<<2);
	printf("%d", a);

	return 0;
}

#endif // ÂºÃ±ÃÂ® Â¿Â¬Â»ÃªÃÃ

#if 01
int main() {

	
	return 0;
}

#endif